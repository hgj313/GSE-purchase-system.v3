var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// netlify/functions/utils/netlifyDatabase.js
var require_netlifyDatabase = __commonJS({
  "netlify/functions/utils/netlifyDatabase.js"(exports2, module2) {
    var fs = require("fs");
    var path = require("path");
    var NetlifyDatabase = class {
      constructor() {
        this.data = null;
        this.initialized = false;
        this.initPromise = null;
      }
      /**
       * 初始化Netlify云端数据库
       * 使用内存存储，避免文件系统权限问题
       */
      async init() {
        if (this.initialized) return true;
        if (this.initPromise) return this.initPromise;
        this.initPromise = this._initialize();
        const result = await this.initPromise;
        this.initPromise = null;
        return result;
      }
      async _initialize() {
        try {
          console.log("\u{1F310} \u521D\u59CB\u5316Netlify\u4E91\u7AEF\u6570\u636E\u5E93...");
          this.data = this.getDefaultData();
          if (process.env.NETLIFY_DATA) {
            try {
              this.data = JSON.parse(process.env.NETLIFY_DATA);
              console.log("\u2705 \u4ECE\u73AF\u5883\u53D8\u91CF\u52A0\u8F7D\u9884\u8BBE\u6570\u636E");
            } catch (e) {
              console.log("\u26A0\uFE0F \u73AF\u5883\u53D8\u91CF\u6570\u636E\u683C\u5F0F\u9519\u8BEF\uFF0C\u4F7F\u7528\u9ED8\u8BA4\u6570\u636E");
            }
          }
          console.log("\u2705 Netlify\u4E91\u7AEF\u6570\u636E\u5E93\u521D\u59CB\u5316\u6210\u529F");
          this.initialized = true;
          return true;
        } catch (error) {
          console.error("\u274C Netlify\u6570\u636E\u5E93\u521D\u59CB\u5316\u5931\u8D25:", error);
          return false;
        }
      }
      /**
       * 获取默认数据结构
       */
      getDefaultData() {
        return {
          designSteels: [],
          moduleSteels: [
            {
              id: "default_1",
              name: "12\u7C73\u6807\u51C6\u94A2\u6750",
              length: 12e3,
              createdAt: (/* @__PURE__ */ new Date()).toISOString(),
              updatedAt: (/* @__PURE__ */ new Date()).toISOString()
            },
            {
              id: "default_2",
              name: "9\u7C73\u6807\u51C6\u94A2\u6750",
              length: 9e3,
              createdAt: (/* @__PURE__ */ new Date()).toISOString(),
              updatedAt: (/* @__PURE__ */ new Date()).toISOString()
            },
            {
              id: "default_3",
              name: "6\u7C73\u6807\u51C6\u94A2\u6750",
              length: 6e3,
              createdAt: (/* @__PURE__ */ new Date()).toISOString(),
              updatedAt: (/* @__PURE__ */ new Date()).toISOString()
            }
          ],
          optimizationTasks: [],
          systemStats: {
            totalOptimizations: 0,
            totalDesignSteels: 0,
            totalModuleSteels: 3,
            totalSavedCost: 0,
            lastUpdated: (/* @__PURE__ */ new Date()).toISOString()
          },
          operationLogs: [],
          settings: {
            autoBackup: false,
            // 云端环境禁用自动备份
            maxLogEntries: 100,
            maxBackups: 5
          }
        };
      }
      /**
       * 创建优化任务
       */
      async createOptimizationTask(taskData) {
        try {
          await this.init();
          const taskId = "task_" + Date.now() + "_" + Math.random().toString(36).substr(2, 9);
          const task = {
            id: taskId,
            designSteels: taskData.designSteels || [],
            moduleSteels: taskData.moduleSteels || [],
            constraints: taskData.constraints || {},
            status: "pending",
            progress: 0,
            createdAt: (/* @__PURE__ */ new Date()).toISOString(),
            updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
            results: null,
            error: null
          };
          this.data.optimizationTasks.push(task);
          this.data.systemStats.totalOptimizations++;
          this.data.systemStats.lastUpdated = (/* @__PURE__ */ new Date()).toISOString();
          console.log(`\u2705 \u4E91\u7AEF\u4EFB\u52A1\u521B\u5EFA\u6210\u529F: ${taskId}`);
          return taskId;
        } catch (error) {
          console.error("\u274C \u521B\u5EFA\u4E91\u7AEF\u4EFB\u52A1\u5931\u8D25:", error);
          throw error;
        }
      }
      /**
       * 更新任务状态
       */
      async updateTaskStatus(taskId, status) {
        try {
          await this.init();
          const task = this.data.optimizationTasks.find((t) => t.id === taskId);
          if (task) {
            task.status = status;
            task.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
            return true;
          }
          return false;
        } catch (error) {
          console.error("\u274C \u66F4\u65B0\u4EFB\u52A1\u72B6\u6001\u5931\u8D25:", error);
          return false;
        }
      }
      /**
       * 更新任务进度
       */
      async updateTaskProgress(taskId, progress, message) {
        try {
          await this.init();
          const task = this.data.optimizationTasks.find((t) => t.id === taskId);
          if (task) {
            task.progress = progress;
            task.message = message;
            task.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
            return true;
          }
          return false;
        } catch (error) {
          console.error("\u274C \u66F4\u65B0\u4EFB\u52A1\u8FDB\u5EA6\u5931\u8D25:", error);
          return false;
        }
      }
      /**
       * 设置任务结果
       */
      async setTaskResults(taskId, results) {
        try {
          await this.init();
          const task = this.data.optimizationTasks.find((t) => t.id === taskId);
          if (task) {
            task.results = results;
            task.status = results.success ? "completed" : "failed";
            task.progress = 100;
            task.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
            return true;
          }
          return false;
        } catch (error) {
          console.error("\u274C \u8BBE\u7F6E\u4EFB\u52A1\u7ED3\u679C\u5931\u8D25:", error);
          return false;
        }
      }
      /**
       * 设置任务错误
       */
      async setTaskError(taskId, error) {
        try {
          await this.init();
          const task = this.data.optimizationTasks.find((t) => t.id === taskId);
          if (task) {
            task.error = error;
            task.status = "failed";
            task.progress = 100;
            task.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
            return true;
          }
          return false;
        } catch (error2) {
          console.error("\u274C \u8BBE\u7F6E\u4EFB\u52A1\u9519\u8BEF\u5931\u8D25:", error2);
          return false;
        }
      }
      /**
       * 获取任务
       */
      async getTask(taskId) {
        await this.init();
        return this.data.optimizationTasks.find((t) => t.id === taskId);
      }
      /**
       * 获取数据库统计信息
       */
      getStats() {
        if (!this.data) {
          return {
            designSteels: 0,
            moduleSteels: 3,
            optimizationTasks: 0,
            completedTasks: 0,
            operationLogs: 0,
            databaseSize: "\u5185\u5B58\u5B58\u50A8",
            lastUpdated: (/* @__PURE__ */ new Date()).toISOString()
          };
        }
        return {
          designSteels: this.data.designSteels?.length || 0,
          moduleSteels: this.data.moduleSteels?.length || 0,
          optimizationTasks: this.data.optimizationTasks?.length || 0,
          completedTasks: this.data.optimizationTasks?.filter((task) => task.status === "completed")?.length || 0,
          operationLogs: this.data.operationLogs?.length || 0,
          databaseSize: "\u5185\u5B58\u5B58\u50A8",
          lastUpdated: this.data.systemStats?.lastUpdated || (/* @__PURE__ */ new Date()).toISOString()
        };
      }
      /**
       * 获取数据库连接
       */
      getConnection() {
        if (!this.initialized) {
          throw new Error("Netlify\u4E91\u7AEF\u6570\u636E\u5E93\u672A\u521D\u59CB\u5316");
        }
        return this;
      }
    };
    var netlifyDb = new NetlifyDatabase();
    module2.exports = netlifyDb;
  }
});

// netlify/functions/health.js
var db = require_netlifyDatabase();
exports.handler = async (event, context) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  try {
    const dbInitialized = await db.init();
    if (!dbInitialized) {
      return {
        statusCode: 503,
        headers,
        body: JSON.stringify({
          status: "error",
          message: "\u4E91\u7AEF\u6570\u636E\u5E93\u521D\u59CB\u5316\u5931\u8D25",
          database: "failed",
          timestamp: (/* @__PURE__ */ new Date()).toISOString()
        })
      };
    }
    const stats = db.getStats();
    const healthInfo = {
      status: "healthy",
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      version: "1.7.0",
      services: {
        database: "connected",
        api: "running"
      },
      stats,
      environment: process.env.NODE_ENV || "production",
      endpoints: [
        "GET /.netlify/functions/health",
        "POST /.netlify/functions/optimize",
        "POST /.netlify/functions/validate-constraints",
        "POST /.netlify/functions/upload-design-steels",
        "GET /.netlify/functions/optimize/:id/progress",
        "GET /.netlify/functions/optimize/history",
        "POST /.netlify/functions/export/excel",
        "POST /.netlify/functions/export/pdf"
      ]
    };
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(healthInfo)
    };
  } catch (error) {
    console.error("\u274C \u4E91\u7AEF\u5065\u5EB7\u68C0\u67E5\u5931\u8D25:", error);
    return {
      statusCode: 503,
      headers,
      body: JSON.stringify({
        status: "unhealthy",
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        error: error.message,
        message: "\u4E91\u7AEF\u670D\u52A1\u5F02\u5E38"
      })
    };
  }
};
