var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// node_modules/lowdb/lib/adapters/Memory.js
var Memory, MemorySync;
var init_Memory = __esm({
  "node_modules/lowdb/lib/adapters/Memory.js"() {
    Memory = class {
      #data = null;
      read() {
        return Promise.resolve(this.#data);
      }
      write(obj) {
        this.#data = obj;
        return Promise.resolve();
      }
    };
    MemorySync = class {
      #data = null;
      read() {
        return this.#data || null;
      }
      write(obj) {
        this.#data = obj;
      }
    };
  }
});

// node_modules/lowdb/lib/core/Low.js
function checkArgs(adapter, defaultData) {
  if (adapter === void 0)
    throw new Error("lowdb: missing adapter");
  if (defaultData === void 0)
    throw new Error("lowdb: missing default data");
}
var Low, LowSync;
var init_Low = __esm({
  "node_modules/lowdb/lib/core/Low.js"() {
    Low = class {
      adapter;
      data;
      constructor(adapter, defaultData) {
        checkArgs(adapter, defaultData);
        this.adapter = adapter;
        this.data = defaultData;
      }
      async read() {
        const data = await this.adapter.read();
        if (data)
          this.data = data;
      }
      async write() {
        if (this.data)
          await this.adapter.write(this.data);
      }
      async update(fn) {
        fn(this.data);
        await this.write();
      }
    };
    LowSync = class {
      adapter;
      data;
      constructor(adapter, defaultData) {
        checkArgs(adapter, defaultData);
        this.adapter = adapter;
        this.data = defaultData;
      }
      read() {
        const data = this.adapter.read();
        if (data)
          this.data = data;
      }
      write() {
        if (this.data)
          this.adapter.write(this.data);
      }
      update(fn) {
        fn(this.data);
        this.write();
      }
    };
  }
});

// node_modules/lowdb/lib/index.js
var lib_exports = {};
__export(lib_exports, {
  Low: () => Low,
  LowSync: () => LowSync,
  Memory: () => Memory,
  MemorySync: () => MemorySync
});
var init_lib = __esm({
  "node_modules/lowdb/lib/index.js"() {
    init_Memory();
    init_Low();
  }
});

// node_modules/steno/lib/index.js
function getTempFilename(file) {
  const f = file instanceof URL ? (0, import_node_url.fileURLToPath)(file) : file.toString();
  return (0, import_node_path.join)((0, import_node_path.dirname)(f), `.${(0, import_node_path.basename)(f)}.tmp`);
}
async function retryAsyncOperation(fn, maxRetries, delayMs) {
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (error) {
      if (i < maxRetries - 1) {
        await new Promise((resolve) => setTimeout(resolve, delayMs));
      } else {
        throw error;
      }
    }
  }
}
var import_promises, import_node_path, import_node_url, Writer;
var init_lib2 = __esm({
  "node_modules/steno/lib/index.js"() {
    import_promises = require("fs/promises");
    import_node_path = require("path");
    import_node_url = require("url");
    Writer = class {
      #filename;
      #tempFilename;
      #locked = false;
      #prev = null;
      #next = null;
      #nextPromise = null;
      #nextData = null;
      // File is locked, add data for later
      #add(data) {
        this.#nextData = data;
        this.#nextPromise ||= new Promise((resolve, reject) => {
          this.#next = [resolve, reject];
        });
        return new Promise((resolve, reject) => {
          this.#nextPromise?.then(resolve).catch(reject);
        });
      }
      // File isn't locked, write data
      async #write(data) {
        this.#locked = true;
        try {
          await (0, import_promises.writeFile)(this.#tempFilename, data, "utf-8");
          await retryAsyncOperation(async () => {
            await (0, import_promises.rename)(this.#tempFilename, this.#filename);
          }, 10, 100);
          this.#prev?.[0]();
        } catch (err) {
          if (err instanceof Error) {
            this.#prev?.[1](err);
          }
          throw err;
        } finally {
          this.#locked = false;
          this.#prev = this.#next;
          this.#next = this.#nextPromise = null;
          if (this.#nextData !== null) {
            const nextData = this.#nextData;
            this.#nextData = null;
            await this.write(nextData);
          }
        }
      }
      constructor(filename) {
        this.#filename = filename;
        this.#tempFilename = getTempFilename(filename);
      }
      async write(data) {
        return this.#locked ? this.#add(data) : this.#write(data);
      }
    };
  }
});

// node_modules/lowdb/lib/adapters/node/TextFile.js
var import_node_fs, import_promises2, import_node_path2, TextFile, TextFileSync;
var init_TextFile = __esm({
  "node_modules/lowdb/lib/adapters/node/TextFile.js"() {
    import_node_fs = require("fs");
    import_promises2 = require("fs/promises");
    import_node_path2 = __toESM(require("path"), 1);
    init_lib2();
    TextFile = class {
      #filename;
      #writer;
      constructor(filename) {
        this.#filename = filename;
        this.#writer = new Writer(filename);
      }
      async read() {
        let data;
        try {
          data = await (0, import_promises2.readFile)(this.#filename, "utf-8");
        } catch (e) {
          if (e.code === "ENOENT") {
            return null;
          }
          throw e;
        }
        return data;
      }
      write(str) {
        return this.#writer.write(str);
      }
    };
    TextFileSync = class {
      #tempFilename;
      #filename;
      constructor(filename) {
        this.#filename = filename;
        const f = filename.toString();
        this.#tempFilename = import_node_path2.default.join(import_node_path2.default.dirname(f), `.${import_node_path2.default.basename(f)}.tmp`);
      }
      read() {
        let data;
        try {
          data = (0, import_node_fs.readFileSync)(this.#filename, "utf-8");
        } catch (e) {
          if (e.code === "ENOENT") {
            return null;
          }
          throw e;
        }
        return data;
      }
      write(str) {
        (0, import_node_fs.writeFileSync)(this.#tempFilename, str);
        (0, import_node_fs.renameSync)(this.#tempFilename, this.#filename);
      }
    };
  }
});

// node_modules/lowdb/lib/adapters/node/DataFile.js
var DataFile, DataFileSync;
var init_DataFile = __esm({
  "node_modules/lowdb/lib/adapters/node/DataFile.js"() {
    init_TextFile();
    DataFile = class {
      #adapter;
      #parse;
      #stringify;
      constructor(filename, { parse, stringify }) {
        this.#adapter = new TextFile(filename);
        this.#parse = parse;
        this.#stringify = stringify;
      }
      async read() {
        const data = await this.#adapter.read();
        if (data === null) {
          return null;
        } else {
          return this.#parse(data);
        }
      }
      write(obj) {
        return this.#adapter.write(this.#stringify(obj));
      }
    };
    DataFileSync = class {
      #adapter;
      #parse;
      #stringify;
      constructor(filename, { parse, stringify }) {
        this.#adapter = new TextFileSync(filename);
        this.#parse = parse;
        this.#stringify = stringify;
      }
      read() {
        const data = this.#adapter.read();
        if (data === null) {
          return null;
        } else {
          return this.#parse(data);
        }
      }
      write(obj) {
        this.#adapter.write(this.#stringify(obj));
      }
    };
  }
});

// node_modules/lowdb/lib/adapters/node/JSONFile.js
var JSONFile, JSONFileSync;
var init_JSONFile = __esm({
  "node_modules/lowdb/lib/adapters/node/JSONFile.js"() {
    init_DataFile();
    JSONFile = class extends DataFile {
      constructor(filename) {
        super(filename, {
          parse: JSON.parse,
          stringify: (data) => JSON.stringify(data, null, 2)
        });
      }
    };
    JSONFileSync = class extends DataFileSync {
      constructor(filename) {
        super(filename, {
          parse: JSON.parse,
          stringify: (data) => JSON.stringify(data, null, 2)
        });
      }
    };
  }
});

// node_modules/lowdb/lib/presets/node.js
async function JSONFilePreset(filename, defaultData) {
  const adapter = process.env.NODE_ENV === "test" ? new Memory() : new JSONFile(filename);
  const db = new Low(adapter, defaultData);
  await db.read();
  return db;
}
function JSONFileSyncPreset(filename, defaultData) {
  const adapter = process.env.NODE_ENV === "test" ? new MemorySync() : new JSONFileSync(filename);
  const db = new LowSync(adapter, defaultData);
  db.read();
  return db;
}
var init_node = __esm({
  "node_modules/lowdb/lib/presets/node.js"() {
    init_Memory();
    init_JSONFile();
    init_Low();
  }
});

// node_modules/lowdb/lib/node.js
var node_exports = {};
__export(node_exports, {
  DataFile: () => DataFile,
  DataFileSync: () => DataFileSync,
  JSONFile: () => JSONFile,
  JSONFilePreset: () => JSONFilePreset,
  JSONFileSync: () => JSONFileSync,
  JSONFileSyncPreset: () => JSONFileSyncPreset,
  TextFile: () => TextFile,
  TextFileSync: () => TextFileSync
});
var init_node2 = __esm({
  "node_modules/lowdb/lib/node.js"() {
    init_DataFile();
    init_JSONFile();
    init_TextFile();
    init_node();
  }
});

// server/database/Database.js
var require_Database = __commonJS({
  "server/database/Database.js"(exports2, module2) {
    var { Low: Low2 } = (init_lib(), __toCommonJS(lib_exports));
    var { JSONFile: JSONFile2 } = (init_node2(), __toCommonJS(node_exports));
    var fs = require("fs");
    var path2 = require("path");
    var DatabaseManager2 = class {
      constructor() {
        this.db = null;
        this.dbPath = path2.join(__dirname, "steel_system.json");
        this.backupDir = path2.join(__dirname, "backups");
      }
      /**
       * 初始化数据库连接
       */
      async init() {
        try {
          console.log("\u{1F5C4}\uFE0F \u6B63\u5728\u521D\u59CB\u5316JSON\u6570\u636E\u5E93...");
          if (!fs.existsSync(this.backupDir)) {
            fs.mkdirSync(this.backupDir, { recursive: true });
          }
          const adapter = new JSONFile2(this.dbPath);
          this.db = new Low2(adapter, this.getDefaultData());
          await this.db.read();
          if (!fs.existsSync(this.dbPath)) {
            await this.save();
          }
          console.log("\u2705 JSON\u6570\u636E\u5E93\u521D\u59CB\u5316\u6210\u529F");
          console.log(`\u{1F4CD} \u6570\u636E\u5E93\u6587\u4EF6\u4F4D\u7F6E: ${this.dbPath}`);
          return true;
        } catch (error) {
          console.error("\u274C \u6570\u636E\u5E93\u521D\u59CB\u5316\u5931\u8D25:", error);
          return false;
        }
      }
      /**
       * 获取默认数据结构
       */
      getDefaultData() {
        return {
          designSteels: [],
          moduleSteels: [
            {
              id: "default_1",
              name: "12\u7C73\u6807\u51C6\u94A2\u6750",
              length: 12e3,
              createdAt: (/* @__PURE__ */ new Date()).toISOString(),
              updatedAt: (/* @__PURE__ */ new Date()).toISOString()
            },
            {
              id: "default_2",
              name: "9\u7C73\u6807\u51C6\u94A2\u6750",
              length: 9e3,
              createdAt: (/* @__PURE__ */ new Date()).toISOString(),
              updatedAt: (/* @__PURE__ */ new Date()).toISOString()
            },
            {
              id: "default_3",
              name: "6\u7C73\u6807\u51C6\u94A2\u6750",
              length: 6e3,
              createdAt: (/* @__PURE__ */ new Date()).toISOString(),
              updatedAt: (/* @__PURE__ */ new Date()).toISOString()
            }
          ],
          optimizationTasks: [],
          systemStats: {
            totalOptimizations: 0,
            totalDesignSteels: 0,
            totalModuleSteels: 3,
            totalSavedCost: 0,
            lastUpdated: (/* @__PURE__ */ new Date()).toISOString()
          },
          operationLogs: [],
          settings: {
            autoBackup: true,
            maxLogEntries: 1e3,
            maxBackups: 10
          }
        };
      }
      /**
       * 获取数据库连接
       */
      getConnection() {
        if (!this.db) {
          throw new Error("\u6570\u636E\u5E93\u672A\u521D\u59CB\u5316\uFF0C\u8BF7\u5148\u8C03\u7528 init() \u65B9\u6CD5");
        }
        return this.db;
      }
      /**
       * 保存数据到文件
       */
      async save() {
        try {
          await this.db.write();
          return true;
        } catch (error) {
          console.error("\u4FDD\u5B58\u6570\u636E\u5931\u8D25:", error);
          return false;
        }
      }
      /**
       * 重新加载数据
       */
      async reload() {
        try {
          await this.db.read();
          return true;
        } catch (error) {
          console.error("\u91CD\u65B0\u52A0\u8F7D\u6570\u636E\u5931\u8D25:", error);
          return false;
        }
      }
      /**
       * 获取数据库统计信息
       */
      getStats() {
        try {
          const data = this.db.data;
          const stats = {
            designSteels: data.designSteels?.length || 0,
            moduleSteels: data.moduleSteels?.length || 0,
            optimizationTasks: data.optimizationTasks?.length || 0,
            completedTasks: data.optimizationTasks?.filter((task) => task.status === "completed")?.length || 0,
            operationLogs: data.operationLogs?.length || 0,
            databaseSize: this.getDatabaseSize(),
            lastUpdated: data.systemStats?.lastUpdated || (/* @__PURE__ */ new Date()).toISOString()
          };
          return stats;
        } catch (error) {
          console.error("\u83B7\u53D6\u6570\u636E\u5E93\u7EDF\u8BA1\u4FE1\u606F\u5931\u8D25:", error);
          return null;
        }
      }
      /**
       * 获取数据库文件大小
       */
      getDatabaseSize() {
        try {
          const stats = fs.statSync(this.dbPath);
          const sizeInBytes = stats.size;
          const sizeInKB = (sizeInBytes / 1024).toFixed(2);
          return `${sizeInKB} KB`;
        } catch (error) {
          return "\u672A\u77E5";
        }
      }
      /**
       * 备份数据库
       */
      async backup(backupPath) {
        try {
          if (!backupPath) {
            const timestamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
            backupPath = path2.join(this.backupDir, `backup_${timestamp}.json`);
          }
          await this.db.read();
          fs.copyFileSync(this.dbPath, backupPath);
          console.log(`\u2705 \u6570\u636E\u5E93\u5907\u4EFD\u6210\u529F: ${backupPath}`);
          this.cleanOldBackups();
          return backupPath;
        } catch (error) {
          console.error("\u274C \u6570\u636E\u5E93\u5907\u4EFD\u5931\u8D25:", error);
          throw error;
        }
      }
      /**
       * 清理旧备份文件
       */
      cleanOldBackups() {
        try {
          const files = fs.readdirSync(this.backupDir).filter((file) => file.startsWith("backup_") && file.endsWith(".json")).map((file) => ({
            name: file,
            path: path2.join(this.backupDir, file),
            time: fs.statSync(path2.join(this.backupDir, file)).mtime
          })).sort((a, b) => b.time - a.time);
          const maxBackups = this.db.data.settings?.maxBackups || 10;
          if (files.length > maxBackups) {
            const filesToDelete = files.slice(maxBackups);
            filesToDelete.forEach((file) => {
              fs.unlinkSync(file.path);
              console.log(`\u{1F5D1}\uFE0F \u5220\u9664\u65E7\u5907\u4EFD: ${file.name}`);
            });
          }
        } catch (error) {
          console.error("\u6E05\u7406\u65E7\u5907\u4EFD\u5931\u8D25:", error);
        }
      }
      /**
       * 记录操作日志
       */
      async logOperation(type, description, details = null, req = null) {
        try {
          const log = {
            id: Date.now().toString(),
            operationType: type,
            description,
            details,
            ipAddress: req ? req.ip || req.connection.remoteAddress : null,
            userAgent: req ? req.get("User-Agent") : null,
            createdAt: (/* @__PURE__ */ new Date()).toISOString()
          };
          this.db.data.operationLogs.push(log);
          const maxLogs = this.db.data.settings?.maxLogEntries || 1e3;
          if (this.db.data.operationLogs.length > maxLogs) {
            this.db.data.operationLogs = this.db.data.operationLogs.slice(-maxLogs);
          }
          await this.save();
        } catch (error) {
          console.error("\u8BB0\u5F55\u64CD\u4F5C\u65E5\u5FD7\u5931\u8D25:", error);
        }
      }
      /**
       * 更新系统统计
       */
      async updateSystemStats(updates) {
        try {
          this.db.data.systemStats = {
            ...this.db.data.systemStats,
            ...updates,
            lastUpdated: (/* @__PURE__ */ new Date()).toISOString()
          };
          await this.save();
        } catch (error) {
          console.error("\u66F4\u65B0\u7CFB\u7EDF\u7EDF\u8BA1\u5931\u8D25:", error);
        }
      }
      /**
       * 设计钢材CRUD操作
       */
      async saveDesignSteels(steels) {
        try {
          this.db.data.designSteels = steels.map((steel) => ({
            ...steel,
            updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
            createdAt: steel.createdAt || (/* @__PURE__ */ new Date()).toISOString()
          }));
          await this.updateSystemStats({
            totalDesignSteels: steels.length
          });
          await this.save();
          return true;
        } catch (error) {
          console.error("\u4FDD\u5B58\u8BBE\u8BA1\u94A2\u6750\u5931\u8D25:", error);
          return false;
        }
      }
      getDesignSteels() {
        return this.db.data.designSteels || [];
      }
      /**
       * 模数钢材CRUD操作
       */
      async saveModuleSteels(steels) {
        try {
          this.db.data.moduleSteels = steels.map((steel) => ({
            ...steel,
            updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
            createdAt: steel.createdAt || (/* @__PURE__ */ new Date()).toISOString()
          }));
          await this.updateSystemStats({
            totalModuleSteels: steels.length
          });
          await this.save();
          return true;
        } catch (error) {
          console.error("\u4FDD\u5B58\u6A21\u6570\u94A2\u6750\u5931\u8D25:", error);
          return false;
        }
      }
      getModuleSteels() {
        return this.db.data.moduleSteels || [];
      }
      /**
       * 优化任务CRUD操作
       */
      async saveOptimizationTask(task) {
        try {
          const existingIndex = this.db.data.optimizationTasks.findIndex((t) => t.id === task.id);
          const taskWithTimestamp = {
            ...task,
            updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
            createdAt: task.createdAt || (/* @__PURE__ */ new Date()).toISOString()
          };
          if (existingIndex >= 0) {
            this.db.data.optimizationTasks[existingIndex] = taskWithTimestamp;
          } else {
            this.db.data.optimizationTasks.push(taskWithTimestamp);
          }
          if (task.status === "completed") {
            const completedCount = this.db.data.optimizationTasks.filter((t) => t.status === "completed").length;
            await this.updateSystemStats({
              totalOptimizations: completedCount
            });
          }
          await this.save();
          return true;
        } catch (error) {
          console.error("\u4FDD\u5B58\u4F18\u5316\u4EFB\u52A1\u5931\u8D25:", error);
          return false;
        }
      }
      getOptimizationTasks() {
        return this.db.data.optimizationTasks || [];
      }
      getOptimizationTask(id) {
        return this.db.data.optimizationTasks?.find((task) => task.id === id) || null;
      }
      /**
       * 创建新的优化任务
       */
      async createOptimizationTask(taskData) {
        try {
          const taskId = `task_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
          const newTask = {
            id: taskId,
            status: "pending",
            progress: 0,
            message: "\u4EFB\u52A1\u5DF2\u521B\u5EFA\uFF0C\u7B49\u5F85\u6267\u884C",
            results: null,
            error: null,
            executionTime: 0,
            startTime: (/* @__PURE__ */ new Date()).toISOString(),
            endTime: null,
            inputData: {
              designSteelsCount: taskData.designSteels?.length || 0,
              moduleSteelsCount: taskData.moduleSteels?.length || 0,
              constraints: taskData.constraints || {}
            },
            createdAt: (/* @__PURE__ */ new Date()).toISOString(),
            updatedAt: (/* @__PURE__ */ new Date()).toISOString()
          };
          this.db.data.optimizationTasks.push(newTask);
          await this.save();
          console.log(`\u2705 \u521B\u5EFA\u4F18\u5316\u4EFB\u52A1: ${taskId}`);
          return taskId;
        } catch (error) {
          console.error("\u521B\u5EFA\u4F18\u5316\u4EFB\u52A1\u5931\u8D25:", error);
          throw error;
        }
      }
      /**
       * 更新任务状态
       */
      async updateTaskStatus(taskId, status, updates = {}) {
        try {
          const taskIndex = this.db.data.optimizationTasks.findIndex((t) => t.id === taskId);
          if (taskIndex === -1) {
            throw new Error(`\u4EFB\u52A1\u4E0D\u5B58\u5728: ${taskId}`);
          }
          const task = this.db.data.optimizationTasks[taskIndex];
          this.db.data.optimizationTasks[taskIndex] = {
            ...task,
            status,
            updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
            ...updates
          };
          if (status === "completed" || status === "failed") {
            this.db.data.optimizationTasks[taskIndex].endTime = (/* @__PURE__ */ new Date()).toISOString();
            const startTime = new Date(task.startTime).getTime();
            const endTime = Date.now();
            this.db.data.optimizationTasks[taskIndex].executionTime = endTime - startTime;
          }
          await this.save();
          console.log(`\u{1F4DD} \u4EFB\u52A1\u72B6\u6001\u66F4\u65B0: ${taskId} -> ${status}`);
          return true;
        } catch (error) {
          console.error("\u66F4\u65B0\u4EFB\u52A1\u72B6\u6001\u5931\u8D25:", error);
          return false;
        }
      }
      /**
       * 更新任务进度
       */
      async updateTaskProgress(taskId, progress, message = "") {
        try {
          const taskIndex = this.db.data.optimizationTasks.findIndex((t) => t.id === taskId);
          if (taskIndex === -1) {
            console.warn(`\u4EFB\u52A1\u4E0D\u5B58\u5728: ${taskId}`);
            return false;
          }
          this.db.data.optimizationTasks[taskIndex].progress = progress;
          this.db.data.optimizationTasks[taskIndex].message = message;
          this.db.data.optimizationTasks[taskIndex].updatedAt = (/* @__PURE__ */ new Date()).toISOString();
          await this.save();
          console.log(`\u{1F4CA} \u4EFB\u52A1\u8FDB\u5EA6\u66F4\u65B0: ${taskId} -> ${progress}% (${message})`);
          return true;
        } catch (error) {
          console.error("\u66F4\u65B0\u4EFB\u52A1\u8FDB\u5EA6\u5931\u8D25:", error);
          return false;
        }
      }
      /**
       * 设置任务结果
       */
      async setTaskResults(taskId, results) {
        try {
          let resultsToSave = results;
          if (typeof results !== "object" || results === null) {
            resultsToSave = { value: results };
          }
          return await this.updateTaskStatus(taskId, "completed", {
            results: JSON.stringify(resultsToSave),
            progress: 100,
            message: resultsToSave.success ? "\u4F18\u5316\u5B8C\u6210" : "\u4F18\u5316\u5B8C\u6210\u4F46\u6709\u8B66\u544A"
          });
        } catch (error) {
          console.error("\u8BBE\u7F6E\u4EFB\u52A1\u7ED3\u679C\u5931\u8D25:", error);
          console.error("\u5931\u8D25\u7684\u7ED3\u679C\u6570\u636E\u7C7B\u578B:", typeof results);
          return false;
        }
      }
      /**
       * 设置任务错误
       */
      async setTaskError(taskId, error) {
        try {
          let errorMessage = "\u672A\u77E5\u9519\u8BEF";
          let errorDetails = null;
          if (error && typeof error === "object") {
            errorMessage = error.message || "\u672A\u77E5\u9519\u8BEF";
            errorDetails = {
              message: error.message,
              stack: error.stack,
              timestamp: error.timestamp || (/* @__PURE__ */ new Date()).toISOString(),
              // 保留其他可能的错误属性
              ...Object.fromEntries(
                Object.entries(error).filter(([key]) => !["message", "stack", "timestamp"].includes(key))
              )
            };
          } else {
            errorMessage = String(error);
          }
          return await this.updateTaskStatus(taskId, "failed", {
            error: errorMessage,
            errorDetails,
            message: `\u4F18\u5316\u5931\u8D25: ${errorMessage}`
          });
        } catch (dbError) {
          console.error("\u8BBE\u7F6E\u4EFB\u52A1\u9519\u8BEF\u5931\u8D25:", dbError);
          try {
            await this.updateTaskStatus(taskId, "failed", {
              error: "\u8BB0\u5F55\u8BE6\u7EC6\u9519\u8BEF\u5931\u8D25",
              message: "\u4F18\u5316\u5931\u8D25\u4E14\u65E0\u6CD5\u8BB0\u5F55\u8BE6\u7EC6\u9519\u8BEF"
            });
          } catch (finalError) {
            console.error("\u6700\u540E\u5C1D\u8BD5\u66F4\u65B0\u4EFB\u52A1\u72B6\u6001\u4E5F\u5931\u8D25:", finalError);
          }
          return false;
        }
      }
      /**
       * 获取活跃任务（正在执行的任务）
       */
      getActiveTasks() {
        return this.db.data.optimizationTasks?.filter(
          (task) => task.status === "pending" || task.status === "running"
        ) || [];
      }
      /**
       * 清理过期任务（超过24小时的已完成任务）
       */
      async cleanupExpiredTasks() {
        try {
          const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1e3).toISOString();
          const beforeCount = this.db.data.optimizationTasks.length;
          this.db.data.optimizationTasks = this.db.data.optimizationTasks.filter((task) => {
            return task.status === "pending" || task.status === "running" || task.updatedAt > oneDayAgo;
          });
          const afterCount = this.db.data.optimizationTasks.length;
          const cleanedCount = beforeCount - afterCount;
          if (cleanedCount > 0) {
            await this.save();
            console.log(`\u{1F9F9} \u6E05\u7406\u4E86 ${cleanedCount} \u4E2A\u8FC7\u671F\u4EFB\u52A1`);
          }
          return cleanedCount;
        } catch (error) {
          console.error("\u6E05\u7406\u8FC7\u671F\u4EFB\u52A1\u5931\u8D25:", error);
          return 0;
        }
      }
      /**
       * 获取操作日志
       */
      getOperationLogs(limit = 100) {
        const logs = this.db.data.operationLogs || [];
        return logs.slice(-limit).reverse();
      }
      /**
       * 导出数据
       */
      async exportData() {
        try {
          await this.db.read();
          return {
            exportTime: (/* @__PURE__ */ new Date()).toISOString(),
            version: "3.0.0",
            data: this.db.data
          };
        } catch (error) {
          console.error("\u5BFC\u51FA\u6570\u636E\u5931\u8D25:", error);
          return null;
        }
      }
      /**
       * 导入数据
       */
      async importData(data) {
        try {
          await this.backup();
          if (!data.data || typeof data.data !== "object") {
            throw new Error("\u65E0\u6548\u7684\u6570\u636E\u683C\u5F0F");
          }
          this.db.data = {
            ...this.getDefaultData(),
            ...data.data
          };
          await this.save();
          console.log("\u2705 \u6570\u636E\u5BFC\u5165\u6210\u529F");
          return true;
        } catch (error) {
          console.error("\u274C \u6570\u636E\u5BFC\u5165\u5931\u8D25:", error);
          return false;
        }
      }
    };
    var databaseManager = new DatabaseManager2();
    module2.exports = databaseManager;
  }
});

// netlify/functions/task.js
var DatabaseManager = require_Database();
exports.handler = async (event, context) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, POST, DELETE, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  const db = DatabaseManager;
  await db.init();
  try {
    switch (event.httpMethod) {
      case "GET":
        const taskId = event.path.split("/").pop();
        if (!taskId || taskId === "task") {
          const allTasks = db.getOptimizationTasks();
          const activeTasks = allTasks.filter(
            (task2) => task2.status === "pending" || task2.status === "running"
          ).sort(
            (a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
          );
          const formattedTasks = activeTasks.map(formatTaskResponse);
          return {
            statusCode: 200,
            headers,
            body: JSON.stringify({ tasks: formattedTasks })
          };
        }
        const task = db.getOptimizationTask(taskId);
        if (!task) {
          return {
            statusCode: 404,
            headers,
            body: JSON.stringify({
              error: "Task not found",
              success: false
            })
          };
        }
        const formattedTask = formatTaskResponse(task);
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify(formattedTask)
        };
      case "POST":
        const data = JSON.parse(event.body);
        const taskData = {
          designSteels: data.designSteels || (data.input_data ? JSON.parse(data.input_data).designSteels : null),
          moduleSteels: data.moduleSteels || (data.input_data ? JSON.parse(data.input_data).moduleSteels : []),
          constraints: data.constraints || (data.input_data ? JSON.parse(data.input_data).constraints : null),
          options: data.options || {}
        };
        if (!taskData.designSteels || !taskData.constraints) {
          return {
            statusCode: 400,
            headers,
            body: JSON.stringify({
              error: "Missing required data",
              success: false
            })
          };
        }
        const newTaskId = await db.createOptimizationTask(taskData);
        return {
          statusCode: 201,
          headers,
          body: JSON.stringify({
            success: true,
            taskId: newTaskId,
            status: "pending",
            message: "\u4F18\u5316\u4EFB\u52A1\u5DF2\u521B\u5EFA\uFF0C\u8BF7\u901A\u8FC7taskId\u67E5\u8BE2\u8FDB\u5EA6"
          })
        };
      case "DELETE":
        const cancelTaskId = event.path.split("/").pop();
        const taskToCancel = db.getOptimizationTask(cancelTaskId);
        if (!taskToCancel || taskToCancel.status !== "pending" && taskToCancel.status !== "running") {
          return {
            statusCode: 400,
            headers,
            body: JSON.stringify({
              error: "Task cannot be cancelled",
              success: false
            })
          };
        }
        await db.updateTaskStatus(cancelTaskId, "cancelled", {
          message: "\u4EFB\u52A1\u5DF2\u53D6\u6D88"
        });
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({
            success: true,
            message: "Task cancelled"
          })
        };
      default:
        return {
          statusCode: 405,
          headers,
          body: JSON.stringify({
            error: "Method not allowed",
            success: false
          })
        };
    }
  } catch (error) {
    console.error("\u274C Task error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Task operation failed",
        message: error.message,
        success: false
      })
    };
  }
};
function formatTaskResponse(task) {
  try {
    return {
      id: task.id,
      status: task.status,
      progress: task.progress || 0,
      message: task.message || "",
      // 尝试解析results字段，如果存在且是JSON字符串
      results: task.results ? typeof task.results === "string" ? JSON.parse(task.results) : task.results : null,
      error: task.error || null,
      createdAt: task.createdAt,
      updatedAt: task.updatedAt
    };
  } catch (error) {
    console.error("\u274C Error formatting task response:", error);
    return {
      id: task.id,
      status: task.status || "unknown",
      progress: 0,
      message: "\u4EFB\u52A1\u6570\u636E\u89E3\u6790\u5931\u8D25",
      results: null,
      error: error.message,
      createdAt: task.createdAt,
      updatedAt: task.updatedAt
    };
  }
}
