var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// api/types/index.js
var require_types = __commonJS({
  "api/types/index.js"(exports2, module2) {
    var DesignSteel = class {
      constructor({
        id,
        length,
        quantity,
        crossSection,
        displayId = "",
        componentNumber = "",
        specification = "",
        partNumber = ""
      }) {
        this.id = id;
        this.length = length;
        this.quantity = quantity;
        this.crossSection = crossSection;
        this.displayId = displayId;
        this.componentNumber = componentNumber;
        this.specification = specification;
        this.partNumber = partNumber;
      }
    };
    var ModuleSteel = class {
      constructor({ id, name, length }) {
        this.id = id;
        this.name = name;
        this.length = length;
      }
    };
    var RemainderV3 = class {
      constructor({
        id,
        length,
        type = "pending",
        // 'pseudo' | 'real' | 'waste' | 'pending'
        isConsumed = false,
        sourceChain = [],
        crossSection,
        createdAt = (/* @__PURE__ */ new Date()).toISOString(),
        consumedAt = null,
        originalLength = null,
        parentId = null
      }) {
        this.id = id;
        this.length = length;
        this.type = type;
        this.isConsumed = isConsumed;
        this.sourceChain = sourceChain;
        this.crossSection = crossSection;
        this.createdAt = createdAt;
        this.consumedAt = consumedAt;
        this.originalLength = originalLength;
        this.parentId = parentId;
      }
      /**
       * 标记为伪余料（已被使用）
       */
      markAsPseudo() {
        this.type = "pseudo";
        this.isConsumed = true;
        this.consumedAt = (/* @__PURE__ */ new Date()).toISOString();
      }
      /**
       * 标记为真余料（未使用，计入损耗）
       */
      markAsReal() {
        this.type = "real";
        this.isConsumed = false;
      }
      /**
       * 标记为废料
       */
      markAsWaste() {
        this.type = "waste";
      }
    };
    var OptimizationConstraints = class {
      constructor({
        wasteThreshold = 600,
        targetLossRate = 5,
        timeLimit = 300,
        maxWeldingSegments = 1,
        // 保留V3动态焊接约束参数以保持兼容性
        weldingSegments = null,
        // 向后兼容
        maxIterations = 1e3,
        allowDynamicWelding = true,
        minWeldingSegments = 1,
        weldingCostPerSegment = 0.1,
        weldingTimePerSegment = 5
      } = {}) {
        this.wasteThreshold = wasteThreshold;
        this.targetLossRate = targetLossRate;
        this.timeLimit = timeLimit;
        this.maxWeldingSegments = maxWeldingSegments;
        if (weldingSegments !== null) {
          this.maxWeldingSegments = weldingSegments;
        }
        this.weldingSegments = this.maxWeldingSegments;
        this.allowDynamicWelding = allowDynamicWelding;
        this.minWeldingSegments = minWeldingSegments;
        this.weldingCostPerSegment = weldingCostPerSegment;
        this.weldingTimePerSegment = weldingTimePerSegment;
        this.maxIterations = maxIterations;
        this.validateBasicConstraints();
      }
      /**
       * V3.1 修复：基础约束验证（更宽松的验证逻辑）
       * 严格验证由约束配置中心统一处理
       */
      validateBasicConstraints() {
        if (this.wasteThreshold <= 0) {
          throw new Error(`\u5E9F\u6599\u9608\u503C${this.wasteThreshold}\u5FC5\u987B\u5927\u4E8E0`);
        }
        if (this.maxWeldingSegments < 1) {
          throw new Error(`\u6700\u5927\u710A\u63A5\u6BB5\u6570${this.maxWeldingSegments}\u4E0D\u80FD\u5C0F\u4E8E1`);
        }
        if (this.timeLimit <= 0) {
          throw new Error(`\u65F6\u95F4\u9650\u5236${this.timeLimit}\u5FC5\u987B\u5927\u4E8E0`);
        }
        if (this.maxWeldingSegments > 10) {
          console.warn(`\u26A0\uFE0F \u710A\u63A5\u6BB5\u6570${this.maxWeldingSegments}\u8F83\u5927\uFF0C\u53EF\u80FD\u5F71\u54CD\u4F18\u5316\u6548\u679C`);
        }
      }
      /**
       * V3新增：动态设置焊接段数
       */
      setWeldingSegments(segments) {
        if (segments < this.minWeldingSegments || segments > this.maxWeldingSegments) {
          throw new Error(`\u710A\u63A5\u6BB5\u6570${segments}\u8D85\u51FA\u5141\u8BB8\u8303\u56F4[${this.minWeldingSegments}, ${this.maxWeldingSegments}]`);
        }
        this.weldingSegments = segments;
        console.log(`\u{1F527} \u52A8\u6001\u8BBE\u7F6E\u710A\u63A5\u7EA6\u675F: \u5141\u8BB8${segments}\u6BB5\u710A\u63A5`);
      }
      /**
       * V3新增：计算焊接成本
       */
      calculateWeldingCost(segments) {
        if (segments <= 1) return 0;
        return (segments - 1) * this.weldingCostPerSegment;
      }
      /**
       * V3新增：计算焊接时间成本
       */
      calculateWeldingTime(segments) {
        if (segments <= 1) return 0;
        return (segments - 1) * this.weldingTimePerSegment;
      }
      /**
       * V3新增：获取焊接约束信息
       */
      getWeldingConstraintInfo() {
        return {
          current: this.weldingSegments,
          min: this.minWeldingSegments,
          max: this.maxWeldingSegments,
          allowDynamic: this.allowDynamicWelding,
          costPerSegment: this.weldingCostPerSegment,
          timePerSegment: this.weldingTimePerSegment
        };
      }
      /**
       * 验证焊接段数约束的可行性
       * 检查设计钢材长度是否超出模数钢材能力范围
       */
      validateWeldingConstraint(designSteels, moduleSteels) {
        const maxModuleLength = Math.max(...moduleSteels.map((m) => m.length));
        const conflictSteels = designSteels.filter((d) => d.length > maxModuleLength);
        if (conflictSteels.length > 0 && this.maxWeldingSegments === 1) {
          return {
            isValid: false,
            conflicts: conflictSteels,
            maxModuleLength,
            suggestions: [
              {
                type: "addLongerModule",
                description: `\u5EFA\u8BAE\u6DFB\u52A0\u957F\u5EA6\u2265${Math.max(...conflictSteels.map((s) => s.length))}mm\u7684\u6A21\u6570\u94A2\u6750`,
                requiredLength: Math.max(...conflictSteels.map((s) => s.length))
              },
              {
                type: "increaseWelding",
                description: `\u5EFA\u8BAE\u5C06\u6700\u5927\u710A\u63A5\u6BB5\u6570\u589E\u52A0\u5230\u2265${Math.ceil(Math.max(...conflictSteels.map((s) => s.length)) / maxModuleLength)}\u6BB5`,
                requiredSegments: Math.ceil(Math.max(...conflictSteels.map((s) => s.length)) / maxModuleLength)
              }
            ]
          };
        }
        return { isValid: true, conflicts: [], suggestions: [] };
      }
      /**
       * 获取约束条件的友好显示名称
       */
      getDisplayNames() {
        return {
          wasteThreshold: "\u5E9F\u6599\u9608\u503C",
          weldingSegments: "\u710A\u63A5\u6BB5\u6570",
          maxIterations: "\u6700\u5927\u8FED\u4EE3\u6B21\u6570",
          timeLimit: "\u8BA1\u7B97\u65F6\u95F4\u9650\u5236",
          allowDynamicWelding: "\u52A8\u6001\u710A\u63A5\u7EA6\u675F",
          maxWeldingSegments: "\u6700\u5927\u710A\u63A5\u6BB5\u6570",
          minWeldingSegments: "\u6700\u5C0F\u710A\u63A5\u6BB5\u6570",
          weldingCostPerSegment: "\u6BCF\u6BB5\u710A\u63A5\u7684\u6210\u672C\u7CFB\u6570",
          weldingTimePerSegment: "\u6BCF\u6BB5\u710A\u63A5\u7684\u65F6\u95F4\u6210\u672C(\u79D2)"
        };
      }
      /**
       * 获取约束条件的详细说明
       */
      getDescriptions() {
        return {
          wasteThreshold: "\u4F59\u6599\u957F\u5EA6\u5C0F\u4E8E\u6B64\u503C\u65F6\u89C6\u4E3A\u5E9F\u6599\uFF0C\u65E0\u6CD5\u518D\u6B21\u5229\u7528",
          weldingSegments: "\u5355\u6839\u8BBE\u8BA1\u94A2\u6750\u5141\u8BB8\u7684\u710A\u63A5\u6BB5\u6570\uFF0C1\u6BB5\u8868\u793A\u4E0D\u5141\u8BB8\u710A\u63A5",
          maxIterations: "\u7B97\u6CD5\u6700\u5927\u8FED\u4EE3\u6B21\u6570\uFF0C\u8D85\u8FC7\u540E\u8FD4\u56DE\u5F53\u524D\u6700\u4F18\u89E3",
          timeLimit: "\u7B97\u6CD5\u8BA1\u7B97\u7684\u6700\u5927\u5141\u8BB8\u65F6\u95F4\uFF0C\u8D85\u65F6\u540E\u8FD4\u56DE\u5F53\u524D\u6700\u4F18\u89E3",
          allowDynamicWelding: "\u662F\u5426\u5141\u8BB8\u52A8\u6001\u8C03\u6574\u710A\u63A5\u6BB5\u6570",
          maxWeldingSegments: "\u5355\u6839\u8BBE\u8BA1\u94A2\u6750\u5141\u8BB8\u7684\u6700\u5927\u710A\u63A5\u6BB5\u6570\uFF0C1\u6BB5\u8868\u793A\u4E0D\u5141\u8BB8\u710A\u63A5",
          minWeldingSegments: "\u5355\u6839\u8BBE\u8BA1\u94A2\u6750\u5141\u8BB8\u7684\u6700\u5C0F\u710A\u63A5\u6BB5\u6570\uFF0C1\u6BB5\u8868\u793A\u4E0D\u5141\u8BB8\u710A\u63A5",
          weldingCostPerSegment: "\u6BCF\u6BB5\u710A\u63A5\u7684\u6210\u672C\u7CFB\u6570\uFF0C\u5F71\u54CD\u710A\u63A5\u6210\u672C",
          weldingTimePerSegment: "\u6BCF\u6BB5\u710A\u63A5\u7684\u65F6\u95F4\u6210\u672C(\u79D2)\uFF0C\u5F71\u54CD\u710A\u63A5\u65F6\u95F4"
        };
      }
    };
    var CuttingDetail = class {
      constructor({
        sourceType,
        // 'module' | 'remainder'
        sourceId,
        sourceLength,
        moduleType = "",
        moduleLength = 0,
        designId,
        length,
        quantity,
        remainderInfo = null,
        // 余料信息
        weldingCount = 1
        // 焊接段数
      }) {
        this.sourceType = sourceType;
        this.sourceId = sourceId;
        this.sourceLength = sourceLength;
        this.moduleType = moduleType;
        this.moduleLength = moduleLength;
        this.designId = designId;
        this.length = length;
        this.quantity = quantity;
        this.remainderInfo = remainderInfo;
        this.weldingCount = weldingCount;
      }
    };
    var CuttingPlan = class {
      constructor({
        sourceType,
        sourceId,
        sourceDescription,
        sourceLength,
        moduleType = "",
        moduleLength = 0,
        cuts = [],
        newRemainders = [],
        pseudoRemainders = [],
        // 伪余料
        realRemainders = [],
        // 真余料
        waste = 0,
        usedRemainders = []
      }) {
        this.sourceType = sourceType;
        this.sourceId = sourceId;
        this.sourceDescription = sourceDescription;
        this.sourceLength = sourceLength;
        this.moduleType = moduleType;
        this.moduleLength = moduleLength;
        this.cuts = cuts;
        this.newRemainders = newRemainders;
        this.pseudoRemainders = pseudoRemainders;
        this.realRemainders = realRemainders;
        this.waste = waste;
        this.usedRemainders = usedRemainders;
      }
    };
    var OptimizationSolution = class {
      constructor({
        cuttingPlans = [],
        totalModuleUsed = 0,
        totalWaste = 0,
        totalPseudoRemainder = 0,
        // 伪余料总长度
        totalRealRemainder = 0,
        // 真余料总长度
        details = [],
        lossRateBreakdown = {}
        // 损耗率分解
      }) {
        this.cuttingPlans = cuttingPlans;
        this.totalModuleUsed = totalModuleUsed;
        this.totalWaste = totalWaste;
        this.totalPseudoRemainder = totalPseudoRemainder;
        this.totalRealRemainder = totalRealRemainder;
        this.details = details;
        this.lossRateBreakdown = lossRateBreakdown;
      }
    };
    var OptimizationResult = class {
      constructor({
        solutions = {},
        totalLossRate = 0,
        totalModuleUsed = 0,
        totalWaste = 0,
        totalPseudoRemainder = 0,
        totalRealRemainder = 0,
        totalMaterial = 0,
        executionTime = 0,
        lossRateValidation = null,
        // 损耗率验证结果
        constraintValidation = null
        // 约束验证结果
      }) {
        this.solutions = solutions;
        this.totalLossRate = totalLossRate;
        this.totalModuleUsed = totalModuleUsed;
        this.totalWaste = totalWaste;
        this.totalPseudoRemainder = totalPseudoRemainder;
        this.totalRealRemainder = totalRealRemainder;
        this.totalMaterial = totalMaterial;
        this.executionTime = executionTime;
        this.lossRateValidation = lossRateValidation;
        this.constraintValidation = constraintValidation;
      }
    };
    module2.exports = {
      // 基础类型
      DesignSteel,
      ModuleSteel,
      RemainderV3,
      // 约束系统
      OptimizationConstraints,
      // 切割和结果
      CuttingDetail,
      CuttingPlan,
      OptimizationSolution,
      OptimizationResult,
      // 🔧 统一架构：LossRateCalculator已整合到StatisticsCalculator中
      // 计算器相关功能请使用 StatisticsCalculator
      // 常量
      REMAINDER_TYPES: {
        PENDING: "pending",
        PSEUDO: "pseudo",
        REAL: "real",
        WASTE: "waste"
      },
      SOURCE_TYPES: {
        MODULE: "module",
        REMAINDER: "remainder"
      }
    };
  }
});

// core/utils/StatisticsCalculator.js
var require_StatisticsCalculator = __commonJS({
  "core/utils/StatisticsCalculator.js"(exports2, module2) {
    var { REMAINDER_TYPES } = require_types();
    var StatisticsCalculator = class {
      constructor() {
        this.PRECISION = 4;
      }
      /**
       * 🎯 主计算方法：基于最终状态计算所有统计数据
       * 这是唯一的统计计算源，确保数据一致性
       */
      calculateAllStatistics(solutions, remainderManager) {
        console.log("\u{1F9EE} StatisticsCalculator: \u5F00\u59CB\u7EDF\u4E00\u7EDF\u8BA1\u8BA1\u7B97...");
        const finalRemainderStats = remainderManager.finalizeRemainders();
        const specificationStats = {};
        let globalStats = {
          totalModuleCount: 0,
          totalModuleLength: 0,
          totalDesignLength: 0,
          totalWaste: 0,
          totalRealRemainder: 0,
          totalPseudoRemainder: 0,
          overallLossRate: 0,
          materialUtilizationRate: 0
        };
        Object.entries(solutions).forEach(([groupKey, solution]) => {
          const specStats = this.calculateSpecificationStatistics(solution, groupKey, remainderManager);
          specificationStats[groupKey] = specStats;
          globalStats.totalModuleCount += specStats.moduleUsed;
          globalStats.totalModuleLength += specStats.totalMaterial;
          globalStats.totalDesignLength += specStats.designLength;
          globalStats.totalWaste += specStats.waste;
          globalStats.totalRealRemainder += specStats.realRemainder;
          globalStats.totalPseudoRemainder += specStats.pseudoRemainder;
        });
        if (globalStats.totalModuleLength > 0) {
          globalStats.overallLossRate = parseFloat(
            ((globalStats.totalWaste + globalStats.totalRealRemainder) / globalStats.totalModuleLength * 100).toFixed(this.PRECISION)
          );
          globalStats.materialUtilizationRate = parseFloat(
            (globalStats.totalDesignLength / globalStats.totalModuleLength * 100).toFixed(this.PRECISION)
          );
        }
        const consistencyCheck = this.validateDataConsistency(globalStats, specificationStats, finalRemainderStats);
        console.log("\u2705 StatisticsCalculator: \u7EDF\u8BA1\u8BA1\u7B97\u5B8C\u6210");
        console.log(`\u{1F4CA} \u5168\u5C40\u6C47\u603B: \u6A21\u6570${globalStats.totalModuleCount}\u6839, \u635F\u8017\u7387${globalStats.overallLossRate}%, \u5229\u7528\u7387${globalStats.materialUtilizationRate}%`);
        return {
          globalStats,
          specificationStats,
          remainderStats: finalRemainderStats,
          consistencyCheck
        };
      }
      /**
       * 🔢 计算单个规格的统计数据
       */
      calculateSpecificationStatistics(solution, groupKey, remainderManager) {
        let moduleUsed = 0;
        let totalMaterial = 0;
        let designLength = 0;
        let waste = 0;
        let realRemainder = 0;
        let pseudoRemainder = 0;
        const usedModuleIds = /* @__PURE__ */ new Set();
        console.log(`\u{1F50D} \u8BA1\u7B97 ${groupKey} \u89C4\u683C\u7EDF\u8BA1...`);
        solution.cuttingPlans?.forEach((plan) => {
          if (plan.sourceType === "module" && plan.sourceId) {
            if (!usedModuleIds.has(plan.sourceId)) {
              totalMaterial += plan.sourceLength;
              usedModuleIds.add(plan.sourceId);
            }
          }
          plan.cuts?.forEach((cut) => {
            designLength += cut.length * cut.quantity;
          });
          if (plan.waste && plan.waste > 0) {
            waste += plan.waste;
          }
        });
        moduleUsed = usedModuleIds.size;
        const remainderSpecStats = remainderManager.getSpecificationStatistics(groupKey);
        realRemainder = remainderSpecStats.realLength;
        pseudoRemainder = remainderSpecStats.pseudoRemainders;
        const lossRate = totalMaterial > 0 ? parseFloat(((waste + realRemainder) / totalMaterial * 100).toFixed(this.PRECISION)) : 0;
        const utilization = totalMaterial > 0 ? parseFloat((designLength / totalMaterial * 100).toFixed(this.PRECISION)) : 0;
        const stats = {
          groupKey,
          moduleUsed,
          totalMaterial,
          designLength,
          waste,
          realRemainder,
          pseudoRemainder,
          lossRate,
          utilization,
          cuttingPlansCount: solution.cuttingPlans?.length || 0
        };
        console.log(`  \u{1F4CB} ${groupKey}: ${moduleUsed}\u6839\u6A21\u6570, \u5E9F\u6599${waste}mm, \u771F\u4F59\u6599${realRemainder}mm, \u635F\u8017\u7387${lossRate}%`);
        return stats;
      }
      /**
       * 🔬 数据一致性验证
       */
      validateDataConsistency(globalStats, specificationStats, remainderStats) {
        const errors = [];
        const warnings = [];
        let sumModuleCount = 0;
        let sumTotalMaterial = 0;
        let sumWaste = 0;
        let sumRealRemainder = 0;
        Object.values(specificationStats).forEach((specStats) => {
          sumModuleCount += specStats.moduleUsed;
          sumTotalMaterial += specStats.totalMaterial;
          sumWaste += specStats.waste;
          sumRealRemainder += specStats.realRemainder;
        });
        const tolerance = 0.01;
        if (Math.abs(globalStats.totalModuleCount - sumModuleCount) > tolerance) {
          errors.push(`\u6A21\u6570\u94A2\u6750\u6570\u91CF\u4E0D\u4E00\u81F4: \u5168\u5C40${globalStats.totalModuleCount} vs \u89C4\u683C\u6C42\u548C${sumModuleCount}`);
        }
        if (Math.abs(globalStats.totalModuleLength - sumTotalMaterial) > tolerance) {
          errors.push(`\u6A21\u6570\u94A2\u6750\u957F\u5EA6\u4E0D\u4E00\u81F4: \u5168\u5C40${globalStats.totalModuleLength} vs \u89C4\u683C\u6C42\u548C${sumTotalMaterial}`);
        }
        if (Math.abs(globalStats.totalWaste - sumWaste) > tolerance) {
          errors.push(`\u5E9F\u6599\u7EDF\u8BA1\u4E0D\u4E00\u81F4: \u5168\u5C40${globalStats.totalWaste} vs \u89C4\u683C\u6C42\u548C${sumWaste}`);
        }
        if (Math.abs(globalStats.totalRealRemainder - sumRealRemainder) > tolerance) {
          errors.push(`\u771F\u4F59\u6599\u7EDF\u8BA1\u4E0D\u4E00\u81F4: \u5168\u5C40${globalStats.totalRealRemainder} vs \u89C4\u683C\u6C42\u548C${sumRealRemainder}`);
        }
        if (Math.abs(remainderStats.totalWaste - sumWaste) > tolerance) {
          warnings.push(`\u4F59\u6599\u7BA1\u7406\u5668\u5E9F\u6599\u7EDF\u8BA1\u4E0E\u5207\u5272\u8BA1\u5212\u4E0D\u4E00\u81F4: \u7BA1\u7406\u5668${remainderStats.totalWaste} vs \u8BA1\u5212${sumWaste}`);
        }
        if (globalStats.overallLossRate < 0 || globalStats.overallLossRate > 100) {
          errors.push(`\u635F\u8017\u7387\u8D85\u51FA\u5408\u7406\u8303\u56F4: ${globalStats.overallLossRate}%`);
        }
        if (globalStats.overallLossRate > 50) {
          warnings.push(`\u635F\u8017\u7387\u504F\u9AD8: ${globalStats.overallLossRate}%\uFF0C\u8BF7\u68C0\u67E5\u4F18\u5316\u914D\u7F6E`);
        }
        if (globalStats.materialUtilizationRate > 100) {
          errors.push(`\u6750\u6599\u5229\u7528\u7387\u8D85\u8FC7100%: ${globalStats.materialUtilizationRate}%\uFF0C\u5B58\u5728\u8BA1\u7B97\u9519\u8BEF`);
        }
        console.log(`\u{1F50D} \u6570\u636E\u4E00\u81F4\u6027\u68C0\u67E5: ${errors.length}\u4E2A\u9519\u8BEF, ${warnings.length}\u4E2A\u8B66\u544A`);
        if (errors.length > 0) {
          console.error("\u274C \u53D1\u73B0\u6570\u636E\u4E00\u81F4\u6027\u9519\u8BEF:");
          errors.forEach((error) => console.error(`  - ${error}`));
        }
        if (warnings.length > 0) {
          console.warn("\u26A0\uFE0F \u6570\u636E\u4E00\u81F4\u6027\u8B66\u544A:");
          warnings.forEach((warning) => console.warn(`  - ${warning}`));
        }
        return {
          isConsistent: errors.length === 0,
          errors,
          warnings,
          checkTime: (/* @__PURE__ */ new Date()).toISOString(),
          tolerance
        };
      }
      /**
       * 🎨 构建图表数据
       */
      buildChartData(specificationStats) {
        const colors = ["#0088FE", "#00C49F", "#FFBB28", "#FF8042", "#8884D8"];
        const lossRateData = [];
        const pieData = [];
        Object.entries(specificationStats).forEach(([groupKey, specStats], index) => {
          const [specification, crossSectionStr] = groupKey.split("_");
          const displayName = `${specification}(${crossSectionStr}mm\xB2)`;
          lossRateData.push({
            specification: displayName,
            groupKey,
            lossRate: specStats.lossRate,
            moduleUsed: specStats.moduleUsed,
            waste: specStats.waste,
            realRemainder: specStats.realRemainder,
            pseudoRemainder: specStats.pseudoRemainder,
            utilization: specStats.utilization
          });
          pieData.push({
            name: displayName,
            value: specStats.moduleUsed,
            fill: colors[index % colors.length]
          });
        });
        return { lossRateData, pieData };
      }
      /**
       * 🔢 构建模数钢材使用统计
       */
      buildModuleUsageStats(solutions) {
        const usage = {};
        let grandTotalCount = 0;
        let grandTotalLength = 0;
        Object.entries(solutions).forEach(([groupKey, solution]) => {
          const [specification, crossSectionStr] = groupKey.split("_");
          const moduleStats = {};
          let groupTotalCount = 0;
          let groupTotalLength = 0;
          const usedModules = /* @__PURE__ */ new Map();
          solution.cuttingPlans?.forEach((plan) => {
            if (plan.sourceType === "module" && plan.sourceId) {
              const length = plan.sourceLength;
              if (!usedModules.has(plan.sourceId)) {
                usedModules.set(plan.sourceId, { length, count: 1 });
              }
            }
          });
          for (const { length } of usedModules.values()) {
            if (!moduleStats[length]) {
              moduleStats[length] = { count: 0, totalLength: 0 };
            }
            moduleStats[length].count += 1;
            moduleStats[length].totalLength += length;
            groupTotalCount += 1;
            groupTotalLength += length;
          }
          usage[groupKey] = {
            specification,
            crossSection: parseInt(crossSectionStr),
            moduleBreakdown: moduleStats,
            groupTotal: { count: groupTotalCount, totalLength: groupTotalLength }
          };
          grandTotalCount += groupTotalCount;
          grandTotalLength += groupTotalLength;
        });
        return {
          bySpecification: usage,
          grandTotal: { count: grandTotalCount, totalLength: grandTotalLength }
        };
      }
      // ==================== 损耗率计算方法 ====================
      // 🔧 统一架构：整合原LossRateCalculator的所有功能
      /**
       * 🎯 计算单规格损耗率
       * 公式：(真余料+废料)/该规格模数钢材总长度*100%
       * 注意：这里直接使用统计结果，不再依赖外部计算
       */
      calculateSpecificationLossRate(specificationStats) {
        const { waste, realRemainder, totalMaterial } = specificationStats;
        if (totalMaterial === 0) return 0;
        const totalWasteAndReal = waste + realRemainder;
        return parseFloat((totalWasteAndReal / totalMaterial * 100).toFixed(this.PRECISION));
      }
      /**
       * 🎯 计算总损耗率
       * 公式：各规格真余料废料总和/各规格模数钢材总长度总和*100%
       */
      calculateTotalLossRate(allSpecificationStats) {
        let totalWasteAndReal = 0;
        let totalModuleMaterial = 0;
        Object.values(allSpecificationStats).forEach((specStats) => {
          totalWasteAndReal += specStats.waste + specStats.realRemainder;
          totalModuleMaterial += specStats.totalMaterial;
        });
        if (totalModuleMaterial === 0) return 0;
        return parseFloat((totalWasteAndReal / totalModuleMaterial * 100).toFixed(this.PRECISION));
      }
      /**
       * 🔍 验证损耗率计算正确性
       * 检查加权平均是否等于总损耗率
       */
      validateLossRateCalculation(allSpecificationStats) {
        const totalLossRate = this.calculateTotalLossRate(allSpecificationStats);
        let weightedSum = 0;
        let totalWeight = 0;
        const specResults = Object.values(allSpecificationStats).map((specStats) => {
          const specLossRate = this.calculateSpecificationLossRate(specStats);
          const weight = specStats.totalMaterial;
          weightedSum += specLossRate * weight;
          totalWeight += weight;
          return {
            lossRate: specLossRate,
            weight,
            contribution: specLossRate * weight
          };
        });
        const weightedAverage = totalWeight > 0 ? parseFloat((weightedSum / totalWeight).toFixed(this.PRECISION)) : 0;
        const difference = Math.abs(totalLossRate - weightedAverage);
        const ERROR_THRESHOLD = 0.01;
        const isValid = difference <= ERROR_THRESHOLD;
        return {
          isValid,
          totalLossRate,
          weightedAverage,
          difference,
          specResults,
          errorMessage: isValid ? null : `\u635F\u8017\u7387\u8BA1\u7B97\u5B58\u5728\u8BEF\u5DEE: ${difference.toFixed(4)}%`
        };
      }
      /**
       * 🎯 获取规格的模数钢材总长度
       * 统一架构：直接从统计结果获取，不再依赖solution对象
       */
      getSpecificationTotalMaterial(specificationStats) {
        return specificationStats.totalMaterial || 0;
      }
      /**
       * 🎯 增强的损耗率分析
       * 提供详细的损耗率分解和分析
       */
      analyzeLossRateBreakdown(allSpecificationStats) {
        const analysis = {
          totalLossRate: this.calculateTotalLossRate(allSpecificationStats),
          specificationBreakdown: {},
          summary: {
            highLossSpecs: [],
            lowLossSpecs: [],
            averageLossRate: 0,
            totalMaterial: 0,
            totalWaste: 0,
            totalRealRemainder: 0
          }
        };
        let totalMaterial = 0;
        let totalWaste = 0;
        let totalRealRemainder = 0;
        let totalLossRateSum = 0;
        let specCount = 0;
        Object.entries(allSpecificationStats).forEach(([groupKey, specStats]) => {
          const specLossRate = this.calculateSpecificationLossRate(specStats);
          const contribution = specStats.totalMaterial / Object.values(allSpecificationStats).reduce((sum, s) => sum + s.totalMaterial, 0) * 100;
          analysis.specificationBreakdown[groupKey] = {
            lossRate: specLossRate,
            waste: specStats.waste,
            realRemainder: specStats.realRemainder,
            totalMaterial: specStats.totalMaterial,
            contribution: parseFloat(contribution.toFixed(2)),
            efficiency: parseFloat((100 - specLossRate).toFixed(2))
          };
          if (specLossRate > 10) {
            analysis.summary.highLossSpecs.push({ groupKey, lossRate: specLossRate });
          } else if (specLossRate < 3) {
            analysis.summary.lowLossSpecs.push({ groupKey, lossRate: specLossRate });
          }
          totalMaterial += specStats.totalMaterial;
          totalWaste += specStats.waste;
          totalRealRemainder += specStats.realRemainder;
          totalLossRateSum += specLossRate;
          specCount++;
        });
        analysis.summary.averageLossRate = specCount > 0 ? parseFloat((totalLossRateSum / specCount).toFixed(this.PRECISION)) : 0;
        analysis.summary.totalMaterial = totalMaterial;
        analysis.summary.totalWaste = totalWaste;
        analysis.summary.totalRealRemainder = totalRealRemainder;
        return analysis;
      }
    };
    module2.exports = StatisticsCalculator;
  }
});

// core/optimizer/ResultBuilder.js
var require_ResultBuilder = __commonJS({
  "core/optimizer/ResultBuilder.js"(exports2, module2) {
    var StatisticsCalculator = require_StatisticsCalculator();
    var ResultBuilder = class {
      constructor() {
        this.statisticsCalculator = new StatisticsCalculator();
      }
      /**
       * 构建完整的优化结果
       * 使用统一的StatisticsCalculator进行所有计算
       */
      buildCompleteResult(solutions, designSteels, moduleSteels, remainderManager, executionTime = 0) {
        console.log("\u{1F3D7}\uFE0F ResultBuilder: \u5F00\u59CB\u6784\u5EFA\u5B8C\u6574\u7ED3\u679C...");
        const statisticsResult = this.statisticsCalculator.calculateAllStatistics(solutions, remainderManager);
        const { globalStats, specificationStats, remainderStats, consistencyCheck } = statisticsResult;
        Object.entries(solutions).forEach(([groupKey, solution]) => {
          const specStats = specificationStats[groupKey];
          if (specStats) {
            solution.totalMaterial = specStats.totalMaterial;
            solution.totalRealRemainder = specStats.realRemainder;
            solution.totalWaste = specStats.waste;
            solution.lossRate = specStats.lossRate;
            console.log(`\u{1F527} \u8BBE\u7F6E ${groupKey} \u7684 totalMaterial: ${specStats.totalMaterial}mm`);
          }
        });
        const chartData = this.statisticsCalculator.buildChartData(specificationStats);
        const requirementValidation = this.buildRequirementValidation(solutions, designSteels);
        const moduleUsageStats = this.statisticsCalculator.buildModuleUsageStats(solutions);
        const specificationDetails = this.buildSpecificationDetails(specificationStats);
        const result = {
          // 原有字段保持兼容性
          solutions,
          totalModuleUsed: globalStats.totalModuleCount,
          totalMaterial: globalStats.totalModuleLength,
          totalWaste: globalStats.totalWaste,
          totalRealRemainder: globalStats.totalRealRemainder,
          totalPseudoRemainder: globalStats.totalPseudoRemainder,
          totalLossRate: globalStats.overallLossRate,
          executionTime,
          // 新增的完整数据结构，前端直接使用
          completeStats: {
            global: globalStats,
            chartData,
            requirementValidation,
            moduleUsageStats,
            specificationDetails,
            remainderStats,
            consistencyCheck
          }
        };
        console.log(`\u2705 ResultBuilder: \u7ED3\u679C\u6784\u5EFA\u5B8C\u6210`);
        console.log(`\u{1F4CA} \u5168\u5C40\u7EDF\u8BA1: \u6A21\u6570\u94A2\u6750${globalStats.totalModuleCount}\u6839, \u635F\u8017\u7387${globalStats.overallLossRate}%`);
        if (!consistencyCheck.isConsistent) {
          console.warn("\u26A0\uFE0F ResultBuilder: \u6570\u636E\u4E00\u81F4\u6027\u68C0\u67E5\u5931\u8D25:", consistencyCheck.errors);
        }
        return result;
      }
      /**
       * 构建需求验证数据
       * 验证所有设计钢材需求是否得到满足
       */
      buildRequirementValidation(solutions, designSteels) {
        const validation = [];
        let allSatisfied = true;
        designSteels.forEach((steel) => {
          let produced = 0;
          Object.values(solutions).forEach((solution) => {
            solution.cuttingPlans?.forEach((plan) => {
              plan.cuts?.forEach((cut) => {
                if (cut.designId === steel.id) {
                  produced += cut.quantity;
                }
              });
            });
          });
          const satisfied = produced >= steel.quantity;
          if (!satisfied) allSatisfied = false;
          validation.push({
            key: steel.id,
            id: steel.displayId || steel.id,
            specification: steel.specification || "\u672A\u77E5\u89C4\u683C",
            crossSection: steel.crossSection,
            length: steel.length,
            quantity: steel.quantity,
            produced,
            satisfied,
            difference: produced - steel.quantity,
            groupKey: steel.groupKey,
            satisfactionRate: steel.quantity > 0 ? parseFloat((produced / steel.quantity * 100).toFixed(this.PRECISION)) : 0
          });
        });
        return {
          items: validation,
          summary: {
            total: validation.length,
            satisfied: validation.filter((item) => item.satisfied).length,
            unsatisfied: validation.filter((item) => !item.satisfied).length,
            allSatisfied,
            overallSatisfactionRate: validation.length > 0 ? parseFloat((validation.filter((item) => item.satisfied).length / validation.length * 100).toFixed(this.PRECISION)) : 0
          }
        };
      }
      /**
       * 构建规格级别的详细统计
       * 使用StatisticsCalculator计算的数据
       */
      buildSpecificationDetails(specificationStats) {
        const details = {};
        Object.entries(specificationStats).forEach(([groupKey, specStats]) => {
          const [specification, crossSectionStr] = groupKey.split("_");
          details[groupKey] = {
            specification,
            crossSection: parseInt(crossSectionStr),
            displayName: `${specification}(${crossSectionStr}mm\xB2)`,
            stats: {
              moduleUsed: specStats.moduleUsed,
              totalMaterial: specStats.totalMaterial,
              designLength: specStats.designLength,
              waste: specStats.waste,
              realRemainder: specStats.realRemainder,
              pseudoRemainder: specStats.pseudoRemainder,
              lossRate: specStats.lossRate,
              utilization: specStats.utilization
            },
            cuttingPlansCount: specStats.cuttingPlansCount
          };
        });
        return details;
      }
    };
    module2.exports = ResultBuilder;
  }
});

// core/config/ConstraintConfig.js
var require_ConstraintConfig = __commonJS({
  "core/config/ConstraintConfig.js"(exports2, module2) {
    var DEFAULT_CONSTRAINTS = {
      wasteThreshold: 600,
      // 废料阈值 (mm) - 余料长度小于此值时视为废料，默认值600mm
      targetLossRate: 5,
      // 目标损耗率 (%) - 优化目标参考值（软约束）
      timeLimit: 3e5,
      // 计算时间限制 (ms) - 算法最大运行时间 = 300秒
      maxWeldingSegments: 1
      // 最大焊接段数 (段) - 单根设计钢材允许的最大焊接段数
    };
    var VALIDATION_LIMITS = {
      wasteThreshold: {
        min: 100,
        // 最小废料阈值 (mm) - 必须≥100mm
        max: 2e3,
        // 最大废料阈值 (mm) - 放宽上限
        recommended: {
          min: 100,
          // 推荐最小值
          max: 1e3
          // 推荐最大值
        }
      },
      targetLossRate: {
        min: 0,
        // 最小损耗率 (%)
        max: 100,
        // 最大损耗率 (%)
        recommended: {
          min: 2,
          // 推荐最小值
          max: 15
          // 推荐最大值
        }
      },
      timeLimit: {
        min: 1e3,
        // 最小时间限制 (ms) = 1秒
        max: 3e5,
        // 最大时间限制 (ms) = 300秒
        recommended: {
          min: 5e3,
          // 推荐最小值 = 5秒
          max: 6e4
          // 推荐最大值 = 1分钟
        }
      },
      maxWeldingSegments: {
        min: 1,
        // 最小焊接段数
        max: 10,
        // 最大焊接段数
        recommended: {
          min: 1,
          // 推荐最小值
          max: 3
          // 推荐最大值
        }
      }
    };
    var DATA_LIMITS = {
      designSteel: {
        maxLength: 5e4,
        // 设计钢材最大长度 (mm)
        maxQuantity: 1e4,
        // 设计钢材最大数量
        maxCrossSection: 1e5
        // 最大截面面积 (mm²)
      },
      moduleSteel: {
        minLength: 1e3,
        // 模数钢材最小长度 (mm)
        maxLength: 5e4
        // 模数钢材最大长度 (mm)
      }
    };
    var STANDARD_STEEL_LENGTHS = [6e3, 9e3, 12e3, 15e3, 18e3];
    var DEFAULT_MODULE_LENGTHS = [12e3, 1e4, 8e3, 6e3];
    var REMAINDER_CONFIG = {
      idGeneration: {
        letterLimit: 50,
        // 单字母余料ID数量限制
        maxLetters: 26
        // 最大字母数量（a-z）
      },
      defaultWasteThreshold: 600,
      // 余料管理器默认废料阈值（与DEFAULT_CONSTRAINTS.wasteThreshold保持一致）
      binarySearchEnabled: true,
      // 是否启用二分查找优化
      dynamicAlgorithmSelection: true,
      // 是否启用动态算法选择
      algorithmThresholds: {
        smallScalePoolSize: 20,
        // 小规模问题的池大小阈值
        maxSegmentsForDP: 2
        // 动态规划算法的最大段数阈值
      }
    };
    var PERFORMANCE_CONFIG = {
      parallelOptimization: {
        maxActiveOptimizers: 10,
        // 最大并发优化器数量
        optimizerTimeout: 300,
        // 优化器超时时间 (ms)
        cleanupInterval: 6e4,
        // 清理间隔 (ms)
        historyLimit: 100
        // 历史记录数量限制
      },
      iterationLimits: {
        maxIterationsPerDemand: 100,
        // 每个需求的最大迭代次数倍数
        maxTotalIterations: 1e6
        // 总的最大迭代次数（安全上限）
      }
    };
    var ERROR_CONFIG = {
      validation: {
        maxErrorHistorySize: 100,
        // 最大错误历史记录数
        recentErrorWindow: 864e5
        // 最近错误时间窗口 (ms) = 24小时
      },
      systemResource: {
        highMemoryThreshold: 1e3,
        // 高内存使用阈值 (MB)
        maxFileSize: 10485760
        // 最大文件大小 (bytes) = 10MB
      }
    };
    var SCENARIO_CONFIGS = {
      // 高精度场景：桥梁、重要结构
      "precision": {
        wasteThreshold: 200,
        targetLossRate: 2,
        timeLimit: 6e4,
        // 1分钟
        maxWeldingSegments: 1,
        description: "\u9AD8\u7CBE\u5EA6\u573A\u666F - \u9002\u7528\u4E8E\u6865\u6881\u3001\u91CD\u8981\u7ED3\u6784\u7B49\u5BF9\u7CBE\u5EA6\u8981\u6C42\u6781\u9AD8\u7684\u9879\u76EE"
      },
      // 标准场景：一般建筑
      "standard": {
        wasteThreshold: 600,
        targetLossRate: 5,
        timeLimit: 3e5,
        // 300秒
        maxWeldingSegments: 2,
        description: "\u6807\u51C6\u573A\u666F - \u9002\u7528\u4E8E\u4E00\u822C\u5EFA\u7B51\u9879\u76EE\uFF0C\u5E73\u8861\u7CBE\u5EA6\u548C\u6548\u7387"
      },
      // 经济场景：成本优先
      "economic": {
        wasteThreshold: 800,
        targetLossRate: 8,
        timeLimit: 15e3,
        // 15秒
        maxWeldingSegments: 3,
        description: "\u7ECF\u6D4E\u573A\u666F - \u9002\u7528\u4E8E\u6210\u672C\u654F\u611F\u9879\u76EE\uFF0C\u4F18\u5148\u8003\u8651\u6548\u7387"
      },
      // 快速场景：时间优先
      "fast": {
        wasteThreshold: 700,
        targetLossRate: 6,
        timeLimit: 1e4,
        // 10秒
        maxWeldingSegments: 2,
        description: "\u5FEB\u901F\u573A\u666F - \u9002\u7528\u4E8E\u65F6\u95F4\u7D27\u6025\u7684\u9879\u76EE\uFF0C\u5FEB\u901F\u7ED9\u51FA\u4F18\u5316\u7ED3\u679C"
      }
    };
    var CONSTRAINT_DESCRIPTIONS = {
      wasteThreshold: "\u5F53\u4F59\u6599\u957F\u5EA6\u5C0F\u4E8E\u6B64\u503C\u65F6\uFF0C\u5C06\u88AB\u89C6\u4E3A\u5E9F\u6599\u65E0\u6CD5\u518D\u6B21\u5229\u7528",
      targetLossRate: "\u7B97\u6CD5\u4F18\u5316\u65F6\u7684\u76EE\u6807\u635F\u8017\u7387\uFF0C\u4F5C\u4E3A\u53C2\u8003\u503C\uFF08\u4E0D\u662F\u5F3A\u5236\u8981\u6C42\uFF09",
      timeLimit: "\u7B97\u6CD5\u8BA1\u7B97\u7684\u6700\u5927\u5141\u8BB8\u65F6\u95F4\uFF0C\u8D85\u65F6\u540E\u8FD4\u56DE\u5F53\u524D\u6700\u4F18\u89E3",
      maxWeldingSegments: "\u5355\u6839\u8BBE\u8BA1\u94A2\u6750\u5141\u8BB8\u7684\u6700\u5927\u710A\u63A5\u6BB5\u6570\uFF0C1\u6BB5\u8868\u793A\u4E0D\u5141\u8BB8\u710A\u63A5\uFF08V3\u6838\u5FC3\u529F\u80FD\uFF09"
    };
    var UNIT_CONVERSIONS = {
      time: {
        // 前端显示单位：秒，后端处理单位：毫秒
        msToSeconds: (ms) => Math.round(ms / 1e3),
        secondsToMs: (seconds) => Math.round(seconds * 1e3)
      },
      length: {
        // 统一使用毫米作为基础单位
        mmToM: (mm) => mm / 1e3,
        mToMm: (m) => m * 1e3
      }
    };
    var ENV_OVERRIDES = {
      wasteThreshold: process.env.HGJ_WASTE_THRESHOLD ? parseInt(process.env.HGJ_WASTE_THRESHOLD) : null,
      targetLossRate: process.env.HGJ_TARGET_LOSS_RATE ? parseFloat(process.env.HGJ_TARGET_LOSS_RATE) : null,
      timeLimit: process.env.HGJ_TIME_LIMIT ? parseInt(process.env.HGJ_TIME_LIMIT) : null,
      maxWeldingSegments: process.env.HGJ_MAX_WELDING_SEGMENTS ? parseInt(process.env.HGJ_MAX_WELDING_SEGMENTS) : null
    };
    module2.exports = {
      DEFAULT_CONSTRAINTS,
      VALIDATION_LIMITS,
      DATA_LIMITS,
      STANDARD_STEEL_LENGTHS,
      DEFAULT_MODULE_LENGTHS,
      REMAINDER_CONFIG,
      PERFORMANCE_CONFIG,
      ERROR_CONFIG,
      SCENARIO_CONFIGS,
      CONSTRAINT_DESCRIPTIONS,
      UNIT_CONVERSIONS,
      ENV_OVERRIDES
    };
  }
});

// core/config/ConstraintManager.js
var require_ConstraintManager = __commonJS({
  "core/config/ConstraintManager.js"(exports2, module2) {
    var {
      DEFAULT_CONSTRAINTS,
      VALIDATION_LIMITS,
      DATA_LIMITS,
      STANDARD_STEEL_LENGTHS,
      DEFAULT_MODULE_LENGTHS,
      REMAINDER_CONFIG,
      PERFORMANCE_CONFIG,
      ERROR_CONFIG,
      SCENARIO_CONFIGS,
      CONSTRAINT_DESCRIPTIONS,
      UNIT_CONVERSIONS,
      ENV_OVERRIDES
    } = require_ConstraintConfig();
    var ConstraintManager = class {
      constructor() {
        this.initializeConstraints();
      }
      /**
       * 初始化约束配置，应用环境变量覆盖
       */
      initializeConstraints() {
        this.currentConstraints = { ...DEFAULT_CONSTRAINTS };
        Object.keys(ENV_OVERRIDES).forEach((key) => {
          if (ENV_OVERRIDES[key] !== null) {
            this.currentConstraints[key] = ENV_OVERRIDES[key];
            console.log(`\u{1F527} \u7EA6\u675F\u914D\u7F6E\u8986\u76D6: ${key} = ${ENV_OVERRIDES[key]} (\u6765\u6E90: \u73AF\u5883\u53D8\u91CF)`);
          }
        });
        console.log("\u{1F4CB} \u7EA6\u675F\u7BA1\u7406\u5668\u521D\u59CB\u5316\u5B8C\u6210:", this.currentConstraints);
      }
      /**
       * 获取默认约束条件
       * @param {string} scenario - 可选的场景名称
       * @returns {Object} 约束条件对象
       */
      getDefaultConstraints(scenario = null) {
        if (scenario && SCENARIO_CONFIGS[scenario]) {
          const scenarioConfig = SCENARIO_CONFIGS[scenario];
          console.log(`\u{1F3AF} \u4F7F\u7528\u573A\u666F\u5316\u7EA6\u675F\u914D\u7F6E: ${scenario} - ${scenarioConfig.description}`);
          return {
            wasteThreshold: scenarioConfig.wasteThreshold,
            targetLossRate: scenarioConfig.targetLossRate,
            timeLimit: scenarioConfig.timeLimit,
            maxWeldingSegments: scenarioConfig.maxWeldingSegments
          };
        }
        return { ...this.currentConstraints };
      }
      /**
       * 获取约束验证限制
       * @param {string} constraintKey - 约束键名
       * @returns {Object} 验证限制对象
       */
      getValidationLimits(constraintKey = null) {
        if (constraintKey) {
          return VALIDATION_LIMITS[constraintKey] || null;
        }
        return VALIDATION_LIMITS;
      }
      /**
       * 验证单个约束条件
       * @param {string} key - 约束键名
       * @param {*} value - 约束值
       * @returns {Object} 验证结果
       */
      validateConstraint(key, value) {
        const limits = VALIDATION_LIMITS[key];
        if (!limits) {
          return {
            isValid: false,
            error: `\u672A\u77E5\u7684\u7EA6\u675F\u6761\u4EF6: ${key}`,
            code: "UNKNOWN_CONSTRAINT"
          };
        }
        if (typeof value !== "number" || isNaN(value)) {
          return {
            isValid: false,
            error: `${key} \u5FC5\u987B\u662F\u6709\u6548\u6570\u5B57`,
            code: "INVALID_TYPE"
          };
        }
        if (value < limits.min || value > limits.max) {
          return {
            isValid: false,
            error: `${key} \u5FC5\u987B\u5728 ${limits.min}-${limits.max} \u8303\u56F4\u5185`,
            code: "OUT_OF_RANGE",
            limits
          };
        }
        const isRecommended = value >= limits.recommended.min && value <= limits.recommended.max;
        return {
          isValid: true,
          isRecommended,
          recommendedRange: limits.recommended,
          warning: !isRecommended ? `\u5EFA\u8BAE\u5C06${key}\u8BBE\u7F6E\u5728 ${limits.recommended.min}-${limits.recommended.max} \u8303\u56F4\u5185\u4EE5\u83B7\u5F97\u6700\u4F73\u6548\u679C` : null
        };
      }
      /**
       * 验证完整的约束条件对象
       * @param {Object} constraints - 约束条件对象
       * @returns {Object} 验证结果
       */
      validateConstraints(constraints) {
        const results = {
          isValid: true,
          errors: [],
          warnings: [],
          fieldResults: {}
        };
        Object.keys(DEFAULT_CONSTRAINTS).forEach((key) => {
          if (constraints.hasOwnProperty(key)) {
            const validation = this.validateConstraint(key, constraints[key]);
            results.fieldResults[key] = validation;
            if (!validation.isValid) {
              results.isValid = false;
              results.errors.push({
                field: key,
                message: validation.error,
                code: validation.code,
                limits: validation.limits
              });
            } else if (validation.warning) {
              results.warnings.push({
                field: key,
                message: validation.warning
              });
            }
          }
        });
        return results;
      }
      /**
       * 获取数据验证限制
       * @param {string} dataType - 数据类型 ('designSteel' | 'moduleSteel')
       * @returns {Object} 数据验证限制
       */
      getDataLimits(dataType = null) {
        if (dataType) {
          return DATA_LIMITS[dataType] || null;
        }
        return DATA_LIMITS;
      }
      /**
       * 获取标准钢材长度
       * @returns {Array} 标准长度数组
       */
      getStandardSteelLengths() {
        return [...STANDARD_STEEL_LENGTHS];
      }
      /**
       * 获取默认模数钢材长度
       * @returns {Array} 默认模数钢材长度数组
       */
      getDefaultModuleLengths() {
        return [...DEFAULT_MODULE_LENGTHS];
      }
      /**
       * 获取余料管理配置
       * @returns {Object} 余料管理配置
       */
      getRemainderConfig() {
        return { ...REMAINDER_CONFIG };
      }
      /**
       * 获取性能配置
       * @returns {Object} 性能配置
       */
      getPerformanceConfig() {
        return { ...PERFORMANCE_CONFIG };
      }
      /**
       * 获取错误处理配置
       * @returns {Object} 错误处理配置
       */
      getErrorConfig() {
        return { ...ERROR_CONFIG };
      }
      /**
       * 获取约束描述
       * @param {string} constraintKey - 约束键名
       * @returns {string} 约束描述
       */
      getConstraintDescription(constraintKey) {
        return CONSTRAINT_DESCRIPTIONS[constraintKey] || "";
      }
      /**
       * 获取所有约束描述
       * @returns {Object} 所有约束描述
       */
      getAllConstraintDescriptions() {
        return { ...CONSTRAINT_DESCRIPTIONS };
      }
      /**
       * 获取可用的场景配置
       * @returns {Object} 场景配置
       */
      getAvailableScenarios() {
        return Object.keys(SCENARIO_CONFIGS).map((key) => ({
          key,
          name: key,
          description: SCENARIO_CONFIGS[key].description,
          constraints: {
            wasteThreshold: SCENARIO_CONFIGS[key].wasteThreshold,
            targetLossRate: SCENARIO_CONFIGS[key].targetLossRate,
            timeLimit: SCENARIO_CONFIGS[key].timeLimit,
            maxWeldingSegments: SCENARIO_CONFIGS[key].maxWeldingSegments
          }
        }));
      }
      /**
       * 时间单位转换：毫秒转秒（用于前端显示）
       * @param {number} ms - 毫秒
       * @returns {number} 秒
       */
      msToSeconds(ms) {
        return UNIT_CONVERSIONS.time.msToSeconds(ms);
      }
      /**
       * 时间单位转换：秒转毫秒（用于后端处理）
       * @param {number} seconds - 秒
       * @returns {number} 毫秒
       */
      secondsToMs(seconds) {
        return UNIT_CONVERSIONS.time.secondsToMs(seconds);
      }
      /**
       * 长度单位转换：毫米转米
       * @param {number} mm - 毫米
       * @returns {number} 米
       */
      mmToM(mm) {
        return UNIT_CONVERSIONS.length.mmToM(mm);
      }
      /**
       * 长度单位转换：米转毫米
       * @param {number} m - 米
       * @returns {number} 毫米
       */
      mToMm(m) {
        return UNIT_CONVERSIONS.length.mToMm(m);
      }
      /**
       * 创建前端安全的约束对象（时间转换为秒）
       * @param {Object} constraints - 后端约束对象（时间为毫秒）
       * @returns {Object} 前端约束对象（时间为秒）
       */
      createFrontendConstraints(constraints) {
        return {
          wasteThreshold: constraints.wasteThreshold,
          targetLossRate: constraints.targetLossRate,
          timeLimit: this.msToSeconds(constraints.timeLimit),
          maxWeldingSegments: constraints.maxWeldingSegments
        };
      }
      /**
       * 创建后端约束对象（时间转换为毫秒）
       * @param {Object} frontendConstraints - 前端约束对象（时间为秒）
       * @returns {Object} 后端约束对象（时间为毫秒）
       */
      createBackendConstraints(frontendConstraints) {
        return {
          wasteThreshold: frontendConstraints.wasteThreshold,
          targetLossRate: frontendConstraints.targetLossRate,
          timeLimit: this.secondsToMs(frontendConstraints.timeLimit),
          maxWeldingSegments: frontendConstraints.maxWeldingSegments
        };
      }
      /**
       * 生成推荐的模数钢材长度
       * @param {number} requiredLength - 所需最小长度
       * @param {number} maxCount - 最大返回数量
       * @returns {Array} 推荐长度数组
       */
      generateRecommendedLengths(requiredLength, maxCount = 3) {
        const recommended = [];
        recommended.push(requiredLength);
        STANDARD_STEEL_LENGTHS.forEach((length) => {
          if (length >= requiredLength && !recommended.includes(length)) {
            recommended.push(length);
          }
        });
        return recommended.sort((a, b) => a - b).slice(0, maxCount);
      }
      /**
       * 检查焊接约束冲突
       * @param {Array} designSteels - 设计钢材数组
       * @param {Array} moduleSteels - 模数钢材数组
       * @param {Object} constraints - 约束条件
       * @returns {Object} 冲突检查结果
       */
      checkWeldingConstraintConflict(designSteels, moduleSteels, constraints) {
        if (!designSteels.length || !moduleSteels.length) {
          return { hasConflict: false };
        }
        const maxModuleLength = Math.max(...moduleSteels.map((m) => m.length));
        const conflictSteels = designSteels.filter((d) => d.length > maxModuleLength);
        if (conflictSteels.length > 0 && constraints.maxWeldingSegments === 1) {
          const maxDesignLength = Math.max(...conflictSteels.map((s) => s.length));
          const requiredSegments = Math.ceil(maxDesignLength / maxModuleLength);
          return {
            hasConflict: true,
            conflictCount: conflictSteels.length,
            maxConflictLength: maxDesignLength,
            maxModuleLength,
            requiredSegments,
            suggestions: [
              {
                type: "addLongerModule",
                title: "\u6DFB\u52A0\u66F4\u957F\u7684\u6A21\u6570\u94A2\u6750",
                description: `\u5EFA\u8BAE\u6DFB\u52A0\u957F\u5EA6\u2265${maxDesignLength}mm\u7684\u6A21\u6570\u94A2\u6750`,
                recommendedLengths: this.generateRecommendedLengths(maxDesignLength)
              },
              {
                type: "increaseWelding",
                title: "\u589E\u52A0\u5141\u8BB8\u710A\u63A5\u6BB5\u6570",
                description: `\u5EFA\u8BAE\u5C06\u6700\u5927\u710A\u63A5\u6BB5\u6570\u8C03\u6574\u4E3A${requiredSegments}\u6BB5\u4EE5\u4E0A`,
                recommendedValue: requiredSegments
              }
            ]
          };
        }
        return { hasConflict: false };
      }
      /**
       * 重置为默认配置
       */
      resetToDefaults() {
        this.initializeConstraints();
        console.log("\u{1F504} \u7EA6\u675F\u914D\u7F6E\u5DF2\u91CD\u7F6E\u4E3A\u9ED8\u8BA4\u503C");
      }
      /**
       * 获取当前配置摘要
       * @returns {Object} 配置摘要
       */
      getConfigSummary() {
        return {
          currentConstraints: { ...this.currentConstraints },
          hasEnvironmentOverrides: Object.values(ENV_OVERRIDES).some((val) => val !== null),
          environmentOverrides: Object.fromEntries(
            Object.entries(ENV_OVERRIDES).filter(([, value]) => value !== null)
          ),
          availableScenarios: Object.keys(SCENARIO_CONFIGS),
          configVersion: "3.0.0",
          lastInitialized: (/* @__PURE__ */ new Date()).toISOString()
        };
      }
    };
    var constraintManager = new ConstraintManager();
    module2.exports = constraintManager;
  }
});

// node_modules/uuid/dist/esm-node/rng.js
function rng() {
  if (poolPtr > rnds8Pool.length - 16) {
    import_crypto.default.randomFillSync(rnds8Pool);
    poolPtr = 0;
  }
  return rnds8Pool.slice(poolPtr, poolPtr += 16);
}
var import_crypto, rnds8Pool, poolPtr;
var init_rng = __esm({
  "node_modules/uuid/dist/esm-node/rng.js"() {
    import_crypto = __toESM(require("crypto"));
    rnds8Pool = new Uint8Array(256);
    poolPtr = rnds8Pool.length;
  }
});

// node_modules/uuid/dist/esm-node/regex.js
var regex_default;
var init_regex = __esm({
  "node_modules/uuid/dist/esm-node/regex.js"() {
    regex_default = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}|00000000-0000-0000-0000-000000000000)$/i;
  }
});

// node_modules/uuid/dist/esm-node/validate.js
function validate(uuid) {
  return typeof uuid === "string" && regex_default.test(uuid);
}
var validate_default;
var init_validate = __esm({
  "node_modules/uuid/dist/esm-node/validate.js"() {
    init_regex();
    validate_default = validate;
  }
});

// node_modules/uuid/dist/esm-node/stringify.js
function unsafeStringify(arr, offset = 0) {
  return byteToHex[arr[offset + 0]] + byteToHex[arr[offset + 1]] + byteToHex[arr[offset + 2]] + byteToHex[arr[offset + 3]] + "-" + byteToHex[arr[offset + 4]] + byteToHex[arr[offset + 5]] + "-" + byteToHex[arr[offset + 6]] + byteToHex[arr[offset + 7]] + "-" + byteToHex[arr[offset + 8]] + byteToHex[arr[offset + 9]] + "-" + byteToHex[arr[offset + 10]] + byteToHex[arr[offset + 11]] + byteToHex[arr[offset + 12]] + byteToHex[arr[offset + 13]] + byteToHex[arr[offset + 14]] + byteToHex[arr[offset + 15]];
}
function stringify(arr, offset = 0) {
  const uuid = unsafeStringify(arr, offset);
  if (!validate_default(uuid)) {
    throw TypeError("Stringified UUID is invalid");
  }
  return uuid;
}
var byteToHex, stringify_default;
var init_stringify = __esm({
  "node_modules/uuid/dist/esm-node/stringify.js"() {
    init_validate();
    byteToHex = [];
    for (let i = 0; i < 256; ++i) {
      byteToHex.push((i + 256).toString(16).slice(1));
    }
    stringify_default = stringify;
  }
});

// node_modules/uuid/dist/esm-node/v1.js
function v1(options, buf, offset) {
  let i = buf && offset || 0;
  const b = buf || new Array(16);
  options = options || {};
  let node = options.node || _nodeId;
  let clockseq = options.clockseq !== void 0 ? options.clockseq : _clockseq;
  if (node == null || clockseq == null) {
    const seedBytes = options.random || (options.rng || rng)();
    if (node == null) {
      node = _nodeId = [seedBytes[0] | 1, seedBytes[1], seedBytes[2], seedBytes[3], seedBytes[4], seedBytes[5]];
    }
    if (clockseq == null) {
      clockseq = _clockseq = (seedBytes[6] << 8 | seedBytes[7]) & 16383;
    }
  }
  let msecs = options.msecs !== void 0 ? options.msecs : Date.now();
  let nsecs = options.nsecs !== void 0 ? options.nsecs : _lastNSecs + 1;
  const dt = msecs - _lastMSecs + (nsecs - _lastNSecs) / 1e4;
  if (dt < 0 && options.clockseq === void 0) {
    clockseq = clockseq + 1 & 16383;
  }
  if ((dt < 0 || msecs > _lastMSecs) && options.nsecs === void 0) {
    nsecs = 0;
  }
  if (nsecs >= 1e4) {
    throw new Error("uuid.v1(): Can't create more than 10M uuids/sec");
  }
  _lastMSecs = msecs;
  _lastNSecs = nsecs;
  _clockseq = clockseq;
  msecs += 122192928e5;
  const tl = ((msecs & 268435455) * 1e4 + nsecs) % 4294967296;
  b[i++] = tl >>> 24 & 255;
  b[i++] = tl >>> 16 & 255;
  b[i++] = tl >>> 8 & 255;
  b[i++] = tl & 255;
  const tmh = msecs / 4294967296 * 1e4 & 268435455;
  b[i++] = tmh >>> 8 & 255;
  b[i++] = tmh & 255;
  b[i++] = tmh >>> 24 & 15 | 16;
  b[i++] = tmh >>> 16 & 255;
  b[i++] = clockseq >>> 8 | 128;
  b[i++] = clockseq & 255;
  for (let n = 0; n < 6; ++n) {
    b[i + n] = node[n];
  }
  return buf || unsafeStringify(b);
}
var _nodeId, _clockseq, _lastMSecs, _lastNSecs, v1_default;
var init_v1 = __esm({
  "node_modules/uuid/dist/esm-node/v1.js"() {
    init_rng();
    init_stringify();
    _lastMSecs = 0;
    _lastNSecs = 0;
    v1_default = v1;
  }
});

// node_modules/uuid/dist/esm-node/parse.js
function parse(uuid) {
  if (!validate_default(uuid)) {
    throw TypeError("Invalid UUID");
  }
  let v;
  const arr = new Uint8Array(16);
  arr[0] = (v = parseInt(uuid.slice(0, 8), 16)) >>> 24;
  arr[1] = v >>> 16 & 255;
  arr[2] = v >>> 8 & 255;
  arr[3] = v & 255;
  arr[4] = (v = parseInt(uuid.slice(9, 13), 16)) >>> 8;
  arr[5] = v & 255;
  arr[6] = (v = parseInt(uuid.slice(14, 18), 16)) >>> 8;
  arr[7] = v & 255;
  arr[8] = (v = parseInt(uuid.slice(19, 23), 16)) >>> 8;
  arr[9] = v & 255;
  arr[10] = (v = parseInt(uuid.slice(24, 36), 16)) / 1099511627776 & 255;
  arr[11] = v / 4294967296 & 255;
  arr[12] = v >>> 24 & 255;
  arr[13] = v >>> 16 & 255;
  arr[14] = v >>> 8 & 255;
  arr[15] = v & 255;
  return arr;
}
var parse_default;
var init_parse = __esm({
  "node_modules/uuid/dist/esm-node/parse.js"() {
    init_validate();
    parse_default = parse;
  }
});

// node_modules/uuid/dist/esm-node/v35.js
function stringToBytes(str) {
  str = unescape(encodeURIComponent(str));
  const bytes = [];
  for (let i = 0; i < str.length; ++i) {
    bytes.push(str.charCodeAt(i));
  }
  return bytes;
}
function v35(name, version2, hashfunc) {
  function generateUUID(value, namespace, buf, offset) {
    var _namespace;
    if (typeof value === "string") {
      value = stringToBytes(value);
    }
    if (typeof namespace === "string") {
      namespace = parse_default(namespace);
    }
    if (((_namespace = namespace) === null || _namespace === void 0 ? void 0 : _namespace.length) !== 16) {
      throw TypeError("Namespace must be array-like (16 iterable integer values, 0-255)");
    }
    let bytes = new Uint8Array(16 + value.length);
    bytes.set(namespace);
    bytes.set(value, namespace.length);
    bytes = hashfunc(bytes);
    bytes[6] = bytes[6] & 15 | version2;
    bytes[8] = bytes[8] & 63 | 128;
    if (buf) {
      offset = offset || 0;
      for (let i = 0; i < 16; ++i) {
        buf[offset + i] = bytes[i];
      }
      return buf;
    }
    return unsafeStringify(bytes);
  }
  try {
    generateUUID.name = name;
  } catch (err) {
  }
  generateUUID.DNS = DNS;
  generateUUID.URL = URL;
  return generateUUID;
}
var DNS, URL;
var init_v35 = __esm({
  "node_modules/uuid/dist/esm-node/v35.js"() {
    init_stringify();
    init_parse();
    DNS = "6ba7b810-9dad-11d1-80b4-00c04fd430c8";
    URL = "6ba7b811-9dad-11d1-80b4-00c04fd430c8";
  }
});

// node_modules/uuid/dist/esm-node/md5.js
function md5(bytes) {
  if (Array.isArray(bytes)) {
    bytes = Buffer.from(bytes);
  } else if (typeof bytes === "string") {
    bytes = Buffer.from(bytes, "utf8");
  }
  return import_crypto2.default.createHash("md5").update(bytes).digest();
}
var import_crypto2, md5_default;
var init_md5 = __esm({
  "node_modules/uuid/dist/esm-node/md5.js"() {
    import_crypto2 = __toESM(require("crypto"));
    md5_default = md5;
  }
});

// node_modules/uuid/dist/esm-node/v3.js
var v3, v3_default;
var init_v3 = __esm({
  "node_modules/uuid/dist/esm-node/v3.js"() {
    init_v35();
    init_md5();
    v3 = v35("v3", 48, md5_default);
    v3_default = v3;
  }
});

// node_modules/uuid/dist/esm-node/native.js
var import_crypto3, native_default;
var init_native = __esm({
  "node_modules/uuid/dist/esm-node/native.js"() {
    import_crypto3 = __toESM(require("crypto"));
    native_default = {
      randomUUID: import_crypto3.default.randomUUID
    };
  }
});

// node_modules/uuid/dist/esm-node/v4.js
function v4(options, buf, offset) {
  if (native_default.randomUUID && !buf && !options) {
    return native_default.randomUUID();
  }
  options = options || {};
  const rnds = options.random || (options.rng || rng)();
  rnds[6] = rnds[6] & 15 | 64;
  rnds[8] = rnds[8] & 63 | 128;
  if (buf) {
    offset = offset || 0;
    for (let i = 0; i < 16; ++i) {
      buf[offset + i] = rnds[i];
    }
    return buf;
  }
  return unsafeStringify(rnds);
}
var v4_default;
var init_v4 = __esm({
  "node_modules/uuid/dist/esm-node/v4.js"() {
    init_native();
    init_rng();
    init_stringify();
    v4_default = v4;
  }
});

// node_modules/uuid/dist/esm-node/sha1.js
function sha1(bytes) {
  if (Array.isArray(bytes)) {
    bytes = Buffer.from(bytes);
  } else if (typeof bytes === "string") {
    bytes = Buffer.from(bytes, "utf8");
  }
  return import_crypto4.default.createHash("sha1").update(bytes).digest();
}
var import_crypto4, sha1_default;
var init_sha1 = __esm({
  "node_modules/uuid/dist/esm-node/sha1.js"() {
    import_crypto4 = __toESM(require("crypto"));
    sha1_default = sha1;
  }
});

// node_modules/uuid/dist/esm-node/v5.js
var v5, v5_default;
var init_v5 = __esm({
  "node_modules/uuid/dist/esm-node/v5.js"() {
    init_v35();
    init_sha1();
    v5 = v35("v5", 80, sha1_default);
    v5_default = v5;
  }
});

// node_modules/uuid/dist/esm-node/nil.js
var nil_default;
var init_nil = __esm({
  "node_modules/uuid/dist/esm-node/nil.js"() {
    nil_default = "00000000-0000-0000-0000-000000000000";
  }
});

// node_modules/uuid/dist/esm-node/version.js
function version(uuid) {
  if (!validate_default(uuid)) {
    throw TypeError("Invalid UUID");
  }
  return parseInt(uuid.slice(14, 15), 16);
}
var version_default;
var init_version = __esm({
  "node_modules/uuid/dist/esm-node/version.js"() {
    init_validate();
    version_default = version;
  }
});

// node_modules/uuid/dist/esm-node/index.js
var esm_node_exports = {};
__export(esm_node_exports, {
  NIL: () => nil_default,
  parse: () => parse_default,
  stringify: () => stringify_default,
  v1: () => v1_default,
  v3: () => v3_default,
  v4: () => v4_default,
  v5: () => v5_default,
  validate: () => validate_default,
  version: () => version_default
});
var init_esm_node = __esm({
  "node_modules/uuid/dist/esm-node/index.js"() {
    init_v1();
    init_v3();
    init_v4();
    init_v5();
    init_nil();
    init_version();
    init_validate();
    init_stringify();
    init_parse();
  }
});

// core/remainder/RemainderManager.js
var require_RemainderManager = __commonJS({
  "core/remainder/RemainderManager.js"(exports2, module2) {
    var { RemainderV3, REMAINDER_TYPES } = require_types();
    var constraintManager = require_ConstraintManager();
    var { v4: uuidv4 } = (init_esm_node(), __toCommonJS(esm_node_exports));
    var RemainderManager = class {
      constructor(wasteThreshold = null) {
        this.wasteThreshold = wasteThreshold ?? constraintManager.getWasteThreshold();
        this.remainderPools = {};
        this.wasteBin = {};
        this.usageHistory = {};
        this.remainderCounters = {};
        console.log(`\u{1F4CB} \u4F59\u6599\u7BA1\u7406\u5668\u521D\u59CB\u5316\u5B8C\u6210\uFF0C\u5E9F\u6599\u9608\u503C: ${this.wasteThreshold}mm`);
      }
      /**
       * 初始化组合键的余料池、使用历史和废料仓
       */
      initializePool(groupKey) {
        if (!this.remainderPools[groupKey]) {
          this.remainderPools[groupKey] = [];
          this.usageHistory[groupKey] = [];
          this.wasteBin[groupKey] = [];
          this.remainderCounters[groupKey] = { letterIndex: 0, numbers: {} };
        }
      }
      /**
       * 生成余料ID（按组合键）
       */
      generateRemainderID(groupKey, sourceId = null) {
        this.initializePool(groupKey);
        const counter = this.remainderCounters[groupKey];
        const letter = String.fromCharCode(97 + counter.letterIndex);
        if (!counter.numbers[letter]) {
          counter.numbers[letter] = 0;
        }
        counter.numbers[letter]++;
        const letterLimit = constraintManager.getRemainderConfig().idGeneration.letterLimit;
        if (counter.numbers[letter] > letterLimit) {
          counter.letterIndex++;
          const newLetter = String.fromCharCode(97 + counter.letterIndex);
          counter.numbers[newLetter] = 1;
          return `${groupKey}_${newLetter}1`;
        }
        return `${groupKey}_${letter}${counter.numbers[letter]}`;
      }
      /**
       * 🔧 核心修复：重构余料评估和处理方法
       * 引入"废料仓"机制，实现废料的彻底隔离
       */
      evaluateAndProcessRemainder(remainder, groupKey, context = {}) {
        this.initializePool(groupKey);
        if (!remainder.id) {
          remainder.id = this.generateRemainderID(groupKey);
        }
        remainder.groupKey = groupKey;
        const result = {
          remainder: null,
          // 默认不返回任何对象
          isWaste: false,
          isPendingRemainder: false,
          wasteLength: 0,
          action: ""
        };
        if (remainder.length < this.wasteThreshold) {
          remainder.markAsWaste();
          this.wasteBin[groupKey].push(remainder);
          result.isWaste = true;
          result.wasteLength = remainder.length;
          result.action = "moveToWasteBin";
          console.log(`\u{1F5D1}\uFE0F  ${groupKey}\u4F59\u6599 ${remainder.id} (${remainder.length}mm) \u5C0F\u4E8E\u9608\u503C\uFF0C\u7ACB\u5373\u79FB\u5165\u5E9F\u6599\u4ED3 [\u6765\u6E90: ${context.source || "\u672A\u77E5"}]`);
        } else {
          remainder.type = REMAINDER_TYPES.PENDING;
          this.remainderPools[groupKey].push(remainder);
          this.remainderPools[groupKey].sort((a, b) => a.length - b.length);
          result.remainder = remainder;
          result.isPendingRemainder = true;
          result.action = "addToPool";
          console.log(`\u23F3  ${groupKey}\u4F59\u6599 ${remainder.id} (${remainder.length}mm) \u4F5C\u4E3A\u5F85\u5B9A\u4F59\u6599\u52A0\u5165\u6C60\u4E2D [\u6765\u6E90: ${context.source || "\u672A\u77E5"}]`);
        }
        return result;
      }
      /**
       * 添加余料到组合键池中（修改为使用统一动态判断）
       */
      addRemainder(remainder, groupKey) {
        const evaluationResult = this.evaluateAndProcessRemainder(remainder, groupKey, {
          source: "\u5916\u90E8\u6DFB\u52A0"
        });
        return evaluationResult.remainder;
      }
      /**
       * 寻找最佳余料组合（按组合键匹配）
       * 🔧 重构：支持动态多余料组合，根据焊接段数限制
       */
      findBestRemainderCombination(targetLength, groupKey, maxWeldingSegments = 2) {
        this.initializePool(groupKey);
        const pool = this.remainderPools[groupKey].filter((r) => r.type !== REMAINDER_TYPES.WASTE);
        console.log(`\u{1F50D} \u5728${groupKey}\u7EC4\u5408\u4F59\u6599\u6C60\u4E2D\u5BFB\u627E ${targetLength}mm \u7684\u6700\u4F73\u7EC4\u5408\uFF08\u6700\u5927\u710A\u63A5\u6BB5\u6570\uFF1A${maxWeldingSegments}\uFF09`);
        if (pool.length === 0) {
          console.log(`\u274C ${groupKey}\u7EC4\u5408\u4F59\u6599\u6C60\u4E3A\u7A7A`);
          return null;
        }
        const sortedPool = [...pool].sort((a, b) => a.length - b.length);
        const startTime = Date.now();
        let bestCombination = null;
        let bestEfficiency = Infinity;
        for (let segmentCount = 1; segmentCount <= maxWeldingSegments; segmentCount++) {
          const combination = this.findBestCombinationWithSegments(sortedPool, targetLength, segmentCount);
          if (combination && combination.efficiency < bestEfficiency) {
            bestEfficiency = combination.efficiency;
            bestCombination = combination;
            if (combination.efficiency <= 1.01) {
              console.log(`\u2728 \u627E\u5230\u5B8C\u7F8E\u5339\u914D\uFF0C\u63D0\u524D\u7ED3\u675F\u641C\u7D22`);
              break;
            }
          }
        }
        const endTime = Date.now();
        if (bestCombination) {
          bestCombination.indices = bestCombination.remainders.map(
            (remainder) => pool.findIndex((r) => r.id === remainder.id)
          );
          console.log(`\u2705 \u627E\u5230\u6700\u4F18${bestCombination.remainders.length}\u6BB5\u7EC4\u5408: ${bestCombination.remainders.map((r) => `${r.id}(${r.length}mm)`).join(" + ")} = ${bestCombination.totalLength}mm\uFF0C\u6548\u7387\uFF1A${bestCombination.efficiency.toFixed(3)}\uFF0C\u8017\u65F6\uFF1A${endTime - startTime}ms`);
          return bestCombination;
        }
        console.log(`\u274C \u5728${groupKey}\u7EC4\u5408\u4F59\u6599\u6C60\u4E2D\u672A\u627E\u5230\u5408\u9002\u7EC4\u5408\uFF0C\u8017\u65F6\uFF1A${endTime - startTime}ms`);
        return null;
      }
      /**
       * 🧠 智能算法选择器：根据问题规模选择最优算法
       */
      findBestCombinationWithSegments(sortedPool, targetLength, segmentCount) {
        const poolSize = sortedPool.length;
        if (poolSize <= 20 || segmentCount <= 2) {
          console.log(`\u{1F9EE} \u9009\u62E9\u52A8\u6001\u89C4\u5212\u7B97\u6CD5\uFF08\u6C60\u5927\u5C0F\uFF1A${poolSize}\uFF0C\u6BB5\u6570\uFF1A${segmentCount}\uFF09- \u7CBE\u786E\u89E3`);
          return this.findBestCombinationDP(sortedPool, targetLength, segmentCount);
        } else {
          console.log(`\u{1F680} \u9009\u62E9\u5206\u5C42\u8D2A\u5FC3\u7B97\u6CD5\uFF08\u6C60\u5927\u5C0F\uFF1A${poolSize}\uFF0C\u6BB5\u6570\uFF1A${segmentCount}\uFF09- \u5FEB\u901F\u8FD1\u4F3C\u89E3`);
          return this.findBestCombinationGreedy(sortedPool, targetLength, segmentCount);
        }
      }
      /**
       * 🎯 动态规划算法：找到精确最优解
       * 时间复杂度：O(k × n × L)，其中L是可能长度的数量
       * 适用于：小规模问题，保证全局最优
       */
      findBestCombinationDP(sortedPool, targetLength, maxSegments) {
        if (maxSegments === 1) {
          const index = this.binarySearchClosest(sortedPool, targetLength);
          if (index !== -1) {
            const remainder = sortedPool[index];
            return {
              type: "single",
              remainders: [remainder],
              totalLength: remainder.length,
              efficiency: remainder.length / targetLength
            };
          }
          return null;
        }
        let currentStates = /* @__PURE__ */ new Map();
        currentStates.set(0, { remainders: [], efficiency: Infinity });
        for (let segment = 1; segment <= maxSegments; segment++) {
          const nextStates = /* @__PURE__ */ new Map();
          for (const [currentLength, currentState] of currentStates) {
            for (const remainder of sortedPool) {
              if (currentState.remainders.some((r) => r.id === remainder.id)) {
                continue;
              }
              const newLength = currentLength + remainder.length;
              const newRemainders = [...currentState.remainders, remainder];
              const newEfficiency = newLength >= targetLength ? newLength / targetLength : Infinity;
              if (!nextStates.has(newLength) || nextStates.get(newLength).efficiency > newEfficiency) {
                nextStates.set(newLength, {
                  remainders: newRemainders,
                  efficiency: newEfficiency
                });
              }
            }
          }
          currentStates = nextStates;
          if (currentStates.size > 1e3) {
            const validStates = /* @__PURE__ */ new Map();
            const sortedStates = Array.from(currentStates.entries()).filter(([length, state]) => length >= targetLength && state.efficiency <= 2).sort(([, a], [, b]) => a.efficiency - b.efficiency).slice(0, 100);
            for (const [length, state] of sortedStates) {
              validStates.set(length, state);
            }
            if (validStates.size > 0) {
              currentStates = validStates;
            }
          }
        }
        let bestSolution = null;
        let bestEfficiency = Infinity;
        for (const [length, state] of currentStates) {
          if (length >= targetLength && state.efficiency < bestEfficiency) {
            bestEfficiency = state.efficiency;
            bestSolution = {
              type: "combination",
              remainders: state.remainders,
              totalLength: length,
              efficiency: state.efficiency
            };
          }
        }
        return bestSolution;
      }
      /**
       * ⚡ 分层贪心算法：快速找到近似最优解
       * 时间复杂度：O(k × n × log n)
       * 适用于：大规模问题，速度优先
       */
      findBestCombinationGreedy(sortedPool, targetLength, maxSegments) {
        const descendingPool = [...sortedPool].sort((a, b) => b.length - a.length);
        let bestSolution = null;
        let bestEfficiency = Infinity;
        for (let segments = 1; segments <= maxSegments; segments++) {
          const solution = this.greedySearchForSegments(descendingPool, targetLength, segments);
          if (solution && solution.efficiency < bestEfficiency) {
            bestEfficiency = solution.efficiency;
            bestSolution = solution;
            if (solution.efficiency <= 1.01) {
              break;
            }
          }
        }
        return bestSolution;
      }
      /**
       * 🎲 贪心搜索指定段数的组合
       */
      greedySearchForSegments(descendingPool, targetLength, targetSegments) {
        const used = /* @__PURE__ */ new Set();
        const combination = [];
        let totalLength = 0;
        let remaining = targetLength;
        for (let segment = 0; segment < targetSegments && remaining > 0; segment++) {
          let bestChoice = null;
          let bestWaste = Infinity;
          for (let i = 0; i < descendingPool.length; i++) {
            const remainder = descendingPool[i];
            if (used.has(remainder.id)) continue;
            if (segment === targetSegments - 1) {
              if (remainder.length >= remaining) {
                const waste = remainder.length - remaining;
                if (waste < bestWaste) {
                  bestWaste = waste;
                  bestChoice = { remainder, index: i };
                }
              }
            } else {
              if (remainder.length <= remaining * 1.5) {
                bestChoice = { remainder, index: i };
                break;
              }
            }
          }
          if (!bestChoice) break;
          used.add(bestChoice.remainder.id);
          combination.push(bestChoice.remainder);
          totalLength += bestChoice.remainder.length;
          remaining -= bestChoice.remainder.length;
        }
        if (totalLength >= targetLength) {
          return {
            type: combination.length === 1 ? "single" : "combination",
            remainders: combination,
            totalLength,
            efficiency: totalLength / targetLength
          };
        }
        return null;
      }
      /**
       * 🔍 二分查找最接近且大于目标长度的余料
       * 时间复杂度：O(log n)
       */
      binarySearchClosest(sortedPool, targetLength) {
        let left = 0;
        let right = sortedPool.length - 1;
        let result = -1;
        while (left <= right) {
          const mid = Math.floor((left + right) / 2);
          const midLength = sortedPool[mid].length;
          if (midLength >= targetLength) {
            result = mid;
            right = mid - 1;
          } else {
            left = mid + 1;
          }
        }
        return result;
      }
      /**
       * [新增] V3.1 - 寻找最佳的单个余料
       * @description 为装箱算法(FFD)设计，寻找能容纳目标长度的、最经济的(即最短的)单个余料
       * @param {number} minLength - 最小需要的长度
       * @param {string} groupKey - 组合键
       * @returns {RemainderV3 | null} - 找到的最佳余料对象，或null
       */
      findBestSingleRemainder(minLength, groupKey) {
        this.initializePool(groupKey);
        const pool = this.remainderPools[groupKey].filter((r) => r.type !== REMAINDER_TYPES.WASTE && r.type !== REMAINDER_TYPES.PSEUDO);
        if (pool.length === 0) {
          return null;
        }
        const bestMatch = pool.find((r) => r.length >= minLength);
        if (bestMatch) {
          console.log(`\u2728 [FFD] \u4E3A ${minLength}mm \u627E\u5230\u6700\u4F73\u5355\u4E2A\u4F59\u6599: ${bestMatch.id} (${bestMatch.length}mm)`);
        }
        return bestMatch || null;
      }
      /**
       * [新增] V3.1 - 使用(移除)单个余料
       * @description 为装箱算法(FFD)设计，从池中移除一个已被选中的余料
       * @param {string} remainderId - 要移除的余料ID
       * @param {string} groupKey - 组合键
       */
      useSingleRemainder(remainderId, groupKey) {
        this.initializePool(groupKey);
        const pool = this.remainderPools[groupKey];
        const index = pool.findIndex((r) => r.id === remainderId);
        if (index !== -1) {
          const removed = pool.splice(index, 1)[0];
          console.log(`\u2796 [FFD] \u4ECE${groupKey}\u6C60\u4E2D\u6D88\u8017\u5355\u4E2A\u4F59\u6599: ${removed.id} (${removed.length}mm)`);
          removed.markAsPseudo();
        } else {
          console.warn(`\u26A0\uFE0F [FFD] \u5C1D\u8BD5\u6D88\u8017\u4E00\u4E2A\u4E0D\u5B58\u5728\u7684\u4F59\u6599: ${remainderId}`);
        }
      }
      /**
       * 使用余料进行切割
       * 关键：动态判断余料类型，并确保统计正确
       */
      useRemainder(combination, targetLength, designId, groupKey) {
        const { remainders, indices } = combination;
        const totalLength = combination.totalLength;
        const newRemainderLength = totalLength - targetLength;
        const usage = {
          timestamp: (/* @__PURE__ */ new Date()).toISOString(),
          remainderIds: remainders.map((r) => r.id),
          targetLength,
          designId,
          groupKey,
          resultLength: newRemainderLength
        };
        this.usageHistory[groupKey].push(usage);
        this.removeRemaindersFromPool(indices, groupKey);
        const pseudoRemainders = [];
        remainders.forEach((remainder) => {
          const pseudoRemainder = Object.assign(new RemainderV3({}), remainder);
          pseudoRemainder.markAsPseudo();
          pseudoRemainders.push(pseudoRemainder);
          console.log(`\u{1F504} ${groupKey}\u7EC4\u5408\u4F59\u6599 ${remainder.id} \u6807\u8BB0\u4E3A\u4F2A\u4F59\u6599\uFF08\u5DF2\u4F7F\u7528\uFF09`);
        });
        const newRemainders = [];
        let waste = 0;
        if (newRemainderLength > 0) {
          if (newRemainderLength < this.wasteThreshold) {
            waste = newRemainderLength;
          } else {
            const sourceChain = remainders.reduce((chain, r) => chain.concat(r.sourceChain || [r.id]), []);
            const newRemainder = new RemainderV3({
              id: this.generateRemainderID(groupKey),
              length: newRemainderLength,
              type: REMAINDER_TYPES.PENDING,
              // 初始为待定状态
              sourceChain,
              groupKey,
              originalLength: totalLength,
              parentId: remainders.map((r) => r.id).join("+"),
              createdAt: (/* @__PURE__ */ new Date()).toISOString()
            });
            this.remainderPools[groupKey].push(newRemainder);
            this.remainderPools[groupKey].sort((a, b) => a.length - b.length);
            newRemainders.push(newRemainder);
          }
        }
        if (newRemainders.some((r) => r.type === "waste")) {
          throw new Error("newRemainders\u4E2D\u6DF7\u5165\u4E86\u5E9F\u6599\u5BF9\u8C61\uFF01");
        }
        const details = [{
          sourceType: "remainder",
          sourceId: remainders.map((r) => r.id).join("+"),
          sourceLength: totalLength,
          designId,
          length: targetLength,
          quantity: 1,
          groupKey,
          remainderInfo: {
            usedRemainders: remainders,
            newRemainder: newRemainders[0] || null,
            waste
          },
          weldingCount: remainders.length
        }];
        return {
          usedRemainders: remainders,
          newRemainders,
          pseudoRemainders,
          realRemainders: newRemainders,
          // 修正：新产生的可用余料就是realRemainders的候选
          cuttingLength: targetLength,
          waste,
          details
        };
      }
      /**
       * 从组合键余料池中移除指定余料
       */
      removeRemaindersFromPool(indices, groupKey) {
        this.initializePool(groupKey);
        indices.sort((a, b) => b - a);
        indices.forEach((index) => {
          if (index >= 0 && index < this.remainderPools[groupKey].length) {
            const removed = this.remainderPools[groupKey].splice(index, 1)[0];
            console.log(`\u2796 \u4ECE${groupKey}\u7EC4\u5408\u4F59\u6599\u6C60\u4E2D\u79FB\u9664: ${removed.id}`);
          }
        });
      }
      /**
       * 获取所有余料（跨所有组合）
       */
      getAllRemainders() {
        const allRemainders = [];
        for (const [groupKey, remainders] of Object.entries(this.remainderPools)) {
          allRemainders.push(...remainders);
        }
        return allRemainders;
      }
      /**
       * 🔧 修复：生产结束后的余料最终处理
       * ❌ 统计逻辑已移至StatisticsCalculator，此方法仅负责状态更新
       */
      finalizeRemainders() {
        console.log("\n\u{1F3C1} \u5F00\u59CB\u751F\u4EA7\u7ED3\u675F\u540E\u7684\u4F59\u6599\u6700\u7EC8\u72B6\u6001\u786E\u5B9A...");
        let totalProcessedRemainders = 0;
        for (const [groupKey, remainders] of Object.entries(this.remainderPools)) {
          console.log(`
\u{1F4CB} \u5904\u7406 ${groupKey} \u7EC4\u4F59\u6599\u6C60...`);
          const pendingRemainders = remainders.filter((r) => r.type === REMAINDER_TYPES.PENDING);
          console.log(`  - \u6C60\u4E2D\u5F85\u5B9A\u4F59\u6599\u6570\u91CF: ${pendingRemainders.length}`);
          pendingRemainders.forEach((remainder) => {
            if (remainder.length < this.wasteThreshold) {
              remainder.markAsWaste();
              console.log(`  \u{1F5D1}\uFE0F \u4F59\u6599 ${remainder.id} (${remainder.length}mm) \u6700\u7EC8\u786E\u5B9A\u4E3A\u5E9F\u6599 (< ${this.wasteThreshold}mm\u9608\u503C)`);
            } else {
              remainder.markAsReal();
              console.log(`  \u2705 \u4F59\u6599 ${remainder.id} (${remainder.length}mm) \u786E\u5B9A\u4E3A\u771F\u4F59\u6599 (\u2265 ${this.wasteThreshold}mm\u9608\u503C)`);
            }
            totalProcessedRemainders++;
          });
        }
        console.log(`
\u2705 \u4F59\u6599\u72B6\u6001\u786E\u5B9A\u5B8C\u6210\uFF0C\u5904\u7406\u4E86 ${totalProcessedRemainders} \u4E2A\u5F85\u5B9A\u4F59\u6599`);
        console.log(`\u{1F4CA} \u6240\u6709\u7EDF\u8BA1\u8BA1\u7B97\u5C06\u7531StatisticsCalculator\u7EDF\u4E00\u5B8C\u6210`);
        return {
          processedCount: totalProcessedRemainders,
          message: "\u72B6\u6001\u66F4\u65B0\u5B8C\u6210\uFF0C\u7EDF\u8BA1\u8BA1\u7B97\u5DF2\u79FB\u81F3StatisticsCalculator"
        };
      }
      /**
       * 获取规格统计信息
       */
      getStatistics(groupKey = null) {
        if (groupKey) {
          return this.getSpecificationStatistics(groupKey);
        }
        const allStats = {};
        Object.keys(this.remainderPools).forEach((spec) => {
          allStats[spec] = this.getSpecificationStatistics(spec);
        });
        return allStats;
      }
      /**
       * 获取单个规格的统计信息
       */
      getSpecificationStatistics(groupKey) {
        this.initializePool(groupKey);
        const pool = this.remainderPools[groupKey];
        const usage = this.usageHistory[groupKey];
        const stats = {
          groupKey,
          totalRemainders: pool.length,
          realRemainders: pool.filter((r) => r.type === REMAINDER_TYPES.REAL).length,
          pseudoRemainders: pool.filter((r) => r.type === REMAINDER_TYPES.PSEUDO).length,
          wasteRemainders: pool.filter((r) => r.type === REMAINDER_TYPES.WASTE).length,
          pendingRemainders: pool.filter((r) => r.type === REMAINDER_TYPES.PENDING).length,
          totalLength: pool.reduce((sum, r) => sum + r.length, 0),
          realLength: pool.filter((r) => r.type === REMAINDER_TYPES.REAL).reduce((sum, r) => sum + r.length, 0),
          wasteLength: pool.filter((r) => r.type === REMAINDER_TYPES.WASTE).reduce((sum, r) => sum + r.length, 0),
          usageCount: usage.length,
          averageLength: pool.length > 0 ? pool.reduce((sum, r) => sum + r.length, 0) / pool.length : 0
        };
        return stats;
      }
      /**
       * 清空组合键余料池
       */
      clearPool(groupKey = null) {
        if (groupKey) {
          this.remainderPools[groupKey] = [];
          this.remainderCounters[groupKey] = { letterIndex: 0, numbers: {} };
          this.usageHistory[groupKey] = [];
          console.log(`\u{1F9F9} \u6E05\u7A7A${groupKey}\u7EC4\u5408\u4F59\u6599\u6C60`);
        } else {
          this.remainderPools = {};
          this.remainderCounters = {};
          this.usageHistory = {};
          console.log("\u{1F9F9} \u6E05\u7A7A\u6240\u6709\u7EC4\u5408\u952E\u4F59\u6599\u6C60");
        }
      }
      /**
       * 导出池状态
       */
      exportPoolState() {
        const state = {
          timestamp: (/* @__PURE__ */ new Date()).toISOString(),
          groupKeys: Object.keys(this.remainderPools),
          pools: {},
          statistics: {}
        };
        Object.keys(this.remainderPools).forEach((groupKey) => {
          state.pools[groupKey] = this.remainderPools[groupKey].map((r) => ({
            id: r.id,
            length: r.length,
            type: r.type,
            groupKey: r.groupKey,
            sourceChain: r.sourceChain,
            createdAt: r.createdAt
          }));
          state.statistics[groupKey] = this.getSpecificationStatistics(groupKey);
        });
        return state;
      }
    };
    module2.exports = RemainderManager;
  }
});

// core/constraints/ConstraintValidator.js
var require_ConstraintValidator = __commonJS({
  "core/constraints/ConstraintValidator.js"(exports2, module2) {
    var { OptimizationConstraints } = require_types();
    var constraintManager = require_ConstraintManager();
    var ConstraintValidator2 = class {
      constructor() {
        this.validationHistory = [];
      }
      /**
       * 综合验证所有约束条件
       */
      validateAllConstraints(designSteels, moduleSteels, constraints) {
        const results = {
          isValid: true,
          violations: [],
          suggestions: [],
          warnings: []
        };
        const basicValidation = this.validateBasicConstraints(constraints);
        if (!basicValidation.isValid) {
          results.isValid = false;
          results.violations.push(...basicValidation.violations);
        }
        const weldingValidation = this.validateWeldingConstraint(designSteels, moduleSteels, constraints);
        if (!weldingValidation.isValid) {
          results.isValid = false;
          results.violations.push(...weldingValidation.violations);
          results.suggestions.push(...weldingValidation.suggestions);
        }
        const dataValidation = this.validateDataIntegrity(designSteels, moduleSteels);
        if (!dataValidation.isValid) {
          results.isValid = false;
          results.violations.push(...dataValidation.violations);
        }
        results.warnings.push(...this.generateWarnings(designSteels, moduleSteels, constraints));
        this.validationHistory.push({
          timestamp: (/* @__PURE__ */ new Date()).toISOString(),
          result: JSON.parse(JSON.stringify(results))
        });
        return results;
      }
      /**
       * 验证基础约束条件
       */
      validateBasicConstraints(constraints) {
        const violations = [];
        const defaults = constraintManager.getDefaultConstraints();
        const validationLimits = constraintManager.getValidationLimits();
        if (constraints.wasteThreshold <= 0) {
          violations.push({
            type: "wasteThreshold",
            message: "\u5E9F\u6599\u9608\u503C\u5FC5\u987B\u5927\u4E8E0",
            current: constraints.wasteThreshold,
            suggested: defaults.wasteThreshold
          });
        }
        if (constraints.targetLossRate < 0 || constraints.targetLossRate > validationLimits.targetLossRate.max) {
          violations.push({
            type: "targetLossRate",
            message: `\u76EE\u6807\u635F\u8017\u7387\u5FC5\u987B\u57280-${validationLimits.targetLossRate.max}%\u4E4B\u95F4`,
            current: constraints.targetLossRate,
            suggested: defaults.targetLossRate
          });
        }
        if (constraints.timeLimit < validationLimits.timeLimit.min || constraints.timeLimit > validationLimits.timeLimit.max) {
          const minSeconds = constraintManager.msToSeconds(validationLimits.timeLimit.min);
          const maxSeconds = constraintManager.msToSeconds(validationLimits.timeLimit.max);
          violations.push({
            type: "timeLimit",
            message: `\u8BA1\u7B97\u65F6\u95F4\u9650\u5236\u5FC5\u987B\u5728${minSeconds}-${maxSeconds}\u79D2\u8303\u56F4\u5185`,
            current: constraints.timeLimit,
            suggested: defaults.timeLimit
          });
        }
        if (constraints.maxWeldingSegments < 1) {
          violations.push({
            type: "maxWeldingSegments",
            message: "\u6700\u5927\u710A\u63A5\u6BB5\u6570\u5FC5\u987B\u22651",
            current: constraints.maxWeldingSegments,
            suggested: defaults.maxWeldingSegments
          });
        }
        return {
          isValid: violations.length === 0,
          violations
        };
      }
      /**
       * 验证焊接约束W
       * 关键功能：检查W=1时是否存在冲突
       */
      validateWeldingConstraint(designSteels, moduleSteels, constraints) {
        if (moduleSteels.length === 0) {
          return {
            isValid: false,
            violations: [{
              type: "noModuleSteel",
              message: "\u81F3\u5C11\u9700\u8981\u4E00\u79CD\u6A21\u6570\u94A2\u6750",
              suggestions: []
            }],
            suggestions: []
          };
        }
        const maxModuleLength = Math.max(...moduleSteels.map((m) => m.length));
        const maxDesignLength = Math.max(...designSteels.map((d) => d.length));
        const conflictSteels = designSteels.filter((d) => d.length > maxModuleLength);
        if (conflictSteels.length > 0 && constraints.maxWeldingSegments === 1) {
          const requiredLength = Math.max(...conflictSteels.map((s) => s.length));
          const requiredSegments = Math.ceil(maxDesignLength / maxModuleLength);
          return {
            isValid: false,
            violations: [{
              type: "weldingConstraintViolation",
              message: `\u7EA6\u675FW=1\u4E0E\u8BBE\u8BA1\u9700\u6C42\u51B2\u7A81`,
              details: {
                maxModuleLength,
                conflictCount: conflictSteels.length,
                maxConflictLength: requiredLength,
                conflictSteels: conflictSteels.slice(0, 5)
                // 只显示前5个
              }
            }],
            suggestions: [
              {
                type: "addLongerModule",
                priority: 1,
                title: "\u65B9\u6848A\uFF1A\u6DFB\u52A0\u66F4\u957F\u7684\u6A21\u6570\u94A2\u6750",
                description: `\u5EFA\u8BAE\u6DFB\u52A0\u957F\u5EA6\u2265${requiredLength}mm\u7684\u6A21\u6570\u94A2\u6750`,
                details: {
                  requiredLength,
                  currentMaxLength: maxModuleLength,
                  additionalLength: requiredLength - maxModuleLength
                },
                implementation: {
                  action: "addModuleSteel",
                  minLength: requiredLength,
                  recommendedLengths: this.generateRecommendedLengths(requiredLength)
                }
              },
              {
                type: "increaseWelding",
                priority: 2,
                title: "\u65B9\u6848B\uFF1A\u589E\u52A0\u5141\u8BB8\u710A\u63A5\u6BB5\u6570",
                description: `\u5EFA\u8BAE\u5C06\u5141\u8BB8\u710A\u63A5\u6BB5\u6570W\u589E\u52A0\u5230\u2265${requiredSegments}`,
                details: {
                  currentW: constraints.maxWeldingSegments,
                  requiredW: requiredSegments,
                  maxSegmentsNeeded: requiredSegments
                },
                implementation: {
                  action: "updateConstraint",
                  parameter: "maxWeldingSegments",
                  minValue: requiredSegments,
                  recommendedValue: requiredSegments
                }
              }
            ]
          };
        }
        const efficiencyWarnings = this.checkWeldingEfficiency(designSteels, moduleSteels, constraints);
        return {
          isValid: true,
          violations: [],
          suggestions: [],
          efficiencyWarnings
        };
      }
      /**
       * 验证数据完整性
       */
      validateDataIntegrity(designSteels, moduleSteels) {
        const violations = [];
        if (designSteels.length === 0) {
          violations.push({
            type: "noDesignSteel",
            message: "\u81F3\u5C11\u9700\u8981\u4E00\u4E2A\u8BBE\u8BA1\u94A2\u6750"
          });
        }
        designSteels.forEach((steel, index) => {
          if (!steel.length || steel.length <= 0) {
            violations.push({
              type: "invalidDesignLength",
              message: `\u8BBE\u8BA1\u94A2\u6750${index + 1}\uFF1A\u957F\u5EA6\u5FC5\u987B\u5927\u4E8E0`,
              steelIndex: index
            });
          }
          if (!steel.quantity || steel.quantity <= 0) {
            violations.push({
              type: "invalidDesignQuantity",
              message: `\u8BBE\u8BA1\u94A2\u6750${index + 1}\uFF1A\u6570\u91CF\u5FC5\u987B\u5927\u4E8E0`,
              steelIndex: index
            });
          }
          if (!steel.crossSection || steel.crossSection <= 0) {
            violations.push({
              type: "invalidCrossSection",
              message: `\u8BBE\u8BA1\u94A2\u6750${index + 1}\uFF1A\u622A\u9762\u9762\u79EF\u5FC5\u987B\u5927\u4E8E0`,
              steelIndex: index
            });
          }
        });
        if (moduleSteels.length === 0) {
          violations.push({
            type: "noModuleSteel",
            message: "\u81F3\u5C11\u9700\u8981\u4E00\u79CD\u6A21\u6570\u94A2\u6750"
          });
        }
        moduleSteels.forEach((steel, index) => {
          if (!steel.length || steel.length <= 0) {
            violations.push({
              type: "invalidModuleLength",
              message: `\u6A21\u6570\u94A2\u6750${index + 1}\uFF1A\u957F\u5EA6\u5FC5\u987B\u5927\u4E8E0`,
              steelIndex: index
            });
          }
        });
        return {
          isValid: violations.length === 0,
          violations
        };
      }
      /**
       * 生成警告信息
       */
      generateWarnings(designSteels, moduleSteels, constraints) {
        const warnings = [];
        const avgDesignLength = designSteels.reduce((sum, s) => sum + s.length, 0) / designSteels.length;
        const avgModuleLength = moduleSteels.reduce((sum, s) => sum + s.length, 0) / moduleSteels.length;
        if (avgDesignLength < avgModuleLength * 0.3) {
          warnings.push({
            type: "highWasteRisk",
            level: "warning",
            message: "\u8BBE\u8BA1\u94A2\u6750\u5E73\u5747\u957F\u5EA6\u8F83\u77ED\uFF0C\u53EF\u80FD\u5BFC\u81F4\u8F83\u9AD8\u7684\u635F\u8017\u7387",
            suggestion: "\u8003\u8651\u4F18\u5316\u8BBE\u8BA1\u5C3A\u5BF8\u6216\u8C03\u6574\u6A21\u6570\u94A2\u6750\u89C4\u683C"
          });
        }
        if (constraints.maxWeldingSegments === 1 && moduleSteels.length > 1) {
          warnings.push({
            type: "constraintEfficiency",
            level: "info",
            message: "W=1\u4E14\u6709\u591A\u79CD\u6A21\u6570\u94A2\u6750\uFF0C\u7CFB\u7EDF\u5C06\u81EA\u52A8\u9009\u62E9\u6700\u4F18\u89C4\u683C",
            suggestion: "\u8003\u8651\u589E\u52A0W\u503C\u4EE5\u83B7\u5F97\u66F4\u7075\u6D3B\u7684\u4F18\u5316\u7ED3\u679C"
          });
        }
        const totalDesignCount = designSteels.reduce((sum, s) => sum + s.quantity, 0);
        const timeLimitSeconds = constraintManager.msToSeconds(constraints.timeLimit);
        if (timeLimitSeconds < Math.ceil(totalDesignCount / 10) && totalDesignCount > 100) {
          warnings.push({
            type: "timeLimitRisk",
            level: "warning",
            message: "\u8BBE\u8BA1\u94A2\u6750\u6570\u91CF\u8F83\u591A\uFF0C\u5EFA\u8BAE\u589E\u52A0\u65F6\u95F4\u9650\u5236\u4EE5\u83B7\u5F97\u66F4\u597D\u7684\u4F18\u5316\u7ED3\u679C",
            suggestion: `\u5EFA\u8BAE\u65F6\u95F4\u9650\u5236\u8BBE\u7F6E\u4E3A\u2265${Math.ceil(totalDesignCount / 10)}\u79D2`
          });
        }
        return warnings;
      }
      /**
       * 检查焊接效率
       */
      checkWeldingEfficiency(designSteels, moduleSteels, constraints) {
        const warnings = [];
        const maxModuleLength = Math.max(...moduleSteels.map((m) => m.length));
        const needWeldingCount = designSteels.filter((d) => {
          const segmentsNeeded = Math.ceil(d.length / maxModuleLength);
          return segmentsNeeded > constraints.maxWeldingSegments;
        }).length;
        if (needWeldingCount > 0) {
          warnings.push({
            type: "weldingEfficiency",
            level: "info",
            message: `\u6709${needWeldingCount}\u4E2A\u8BBE\u8BA1\u94A2\u6750\u53EF\u80FD\u9700\u8981\u66F4\u591A\u710A\u63A5\u6BB5\u6570`,
            details: { needWeldingCount, totalCount: designSteels.length }
          });
        }
        return warnings;
      }
      /**
       * 生成推荐的模数钢材长度
       */
      generateRecommendedLengths(requiredLength) {
        const standardLengths = constraintManager.getStandardSteelLengths();
        const recommended = [];
        recommended.push(requiredLength);
        standardLengths.forEach((length) => {
          if (length >= requiredLength && !recommended.includes(length)) {
            recommended.push(length);
          }
        });
        return recommended.sort((a, b) => a - b).slice(0, 3);
      }
      /**
       * 获取约束违规的用户友好描述
       */
      getViolationSummary(violations) {
        if (violations.length === 0) {
          return "\u6240\u6709\u7EA6\u675F\u6761\u4EF6\u5747\u5DF2\u6EE1\u8DB3";
        }
        const categories = {
          critical: [],
          warning: [],
          info: []
        };
        violations.forEach((violation) => {
          const severity = this.getViolationSeverity(violation.type);
          categories[severity].push(violation);
        });
        let summary = "";
        if (categories.critical.length > 0) {
          summary += `\u274C ${categories.critical.length}\u4E2A\u4E25\u91CD\u95EE\u9898\u9700\u8981\u89E3\u51B3
`;
        }
        if (categories.warning.length > 0) {
          summary += `\u26A0\uFE0F ${categories.warning.length}\u4E2A\u8B66\u544A
`;
        }
        if (categories.info.length > 0) {
          summary += `\u2139\uFE0F ${categories.info.length}\u4E2A\u63D0\u793A`;
        }
        return summary.trim();
      }
      /**
       * 获取违规严重程度
       */
      getViolationSeverity(violationType) {
        const severityMap = {
          "weldingConstraintViolation": "critical",
          "noDesignSteel": "critical",
          "noModuleSteel": "critical",
          "invalidDesignLength": "critical",
          "invalidDesignQuantity": "critical",
          "invalidCrossSection": "critical",
          "invalidModuleLength": "critical",
          "wasteThreshold": "warning",
          "targetLossRate": "warning",
          "timeLimit": "warning",
          "maxWeldingSegments": "warning"
        };
        return severityMap[violationType] || "info";
      }
      /**
       * 清空验证历史
       */
      clearHistory() {
        this.validationHistory = [];
      }
      /**
       * 获取验证历史
       */
      getValidationHistory() {
        return this.validationHistory.slice();
      }
    };
    module2.exports = ConstraintValidator2;
  }
});

// core/optimizer/ParallelOptimizationMonitor.js
var require_ParallelOptimizationMonitor = __commonJS({
  "core/optimizer/ParallelOptimizationMonitor.js"(exports2, module2) {
    var ParallelOptimizationMonitor = class {
      constructor() {
        this.tasks = /* @__PURE__ */ new Map();
        this.globalStats = {
          totalTasks: 0,
          completedTasks: 0,
          failedTasks: 0,
          totalExecutionTime: 0,
          averageExecutionTime: 0,
          maxExecutionTime: 0,
          minExecutionTime: Infinity,
          parallelEfficiency: 0
        };
        this.startTime = null;
        this.endTime = null;
      }
      /**
       * 开始监控并行计算
       */
      startMonitoring(taskCount) {
        this.startTime = Date.now();
        this.globalStats.totalTasks = taskCount;
        console.log(`\u{1F4CA} V3\u5E76\u884C\u8BA1\u7B97\u76D1\u63A7\u542F\u52A8: ${taskCount}\u4E2A\u4EFB\u52A1\u5C06\u5E76\u884C\u6267\u884C`);
        for (let i = 0; i < taskCount; i++) {
          this.tasks.set(`task_${i}`, {
            index: i,
            status: "pending",
            startTime: null,
            endTime: null,
            executionTime: 0,
            groupKey: null,
            steelsCount: 0,
            cuts: 0,
            error: null
          });
        }
      }
      /**
       * 记录任务开始
       */
      recordTaskStart(taskIndex, groupKey, steelsCount) {
        const task = this.tasks.get(`task_${taskIndex}`);
        if (task) {
          task.status = "running";
          task.startTime = Date.now();
          task.groupKey = groupKey;
          task.steelsCount = steelsCount;
          console.log(`\u{1F680} \u4EFB\u52A1${taskIndex}\u5F00\u59CB: ${groupKey} (${steelsCount}\u79CD\u94A2\u6750)`);
        }
      }
      /**
       * 记录任务完成
       */
      recordTaskCompletion(taskIndex, stats) {
        const task = this.tasks.get(`task_${taskIndex}`);
        if (task) {
          task.status = "completed";
          task.endTime = Date.now();
          task.executionTime = task.endTime - task.startTime;
          task.cuts = stats.cuts;
          this.globalStats.completedTasks++;
          this.updateGlobalStats(task.executionTime);
          console.log(`\u2705 \u4EFB\u52A1${taskIndex}\u5B8C\u6210: ${task.groupKey} (${task.executionTime}ms, ${stats.cuts}\u6B21\u5207\u5272)`);
        }
      }
      /**
       * 记录任务失败
       */
      recordTaskFailure(taskIndex, error) {
        const task = this.tasks.get(`task_${taskIndex}`);
        if (task) {
          task.status = "failed";
          task.endTime = Date.now();
          task.executionTime = task.endTime - task.startTime;
          task.error = error;
          this.globalStats.failedTasks++;
          console.error(`\u274C \u4EFB\u52A1${taskIndex}\u5931\u8D25: ${task.groupKey} - ${error}`);
        }
      }
      /**
       * 更新全局统计
       */
      updateGlobalStats(executionTime) {
        this.globalStats.totalExecutionTime += executionTime;
        this.globalStats.averageExecutionTime = this.globalStats.totalExecutionTime / this.globalStats.completedTasks;
        if (executionTime > this.globalStats.maxExecutionTime) {
          this.globalStats.maxExecutionTime = executionTime;
        }
        if (executionTime < this.globalStats.minExecutionTime) {
          this.globalStats.minExecutionTime = executionTime;
        }
      }
      /**
       * 完成监控
       */
      finishMonitoring() {
        this.endTime = Date.now();
        const totalWallTime = this.endTime - this.startTime;
        const sequentialTime = this.globalStats.totalExecutionTime;
        this.globalStats.parallelEfficiency = sequentialTime > 0 ? sequentialTime / totalWallTime * 100 : 0;
        console.log(`\u{1F3C1} V3\u5E76\u884C\u8BA1\u7B97\u76D1\u63A7\u5B8C\u6210:`);
        console.log(`   \u603B\u5899\u949F\u65F6\u95F4: ${totalWallTime}ms`);
        console.log(`   \u603BCPU\u65F6\u95F4: ${sequentialTime}ms`);
        console.log(`   \u5E76\u884C\u6548\u7387: ${this.globalStats.parallelEfficiency.toFixed(2)}%`);
        console.log(`   \u6210\u529F\u4EFB\u52A1: ${this.globalStats.completedTasks}/${this.globalStats.totalTasks}`);
        console.log(`   \u5931\u8D25\u4EFB\u52A1: ${this.globalStats.failedTasks}/${this.globalStats.totalTasks}`);
        return this.generateReport();
      }
      /**
       * 生成详细报告
       */
      generateReport() {
        const report = {
          summary: {
            totalTasks: this.globalStats.totalTasks,
            successfulTasks: this.globalStats.completedTasks,
            failedTasks: this.globalStats.failedTasks,
            successRate: this.globalStats.completedTasks / this.globalStats.totalTasks * 100,
            totalWallTime: this.endTime - this.startTime,
            totalCpuTime: this.globalStats.totalExecutionTime,
            parallelEfficiency: this.globalStats.parallelEfficiency,
            averageTaskTime: this.globalStats.averageExecutionTime,
            maxTaskTime: this.globalStats.maxExecutionTime,
            minTaskTime: this.globalStats.minExecutionTime === Infinity ? 0 : this.globalStats.minExecutionTime
          },
          taskDetails: [],
          performance: {
            speedup: this.calculateSpeedup(),
            efficiency: this.calculateEfficiency(),
            scalability: this.calculateScalability()
          }
        };
        this.tasks.forEach((task, taskId) => {
          report.taskDetails.push({
            taskId,
            groupKey: task.groupKey,
            status: task.status,
            executionTime: task.executionTime,
            steelsCount: task.steelsCount,
            cuts: task.cuts,
            error: task.error
          });
        });
        report.taskDetails.sort((a, b) => b.executionTime - a.executionTime);
        return report;
      }
      /**
       * 计算加速比
       */
      calculateSpeedup() {
        const wallTime = this.endTime - this.startTime;
        const cpuTime = this.globalStats.totalExecutionTime;
        return cpuTime > 0 ? cpuTime / wallTime : 1;
      }
      /**
       * 计算效率
       */
      calculateEfficiency() {
        const speedup = this.calculateSpeedup();
        return speedup / this.globalStats.totalTasks;
      }
      /**
       * 计算可扩展性指标
       */
      calculateScalability() {
        const efficiency = this.calculateEfficiency();
        return {
          efficiency,
          rating: efficiency > 0.8 ? "excellent" : efficiency > 0.6 ? "good" : efficiency > 0.4 ? "fair" : "poor"
        };
      }
      /**
       * 获取实时状态
       */
      getRealtimeStatus() {
        const runningTasks = Array.from(this.tasks.values()).filter((t) => t.status === "running");
        const completedTasks = Array.from(this.tasks.values()).filter((t) => t.status === "completed");
        const failedTasks = Array.from(this.tasks.values()).filter((t) => t.status === "failed");
        return {
          total: this.globalStats.totalTasks,
          running: runningTasks.length,
          completed: completedTasks.length,
          failed: failedTasks.length,
          progress: (completedTasks.length + failedTasks.length) / this.globalStats.totalTasks * 100
        };
      }
      /**
       * 输出性能报告到控制台
       */
      printPerformanceReport() {
        const report = this.generateReport();
        console.log("\n\u{1F4CA} ==================== V3\u5E76\u884C\u8BA1\u7B97\u6027\u80FD\u62A5\u544A ====================");
        console.log(`\u{1F3AF} \u603B\u4F53\u8868\u73B0:`);
        console.log(`   \u4EFB\u52A1\u603B\u6570: ${report.summary.totalTasks}`);
        console.log(`   \u6210\u529F\u7387: ${report.summary.successRate.toFixed(2)}%`);
        console.log(`   \u603B\u5899\u949F\u65F6\u95F4: ${report.summary.totalWallTime}ms`);
        console.log(`   \u5E76\u884C\u6548\u7387: ${report.summary.parallelEfficiency.toFixed(2)}%`);
        console.log(`   \u52A0\u901F\u6BD4: ${report.performance.speedup.toFixed(2)}x`);
        console.log(`   \u6548\u7387\u8BC4\u7EA7: ${report.performance.scalability.rating}`);
        console.log(`
\u23F1\uFE0F \u4EFB\u52A1\u65F6\u95F4\u5206\u6790:`);
        console.log(`   \u5E73\u5747\u6267\u884C\u65F6\u95F4: ${report.summary.averageTaskTime.toFixed(2)}ms`);
        console.log(`   \u6700\u957F\u6267\u884C\u65F6\u95F4: ${report.summary.maxTaskTime}ms`);
        console.log(`   \u6700\u77ED\u6267\u884C\u65F6\u95F4: ${report.summary.minTaskTime}ms`);
        console.log(`
\u{1F3C6} \u6027\u80FD\u6700\u4F73\u4EFB\u52A1:`);
        const bestTasks = report.taskDetails.filter((t) => t.status === "completed").slice(0, 3);
        bestTasks.forEach((task, index) => {
          console.log(`   ${index + 1}. ${task.groupKey}: ${task.executionTime}ms (${task.cuts}\u6B21\u5207\u5272)`);
        });
        if (report.summary.failedTasks > 0) {
          console.log(`
\u274C \u5931\u8D25\u4EFB\u52A1:`);
          const failedTasks = report.taskDetails.filter((t) => t.status === "failed");
          failedTasks.forEach((task) => {
            console.log(`   ${task.groupKey}: ${task.error}`);
          });
        }
        console.log("============================================================\n");
      }
    };
    module2.exports = ParallelOptimizationMonitor;
  }
});

// core/optimizer/SteelOptimizerV3.js
var require_SteelOptimizerV3 = __commonJS({
  "core/optimizer/SteelOptimizerV3.js"(exports2, module2) {
    var {
      DesignSteel,
      ModuleSteel,
      RemainderV3,
      OptimizationSolution,
      OptimizationResult,
      CuttingPlan,
      CuttingDetail,
      REMAINDER_TYPES,
      SOURCE_TYPES,
      OptimizationConstraints
    } = require_types();
    var ResultBuilder = require_ResultBuilder();
    var RemainderManager = require_RemainderManager();
    var ConstraintValidator2 = require_ConstraintValidator();
    var ParallelOptimizationMonitor = require_ParallelOptimizationMonitor();
    var constraintManager = require_ConstraintManager();
    var { v4: uuidv4 } = (init_esm_node(), __toCommonJS(esm_node_exports));
    var SteelOptimizerV32 = class {
      constructor(designSteels, moduleSteels, constraints) {
        this.designSteels = designSteels;
        this.moduleSteels = moduleSteels;
        this.constraints = constraints;
        this.startTime = Date.now();
        this.resultBuilder = new ResultBuilder();
        this.moduleCounters = {};
        this.moduleSteelPools = /* @__PURE__ */ new Map();
        this.availableLengths = this.extractAvailableLengths(moduleSteels);
        console.log("\u{1F3AF} V3\u89C4\u683C\u5316\u4F18\u5316\u5668\u521D\u59CB\u5316\u5B8C\u6210");
        console.log(`\u{1F4CA} \u53EF\u7528\u6A21\u6570\u94A2\u6750\u957F\u5EA6: ${this.availableLengths.join(", ")}mm`);
        this.remainderManager = new RemainderManager(constraints.wasteThreshold);
        this.constraintValidator = new ConstraintValidator2();
        this.parallelMonitor = new ParallelOptimizationMonitor();
        this.executionStats = {
          totalCuts: 0,
          remaindersGenerated: 0,
          remaindersReused: 0,
          weldingOperations: 0
        };
      }
      /**
       * 从原始模数钢材中提取可用长度
       */
      extractAvailableLengths(moduleSteels) {
        const lengths = moduleSteels.map((m) => m.length);
        return [...new Set(lengths)].sort((a, b) => a - b);
      }
      /**
       * 获取或创建规格化模数钢材池
       */
      getOrCreateModuleSteelPool(groupKey) {
        if (!this.moduleSteelPools.has(groupKey)) {
          const [specification, crossSection] = this.parseGroupKey(groupKey);
          const pool = new SpecificationModuleSteelPool(
            specification,
            parseFloat(crossSection),
            this.availableLengths
          );
          this.moduleSteelPools.set(groupKey, pool);
          console.log(`\u{1F527} \u521B\u5EFA\u89C4\u683C\u5316\u6A21\u6570\u94A2\u6750\u6C60: ${groupKey}`);
        }
        return this.moduleSteelPools.get(groupKey);
      }
      /**
       * 解析组合键
       */
      parseGroupKey(groupKey) {
        const parts = groupKey.split("_");
        return [parts[0], parts[1]];
      }
      /**
       * 主优化入口
       */
      async optimize() {
        console.log("\u{1F680} \u542F\u52A8\u94A2\u6750\u4F18\u5316\u7B97\u6CD5 V3.0");
        try {
          const validation = this.constraintValidator.validateAllConstraints(
            this.designSteels,
            this.moduleSteels,
            this.constraints
          );
          if (!validation.isValid) {
            console.error("\u274C \u7EA6\u675F\u6761\u4EF6\u9A8C\u8BC1\u5931\u8D25");
            return {
              success: false,
              error: "\u7EA6\u675F\u6761\u4EF6\u9A8C\u8BC1\u5931\u8D25",
              validation
              // 确保返回完整的验证对象
            };
          }
          const solutions = await this.optimizeByGroups();
          console.log("\n\u{1F3C1} \u6240\u6709\u7EC4\u5408\u4F18\u5316\u5B8C\u6210\uFF0C\u5F00\u59CB\u4F59\u6599\u6700\u7EC8\u5904\u7406...");
          const finalRemainderStats = this.remainderManager.finalizeRemainders();
          this.updateCuttingPlansRemainderStatus(solutions);
          console.log("\n\u2705 MW-CD\u4EA4\u6362\u4F18\u5316\u5DF2\u5728\u5404\u7EC4\u5408\u5185\u90E8\u5B8C\u6210");
          const result = this.buildOptimizationResult(solutions, validation);
          const statisticsResult = this.resultBuilder.statisticsCalculator.calculateAllStatistics(solutions, this.remainderManager);
          const lossRateValidation = this.resultBuilder.statisticsCalculator.validateLossRateCalculation(statisticsResult.specificationStats);
          if (!lossRateValidation.isValid) {
            console.warn("\u26A0\uFE0F \u635F\u8017\u7387\u8BA1\u7B97\u9A8C\u8BC1\u5931\u8D25:", lossRateValidation.errorMessage);
          }
          result.lossRateValidation = lossRateValidation;
          result.constraintValidation = validation;
          console.log("\u{1F389} \u4F18\u5316\u5B8C\u6210");
          return {
            success: true,
            result,
            stats: this.executionStats
          };
        } catch (error) {
          console.error("\u274C \u4F18\u5316\u8FC7\u7A0B\u51FA\u9519:", error);
          return {
            success: false,
            error: error.message,
            stack: error.stack
          };
        }
      }
      /**
       * V3并行计算框架：按规格+截面面积组合并行优化
       */
      async optimizeByGroups() {
        const groups = this.groupBySpecificationAndCrossSection();
        const groupKeys = Object.keys(groups);
        this.parallelMonitor.startMonitoring(groupKeys.length);
        console.log(`\u{1F680} \u542F\u52A8V3\u5E76\u884C\u8BA1\u7B97\u6846\u67B6\uFF0C\u5171${groupKeys.length}\u4E2A\u89C4\u683C\u7EC4\u5408\u5C06\u5E76\u884C\u4F18\u5316`);
        const parallelTasks = groupKeys.map(
          (groupKey, index) => this.createMonitoredParallelTask(groupKey, groups[groupKey], index)
        );
        const parallelResults = await Promise.allSettled(parallelTasks);
        const solutions = {};
        const parallelStats = {
          successful: 0,
          failed: 0,
          totalGroups: groupKeys.length,
          errors: []
        };
        parallelResults.forEach((result, index) => {
          const groupKey = groupKeys[index];
          if (result.status === "fulfilled") {
            solutions[groupKey] = result.value.solution;
            parallelStats.successful++;
            this.parallelMonitor.recordTaskCompletion(index, result.value.stats);
            if (result.value.remainderManager) {
              this.mergeRemainderManager(result.value.remainderManager, groupKey);
            }
          } else {
            parallelStats.failed++;
            parallelStats.errors.push({
              groupKey,
              error: result.reason.message || result.reason
            });
            this.parallelMonitor.recordTaskFailure(index, result.reason.message || result.reason);
            solutions[groupKey] = new OptimizationSolution({});
          }
        });
        const performanceReport = this.parallelMonitor.finishMonitoring();
        this.parallelMonitor.printPerformanceReport();
        console.log(`\u{1F3C1} V3\u5E76\u884C\u8BA1\u7B97\u5B8C\u6210: ${parallelStats.successful}\u6210\u529F/${parallelStats.failed}\u5931\u8D25\uFF0C\u5171${parallelStats.totalGroups}\u4E2A\u7EC4\u5408`);
        if (parallelStats.failed > 0) {
          console.warn("\u26A0\uFE0F \u5E76\u884C\u8BA1\u7B97\u4E2D\u7684\u5931\u8D25\u4EFB\u52A1:", parallelStats.errors);
        }
        return solutions;
      }
      /**
       * 创建带监控的并行任务
       */
      async createMonitoredParallelTask(groupKey, steels, taskIndex) {
        this.parallelMonitor.recordTaskStart(taskIndex, groupKey, steels.length);
        try {
          return await this.createParallelOptimizationTask(groupKey, steels);
        } catch (error) {
          throw error;
        }
      }
      /**
       * 创建独立的并行优化任务
       */
      async createParallelOptimizationTask(groupKey, steels) {
        const taskStartTime = Date.now();
        try {
          const independentRemainderManager = this.createIndependentRemainderManager(groupKey);
          const taskStats = {
            groupKey,
            steelsCount: steels.length,
            cuts: 0,
            remaindersGenerated: 0,
            remaindersReused: 0,
            weldingOperations: 0
          };
          console.log(`\u{1F527} \u5E76\u884C\u4EFB\u52A1\u542F\u52A8: ${groupKey} (${steels.length}\u79CD\u8BBE\u8BA1\u94A2\u6750)`);
          const solution = await this.optimizeGroupIndependently(
            steels,
            groupKey,
            independentRemainderManager,
            taskStats
          );
          const executionTime = Date.now() - taskStartTime;
          taskStats.executionTime = executionTime;
          return {
            solution,
            stats: taskStats,
            remainderManager: independentRemainderManager
          };
        } catch (error) {
          console.error(`\u{1F4A5} \u5E76\u884C\u4EFB\u52A1\u5F02\u5E38: ${groupKey} - ${error.message}`);
          throw new Error(`\u5E76\u884C\u4F18\u5316\u5931\u8D25[${groupKey}]: ${error.message}`);
        }
      }
      /**
       * 创建独立的余料管理器实例
       */
      createIndependentRemainderManager(groupKey) {
        const independentManager = new RemainderManager(this.constraints.wasteThreshold);
        independentManager.initializePool(groupKey);
        console.log(`\u{1F527} \u4E3A${groupKey}\u521B\u5EFA\u72EC\u7ACB\u4F59\u6599\u7BA1\u7406\u5668`);
        return independentManager;
      }
      /**
       * 🔧 关键修复：合并独立余料管理器的数据到主余料管理器
       */
      mergeRemainderManager(independentManager, groupKey) {
        console.log(`\u{1F504} \u5408\u5E76\u72EC\u7ACB\u4F59\u6599\u7BA1\u7406\u5668\u6570\u636E: ${groupKey}`);
        const independentPool = independentManager.remainderPools[groupKey] || [];
        if (independentPool.length > 0) {
          this.remainderManager.initializePool(groupKey);
          independentPool.forEach((remainder) => {
            this.remainderManager.remainderPools[groupKey].push(remainder);
            console.log(`  \u2795 \u5408\u5E76\u4F59\u6599: ${remainder.id} (${remainder.length}mm, \u7C7B\u578B: ${remainder.type})`);
          });
          console.log(`\u2705 \u5DF2\u5408\u5E76 ${independentPool.length} \u4E2A\u4F59\u6599\u5230\u4E3B\u7BA1\u7406\u5668`);
        } else {
          console.log(`  - ${groupKey} \u7EC4\u5408\u6CA1\u6709\u4F59\u6599\u9700\u8981\u5408\u5E76`);
        }
      }
      /**
       * 🔧 关键修复：更新所有切割计划中的余料状态
       * 在finalizeRemainders之后，将切割计划中pending状态的余料更新为正确状态
       */
      updateCuttingPlansRemainderStatus(solutions) {
        console.log("\n\u{1F504} \u66F4\u65B0\u5207\u5272\u8BA1\u5212\u4E2D\u7684\u4F59\u6599\u72B6\u6001...");
        let updatedCount = 0;
        const allFinalizedRemainders = this.remainderManager.getAllRemainders();
        const remainderMap = /* @__PURE__ */ new Map();
        allFinalizedRemainders.forEach((remainder) => {
          remainderMap.set(remainder.id, remainder);
        });
        console.log(`\u{1F4CB} \u4E3B\u4F59\u6599\u7BA1\u7406\u5668\u4E2D\u5171\u6709 ${allFinalizedRemainders.length} \u4E2A\u5DF2\u6700\u7EC8\u5316\u7684\u4F59\u6599`);
        Object.entries(solutions).forEach(([groupKey, solution]) => {
          solution.cuttingPlans?.forEach((plan, planIndex) => {
            if (plan.newRemainders && plan.newRemainders.length > 0) {
              plan.newRemainders.forEach((remainder, remainderIndex) => {
                const finalizedRemainder = remainderMap.get(remainder.id);
                if (finalizedRemainder && remainder.type !== finalizedRemainder.type) {
                  console.log(`  \u{1F504} \u66F4\u65B0\u4F59\u6599\u72B6\u6001: ${remainder.id} (${remainder.type} \u2192 ${finalizedRemainder.type})`);
                  remainder.type = finalizedRemainder.type;
                  updatedCount++;
                } else if (!finalizedRemainder) {
                  console.log(`  \u26A0\uFE0F \u4F59\u6599 ${remainder.id} \u5728\u4E3B\u7BA1\u7406\u5668\u4E2D\u672A\u627E\u5230\uFF0C\u53EF\u80FD\u5DF2\u88AB\u4F7F\u7528`);
                }
              });
            }
            if (plan.realRemainders && plan.realRemainders.length > 0) {
              plan.realRemainders.forEach((remainder) => {
                const finalizedRemainder = remainderMap.get(remainder.id);
                if (finalizedRemainder && remainder.type !== finalizedRemainder.type) {
                  console.log(`  \u{1F504} \u66F4\u65B0\u771F\u4F59\u6599\u72B6\u6001: ${remainder.id} (${remainder.type} \u2192 ${finalizedRemainder.type})`);
                  remainder.type = finalizedRemainder.type;
                  updatedCount++;
                }
              });
            }
          });
        });
        console.log(`\u2705 \u5207\u5272\u8BA1\u5212\u4F59\u6599\u72B6\u6001\u66F4\u65B0\u5B8C\u6210\uFF0C\u5171\u66F4\u65B0 ${updatedCount} \u4E2A\u4F59\u6599`);
      }
      /**
       * 独立优化单个规格+截面面积组合（并行安全）- V3.1 装箱算法
       * @description 使用首次适应递减(FFD)启发式算法，取代原有的贪婪策略，以获得更好的全局优化效果。
       */
      async optimizeGroupIndependently(steels, groupKey, remainderManager, taskStats) {
        const solution = new OptimizationSolution({});
        let unfulfilledDemands = this.createFlatDemandList(steels);
        unfulfilledDemands.sort((a, b) => b.length - a.length);
        let binCount = 0;
        while (unfulfilledDemands.length > 0 && !this.isTimeExceeded()) {
          binCount++;
          const longestDemand = unfulfilledDemands[0];
          let sourceMaterial = null;
          let sourceType = "";
          let usedRemaindersList = [];
          const bestRemainder = remainderManager.findBestSingleRemainder(longestDemand.length, groupKey);
          if (bestRemainder) {
            sourceMaterial = bestRemainder;
            sourceType = "remainder";
            usedRemaindersList = [bestRemainder];
            remainderManager.useSingleRemainder(bestRemainder.id, groupKey);
            taskStats.remaindersReused = (taskStats.remaindersReused || 0) + 1;
          } else {
            const bestCombination = remainderManager.findBestRemainderCombination(
              longestDemand.length,
              groupKey,
              this.constraints.maxWeldingSegments
              // 关键：传入焊接段数约束
            );
            if (bestCombination) {
              sourceType = "remainder";
              bestCombination.remainders.forEach((r) => r.markAsPseudo());
              remainderManager.removeRemaindersFromPool(bestCombination.indices, groupKey);
              sourceMaterial = {
                id: bestCombination.remainders.map((r) => r.id).join("+"),
                length: bestCombination.totalLength,
                crossSection: this.parseGroupKey(groupKey)[1]
              };
              usedRemaindersList = bestCombination.remainders;
              taskStats.remaindersReused = (taskStats.remaindersReused || 0) + bestCombination.remainders.length;
              if (bestCombination.remainders.length > 1) {
                taskStats.weldingOperations = (taskStats.weldingOperations || 0) + 1;
              }
            } else {
              const newModule = this.selectBestModule(longestDemand, groupKey, unfulfilledDemands, true);
              if (!newModule) {
                console.error(`\u274C \u4E25\u91CD\u9519\u8BEF: \u65E0\u6CD5\u4E3A\u9700\u6C42 ${longestDemand.length}mm (\u7EC4: ${groupKey}) \u9009\u62E9\u6A21\u6570\u94A2\u6750\u3002`);
                break;
              }
              sourceMaterial = newModule;
              sourceType = "module";
              taskStats.moduleSteelsUsed = (taskStats.moduleSteelsUsed || 0) + 1;
              taskStats.totalModuleLength = (taskStats.totalModuleLength || 0) + newModule.length;
            }
          }
          const cuts = [];
          let remainingLength = sourceMaterial.length;
          const packedDemandUniqueIds = /* @__PURE__ */ new Set();
          for (const demand of unfulfilledDemands) {
            if (demand.length <= remainingLength) {
              cuts.push({ designId: demand.id, length: demand.length, quantity: 1 });
              remainingLength -= demand.length;
              packedDemandUniqueIds.add(demand.uniqueId);
              solution.details.push(new CuttingDetail({
                sourceType,
                sourceId: sourceMaterial.id,
                sourceLength: sourceMaterial.length,
                designId: demand.id,
                length: demand.length,
                quantity: 1,
                weldingCount: 1
              }));
            }
          }
          unfulfilledDemands = unfulfilledDemands.filter((d) => !packedDemandUniqueIds.has(d.uniqueId));
          let waste = 0;
          const newRemainders = [];
          if (remainingLength > 0) {
            const remainderToEvaluate = new RemainderV3({
              id: `${sourceMaterial.id}_rem`,
              length: remainingLength,
              type: REMAINDER_TYPES.PENDING,
              sourceChain: [sourceMaterial.id],
              crossSection: sourceMaterial.crossSection || this.parseGroupKey(groupKey)[1],
              specification: groupKey,
              createdAt: (/* @__PURE__ */ new Date()).toISOString(),
              originalLength: sourceMaterial.length,
              parentId: sourceMaterial.id
            });
            const evalResult = remainderManager.evaluateAndProcessRemainder(remainderToEvaluate, groupKey, { source: `${sourceType}\u5207\u5272\u540E` });
            if (evalResult.isWaste) {
              waste = evalResult.wasteLength;
              taskStats.wasteGenerated = (taskStats.wasteGenerated || 0) + waste;
            } else if (evalResult.isPendingRemainder) {
              newRemainders.push(remainderToEvaluate);
            }
          }
          const cuttingPlan = new CuttingPlan({
            sourceType,
            sourceId: sourceMaterial.id,
            sourceDescription: `${groupKey}\u7EC4\u5408${sourceType} ${sourceMaterial.id}`,
            sourceLength: sourceMaterial.length,
            cuts: this.groupCuts(cuts),
            // 将单个切割合并为带数量的
            newRemainders,
            realRemainders: newRemainders,
            waste,
            usedRemainders: usedRemaindersList,
            moduleLength: sourceType === "module" ? sourceMaterial.length : void 0,
            moduleType: sourceType === "module" ? sourceMaterial.name : void 0
          });
          solution.cuttingPlans.push(cuttingPlan);
          taskStats.cuts += 1;
        }
        if (unfulfilledDemands.length > 0) {
          console.error(`\u274C \u9700\u6C42\u672A\u5B8C\u5168\u6EE1\u8DB3\uFF0C\u7EC4: ${groupKey}\u3002\u5269\u4F59\u6570\u91CF: ${unfulfilledDemands.length}`);
        }
        console.log(`
\u{1F504} ${groupKey}\u7EC4\u5408\u5185\u90E8MW-CD\u4EA4\u6362\u4F18\u5316...`);
        const mwcdStats = await this.performInternalMWCDOptimization(solution, groupKey, remainderManager);
        if (mwcdStats.exchangesPerformed > 0) {
          console.log(`\u2705 ${groupKey}\u7EC4\u5408\u5B8C\u6210${mwcdStats.exchangesPerformed}\u6B21\u5185\u90E8\u4EA4\u6362\uFF0C\u6548\u76CA\u63D0\u5347${mwcdStats.totalBenefitGained.toFixed(2)}mm`);
        }
        this.mergeTaskStatsToSolution(solution, taskStats);
        console.log(`\u2705 \u5E76\u884C\u4EFB\u52A1${groupKey}\u4F18\u5316\u5B8C\u6210: \u4F7F\u7528\u4E86 ${binCount} \u4E2A\u539F\u6750\u6599, \u5B8C\u6210 ${mwcdStats.exchangesPerformed} \u6B21\u5185\u90E8\u4EA4\u6362`);
        return solution;
      }
      /**
       * 将taskStats数据汇总到solution对象，解决"数据孤岛"问题
       */
      mergeTaskStatsToSolution(solution, taskStats) {
        console.log(`\u{1F504} \u5408\u5E76taskStats\u6570\u636E\u5230solution\u5BF9\u8C61:`);
        console.log(`  - taskStats.cuts: ${taskStats.cuts}`);
        console.log(`  - taskStats.moduleSteelsUsed: ${taskStats.moduleSteelsUsed}`);
        console.log(`  - taskStats.totalModuleLength: ${taskStats.totalModuleLength}`);
        console.log(`  - taskStats.wasteGenerated: ${taskStats.wasteGenerated}`);
        console.log(`  - taskStats.remaindersReused: ${taskStats.remaindersReused}`);
        console.log(`  - taskStats.weldingOperations: ${taskStats.weldingOperations}`);
        solution.taskStats = solution.taskStats || {
          totalCuts: 0,
          totalModuleSteelsUsed: 0,
          totalModuleLength: 0,
          totalWasteGenerated: 0,
          totalRemaindersReused: 0,
          totalWeldingOperations: 0
        };
        solution.taskStats.totalCuts += taskStats.cuts || 0;
        solution.taskStats.totalModuleSteelsUsed += taskStats.moduleSteelsUsed || 0;
        solution.taskStats.totalModuleLength += taskStats.totalModuleLength || 0;
        solution.taskStats.totalRemaindersReused += taskStats.remaindersReused || 0;
        solution.taskStats.totalWeldingOperations += taskStats.weldingOperations || 0;
        console.log(`\u2705 taskStats\u6570\u636E\u5DF2\u5408\u5E76\u5230solution.taskStats`);
      }
      /**
       * [V3.2] 智能选择最佳模数钢材 (使用"向前看"决策)
       * @description 不再只选最短够用的，而是对每个候选模数钢材进行虚拟装箱，选出潜在利用率最高的。
       */
      selectBestModule(longestDemand, groupKey, unfulfilledDemands, force = false) {
        const pool = this.getOrCreateModuleSteelPool(groupKey);
        const availableModuleLengths = pool.availableLengths;
        const candidates = availableModuleLengths.filter((len) => len >= longestDemand.length);
        if (candidates.length === 0) {
          if (force) {
            const maxLength = Math.max(...availableModuleLengths);
            console.warn(`\u26A0\uFE0F (\u5F3A\u5236\u6A21\u5F0F) \u9700\u6C42 ${longestDemand.length}mm \u8FC7\u957F\uFF0C\u6240\u6709\u6A21\u6570\u94A2\u6750\u5747\u4E0D\u6EE1\u8DB3\u3002\u5C06\u5C1D\u8BD5\u4F7F\u7528\u6700\u957F\u7684 ${maxLength}mm`);
            return pool.createSteel(maxLength);
          }
          return null;
        }
        if (candidates.length === 1) {
          const bestLength = candidates[0];
          console.log(`\u{1F3AF} \u53EA\u6709\u4E00\u4E2A\u5019\u9009\u6A21\u6570\u94A2\u6750 (${bestLength}mm), \u76F4\u63A5\u9009\u62E9\u3002`);
          return pool.createSteel(bestLength);
        }
        let bestChoice = {
          length: -1,
          utilization: -1
        };
        console.log(`\u{1F9D0} [\u5411\u524D\u770B] \u5F00\u59CB\u8BC4\u4F30 ${candidates.length} \u4E2A\u5019\u9009\u6A21\u6570\u94A2\u6750...`);
        for (const candidateLength of candidates) {
          const { packedLength } = this.calculatePotentialUtilization(candidateLength, unfulfilledDemands);
          const utilization = packedLength / candidateLength;
          console.log(`  - \u5019\u9009 ${candidateLength}mm: \u6F5C\u529B\u88C5\u8F7D ${packedLength}mm, \u9884\u671F\u5229\u7528\u7387 ${(utilization * 100).toFixed(2)}%`);
          if (utilization > bestChoice.utilization) {
            bestChoice.length = candidateLength;
            bestChoice.utilization = utilization;
          }
        }
        console.log(`\u2705 [\u5411\u524D\u770B] \u51B3\u7B56\u5B8C\u6210: \u9009\u62E9 ${bestChoice.length}mm (\u9884\u671F\u5229\u7528\u7387 ${(bestChoice.utilization * 100).toFixed(2)}%)`);
        return pool.createSteel(bestChoice.length);
      }
      /**
       * [新增] 辅助方法 - 为"向前看"机制计算给定箱子的潜在利用率
       */
      calculatePotentialUtilization(binSize, demands) {
        let remainingLength = binSize;
        let packedLength = 0;
        for (const demand of demands) {
          if (demand.length <= remainingLength) {
            remainingLength -= demand.length;
            packedLength += demand.length;
          }
        }
        return { packedLength, remainingLength };
      }
      /**
       * 按规格+截面面积组合分组（真正的规格化设计）
       */
      groupBySpecificationAndCrossSection() {
        const groups = {};
        this.designSteels.forEach((steel) => {
          const specification = steel.specification || "\u672A\u77E5\u89C4\u683C";
          const crossSection = Math.round(steel.crossSection);
          const groupKey = `${specification}_${crossSection}`;
          if (!groups[groupKey]) {
            groups[groupKey] = [];
          }
          groups[groupKey].push(steel);
        });
        console.log("\u{1F3AF} \u6309\u89C4\u683C+\u622A\u9762\u9762\u79EF\u7EC4\u5408\u5206\u7EC4\u7ED3\u679C:", Object.keys(groups));
        return groups;
      }
      /**
       * V3规格化改进：生成模数钢材ID
       */
      generateModuleId(groupKey) {
        if (!this.moduleCounters[groupKey]) {
          this.moduleCounters[groupKey] = 0;
        }
        this.moduleCounters[groupKey]++;
        return `${groupKey}_M${this.moduleCounters[groupKey]}`;
      }
      /**
       * 🔧 修复版：MW-CD交换优化算法
       * 基于规格匹配和效益分析的智能交换
       */
      async performMWCDOptimization(solutions) {
        console.log("\u{1F504} \u6267\u884C\u6539\u8FDB\u7248MW-CD\u4EA4\u6362\u4F18\u5316\u7B97\u6CD5");
        const stats = {
          totalMWFound: 0,
          totalCDFound: 0,
          validExchanges: 0,
          exchangesPerformed: 0,
          totalBenefitGained: 0
        };
        for (const [groupKey, solution] of Object.entries(solutions)) {
          if (this.isTimeExceeded()) break;
          console.log(`
\u{1F4CB} \u5206\u6790 ${groupKey} \u7EC4\u5408\u7684MW-CD\u4EA4\u6362\u673A\u4F1A...`);
          const mwRemainders = this.findMWRemainders(solution);
          const cdPlans = this.findCDPlans(solution);
          stats.totalMWFound += mwRemainders.length;
          stats.totalCDFound += cdPlans.length;
          console.log(`  - \u53D1\u73B0MW\u4F59\u6599: ${mwRemainders.length}\u4E2A`);
          console.log(`  - \u53D1\u73B0CD\u8BA1\u5212: ${cdPlans.length}\u4E2A`);
          if (mwRemainders.length === 0 || cdPlans.length === 0) {
            console.log(`  - \u8DF3\u8FC7${groupKey}\u7EC4\u5408\uFF08\u7F3A\u5C11\u4EA4\u6362\u5BF9\u8C61\uFF09`);
            continue;
          }
          const exchangeOpportunities = this.analyzeExchangeOpportunities(mwRemainders, cdPlans, groupKey);
          for (const opportunity of exchangeOpportunities) {
            if (this.isTimeExceeded()) break;
            stats.validExchanges++;
            const exchangeResult = this.executeImprovedInterchange(solution, opportunity, groupKey);
            if (exchangeResult.success) {
              stats.exchangesPerformed++;
              stats.totalBenefitGained += exchangeResult.benefit;
              console.log(`  \u2705 \u4EA4\u6362\u6210\u529F: \u6548\u76CA\u63D0\u5347 ${exchangeResult.benefit.toFixed(2)}mm`);
            } else {
              console.log(`  \u274C \u4EA4\u6362\u5931\u8D25: ${exchangeResult.reason}`);
            }
          }
        }
        console.log("\n\u{1F4CA} MW-CD\u4EA4\u6362\u4F18\u5316\u7EDF\u8BA1:");
        console.log(`  - MW\u4F59\u6599\u603B\u6570: ${stats.totalMWFound}`);
        console.log(`  - CD\u8BA1\u5212\u603B\u6570: ${stats.totalCDFound}`);
        console.log(`  - \u6709\u6548\u4EA4\u6362\u673A\u4F1A: ${stats.validExchanges}`);
        console.log(`  - \u5B9E\u9645\u6267\u884C\u4EA4\u6362: ${stats.exchangesPerformed}`);
        console.log(`  - \u603B\u6548\u76CA\u63D0\u5347: ${stats.totalBenefitGained.toFixed(2)}mm`);
        return stats;
      }
      /**
       * 🔧 改进：分析交换机会并按效益排序
       */
      analyzeExchangeOpportunities(mwRemainders, cdPlans, groupKey) {
        const opportunities = [];
        for (const mw of mwRemainders) {
          for (const cd of cdPlans) {
            const feasibility = this.checkExchangeFeasibility(mw, cd, groupKey);
            if (feasibility.isFeasible) {
              opportunities.push({
                mw,
                cd,
                benefit: feasibility.benefit,
                totalBenefit: feasibility.benefit,
                // 🔧 修复：添加totalBenefit字段
                confidence: feasibility.confidence,
                reason: feasibility.reason
              });
            }
          }
        }
        opportunities.sort((a, b) => b.benefit - a.benefit);
        console.log(`  - \u5206\u6790\u51FA ${opportunities.length} \u4E2A\u53EF\u884C\u7684\u4EA4\u6362\u673A\u4F1A`);
        return opportunities.slice(0, 5);
      }
      /**
       * 🔧 改进：全面的交换可行性检查
       */
      checkExchangeFeasibility(mw, cd, groupKey) {
        const mwLength = mw.remainder.length;
        const cdTotalLength = cd.usedRemainders.reduce((sum, r) => sum + r.length, 0);
        const cdSegments = cd.usedRemainders.length;
        const mwGroupKey = mw.remainder.groupKey || groupKey;
        const cdGroupKey = cd.usedRemainders[0]?.groupKey || groupKey;
        if (mwGroupKey !== cdGroupKey) {
          return {
            isFeasible: false,
            reason: "\u89C4\u683C\u4E0D\u5339\u914D"
          };
        }
        const targetLength = cd.cuts[0]?.length || 0;
        if (mwLength < targetLength) {
          return {
            isFeasible: false,
            reason: "MW\u4F59\u6599\u957F\u5EA6\u4E0D\u8DB3"
          };
        }
        if (cdSegments <= 1) {
          return {
            isFeasible: false,
            reason: "CD\u8BA1\u5212\u5DF2\u662F\u5355\u6BB5\uFF0C\u65E0\u9700\u4EA4\u6362"
          };
        }
        const weldingCostSaved = (cdSegments - 1) * 50;
        const materialWasteDiff = mwLength - cdTotalLength;
        const totalBenefit = weldingCostSaved - Math.abs(materialWasteDiff);
        if (totalBenefit <= 0) {
          return {
            isFeasible: false,
            reason: "\u4EA4\u6362\u6548\u76CA\u4E3A\u8D1F",
            benefit: totalBenefit
          };
        }
        const newWaste = mwLength - targetLength;
        if (newWaste >= this.constraints.wasteThreshold) {
          return {
            isFeasible: false,
            reason: "\u4EA4\u6362\u540E\u5E9F\u6599\u8FC7\u591A"
          };
        }
        return {
          isFeasible: true,
          benefit: totalBenefit,
          confidence: Math.min(1, totalBenefit / 100),
          // 信心度基于效益大小
          reason: `\u53EF\u8282\u7701${cdSegments - 1}\u4E2A\u710A\u63A5\u70B9\uFF0C\u6548\u76CA${totalBenefit.toFixed(2)}mm`
        };
      }
      /**
       * 🔧 改进：执行完整的交换操作
       */
      executeImprovedInterchange(solution, opportunity, groupKey) {
        const { mw, cd, benefit } = opportunity;
        try {
          console.log(`    \u{1F504} \u6267\u884C\u4EA4\u6362: MW(${mw.remainder.id}, ${mw.remainder.length}mm) \u2194 CD(${cd.usedRemainders.map((r) => r.id).join("+")}, ${cd.usedRemainders.reduce((sum, r) => sum + r.length, 0)}mm)`);
          const targetLength = cd.cuts[0]?.length || 0;
          const newWaste = mw.remainder.length - targetLength;
          const newCuttingPlan = new CuttingPlan({
            sourceType: "remainder",
            sourceId: mw.remainder.id,
            sourceDescription: `${groupKey}\u7EC4\u5408MW\u4F59\u6599 ${mw.remainder.id} (\u4EA4\u6362\u4F18\u5316)`,
            sourceLength: mw.remainder.length,
            cuts: cd.cuts,
            // 复用原CD的切割需求
            usedRemainders: [mw.remainder],
            newRemainders: [],
            pseudoRemainders: [mw.remainder],
            // MW余料变为伪余料
            realRemainders: [],
            waste: newWaste
          });
          const cdIndex = solution.cuttingPlans.findIndex((plan) => plan === cd);
          if (cdIndex !== -1) {
            solution.cuttingPlans.splice(cdIndex, 1);
          }
          solution.cuttingPlans.push(newCuttingPlan);
          solution.totalWaste += newWaste;
          solution.totalRealRemainder -= mw.remainder.length;
          solution.totalPseudoRemainder += mw.remainder.length;
          mw.remainder.markAsPseudo();
          cd.usedRemainders.forEach((remainder) => {
            if (remainder.type === REMAINDER_TYPES.PSEUDO) {
              remainder.type = REMAINDER_TYPES.REAL;
              this.remainderManager.remainderPools[groupKey].push(remainder);
            }
          });
          return {
            success: true,
            benefit,
            newPlan: newCuttingPlan
          };
        } catch (error) {
          console.error(`    \u274C \u4EA4\u6362\u6267\u884C\u5931\u8D25: ${error.message}`);
          return {
            success: false,
            reason: error.message
          };
        }
      }
      /**
       * 🔧 关键修复：在并行任务内部执行MW-CD交换优化
       * 这是正确的架构设计 - MW-CD应该在每个规格组合内部进行
       */
      async performInternalMWCDOptimization(solution, groupKey, remainderManager) {
        const stats = {
          totalMWFound: 0,
          totalCDFound: 0,
          validExchanges: 0,
          exchangesPerformed: 0,
          totalBenefitGained: 0,
          iterations: 0
        };
        console.log(`
\u{1F504} \u5F00\u59CB${groupKey}\u7EC4\u5408\u5185\u90E8MW-CD\u4EA4\u6362\u4F18\u5316...`);
        const minBenefitThreshold = 50;
        const maxIterations = 10;
        let iteration = 0;
        while (iteration < maxIterations && !this.isTimeExceeded()) {
          iteration++;
          stats.iterations = iteration;
          console.log(`  \u{1F4CA} \u7B2C${iteration}\u8F6EMW-CD\u5206\u6790...`);
          const mwRemainders = this.findMWRemainders(solution);
          const cdPlans = this.findCDPlans(solution);
          stats.totalMWFound = mwRemainders.length;
          stats.totalCDFound = cdPlans.length;
          console.log(`    - \u53D1\u73B0MW\u4F59\u6599: ${mwRemainders.length}\u4E2A`);
          console.log(`    - \u53D1\u73B0CD\u8BA1\u5212: ${cdPlans.length}\u4E2A`);
          if (mwRemainders.length === 0 || cdPlans.length === 0) {
            console.log(`    - \u7B2C${iteration}\u8F6E\u65E0\u4EA4\u6362\u5BF9\u8C61\uFF0C\u6536\u655B\u9000\u51FA`);
            break;
          }
          const exchangeOpportunities = this.analyzeExchangeOpportunities(mwRemainders, cdPlans, groupKey);
          let hasPositiveBenefitExchange = false;
          const validOpportunities = exchangeOpportunities.filter((opportunity) => {
            if (opportunity.totalBenefit > minBenefitThreshold) {
              hasPositiveBenefitExchange = true;
              return true;
            }
            return false;
          });
          if (!hasPositiveBenefitExchange) {
            console.log(`    - \u7B2C${iteration}\u8F6E\u65E0\u6B63\u6548\u76CA\u4EA4\u6362(\u9608\u503C${minBenefitThreshold}mm)\uFF0C\u6536\u655B\u9000\u51FA`);
            break;
          }
          console.log(`    - \u53D1\u73B0${validOpportunities.length}\u4E2A\u6709\u6548\u4EA4\u6362\u673A\u4F1A`);
          let roundExchangeCount = 0;
          for (const opportunity of validOpportunities) {
            if (this.isTimeExceeded()) break;
            stats.validExchanges++;
            const exchangeResult = this.executeInternalInterchange(solution, opportunity, groupKey, remainderManager);
            if (exchangeResult.success) {
              stats.exchangesPerformed++;
              stats.totalBenefitGained += exchangeResult.benefit;
              roundExchangeCount++;
              console.log(`      \u2705 \u7B2C${iteration}\u8F6E\u4EA4\u6362${roundExchangeCount}: \u6548\u76CA\u63D0\u5347 ${exchangeResult.benefit.toFixed(2)}mm`);
              break;
            } else {
              console.log(`      \u274C \u4EA4\u6362\u5931\u8D25: ${exchangeResult.reason}`);
            }
          }
          if (roundExchangeCount === 0) {
            console.log(`    - \u7B2C${iteration}\u8F6E\u65E0\u6210\u529F\u4EA4\u6362\uFF0C\u6536\u655B\u9000\u51FA`);
            break;
          }
        }
        if (iteration >= maxIterations) {
          console.log(`  \u26A0\uFE0F \u8FBE\u5230\u6700\u5927\u8FED\u4EE3\u6B21\u6570${maxIterations}\uFF0C\u5F3A\u5236\u6536\u655B`);
        }
        console.log(`\u2705 ${groupKey}\u7EC4\u5408MW-CD\u4F18\u5316\u5B8C\u6210: ${stats.iterations}\u8F6E\u8FED\u4EE3\uFF0C${stats.exchangesPerformed}\u6B21\u4EA4\u6362\uFF0C\u603B\u6548\u76CA${stats.totalBenefitGained.toFixed(2)}mm`);
        return stats;
      }
      /**
       * 🔧 内部交换执行方法（针对并行任务优化）
       */
      executeInternalInterchange(solution, opportunity, groupKey, remainderManager) {
        const { mw, cd, benefit } = opportunity;
        try {
          console.log(`      \u{1F504} \u6267\u884C\u5185\u90E8\u4EA4\u6362: MW(${mw.remainder.id}, ${mw.remainder.length}mm) \u2194 CD(${cd.usedRemainders.map((r) => r.id).join("+")}, ${cd.usedRemainders.reduce((sum, r) => sum + r.length, 0)}mm)`);
          const targetLength = cd.cuts[0]?.length || 0;
          const newWaste = mw.remainder.length - targetLength;
          const newCuttingPlan = new CuttingPlan({
            sourceType: "remainder",
            sourceId: mw.remainder.id,
            sourceDescription: `${groupKey}\u7EC4\u5408MW\u4F59\u6599 ${mw.remainder.id} (\u5185\u90E8\u4EA4\u6362\u4F18\u5316)`,
            sourceLength: mw.remainder.length,
            cuts: cd.cuts,
            // 复用原CD的切割需求
            usedRemainders: [mw.remainder],
            newRemainders: [],
            pseudoRemainders: [mw.remainder],
            // MW余料变为伪余料
            realRemainders: [],
            waste: newWaste
          });
          const cdIndex = solution.cuttingPlans.findIndex((plan) => plan === cd);
          if (cdIndex !== -1) {
            solution.cuttingPlans.splice(cdIndex, 1);
          }
          solution.cuttingPlans.push(newCuttingPlan);
          mw.remainder.markAsPseudo();
          const mwIndex = remainderManager.remainderPools[groupKey].findIndex((r) => r.id === mw.remainder.id);
          if (mwIndex !== -1) {
            remainderManager.remainderPools[groupKey].splice(mwIndex, 1);
          }
          cd.usedRemainders.forEach((remainder) => {
            if (remainder.type === REMAINDER_TYPES.PSEUDO) {
              remainder.type = REMAINDER_TYPES.PENDING;
              remainderManager.remainderPools[groupKey].push(remainder);
            }
          });
          remainderManager.remainderPools[groupKey].sort((a, b) => a.length - b.length);
          return {
            success: true,
            benefit,
            newPlan: newCuttingPlan
          };
        } catch (error) {
          console.error(`      \u274C \u5185\u90E8\u4EA4\u6362\u6267\u884C\u5931\u8D25: ${error.message}`);
          return {
            success: false,
            reason: error.message
          };
        }
      }
      /**
       * 查找MW余料（在内部优化时查找PENDING状态的余料，因为REAL状态在最后才确定）
       */
      findMWRemainders(solution) {
        const mwRemainders = [];
        solution.cuttingPlans.forEach((plan) => {
          if (plan.newRemainders) {
            plan.newRemainders.forEach((remainder) => {
              if (remainder.type === REMAINDER_TYPES.PENDING && remainder.length >= this.constraints.wasteThreshold) {
                mwRemainders.push({
                  remainder,
                  plan
                });
              }
            });
          }
          if (plan.realRemainders) {
            plan.realRemainders.forEach((remainder) => {
              if (remainder.type === REMAINDER_TYPES.REAL) {
                mwRemainders.push({
                  remainder,
                  plan
                });
              }
            });
          }
        });
        return mwRemainders;
      }
      /**
       * 查找CD计划（使用余料组合的）
       */
      findCDPlans(solution) {
        return solution.cuttingPlans.filter(
          (plan) => plan.sourceType === "remainder" && plan.usedRemainders && plan.usedRemainders.length >= 2
        );
      }
      /**
       * 检查是否可以执行交换
       */
      canPerformInterchange(mw, cd) {
        const mwLength = mw.remainder.length;
        const cdTotalLength = cd.usedRemainders.reduce((sum, r) => sum + r.length, 0);
        return Math.abs(mwLength - cdTotalLength) < this.constraints.wasteThreshold;
      }
      /**
       * 执行交换操作
       */
      executeInterchange(solution, mw, cd, groupKey) {
        console.log(`\u{1F504} \u6267\u884CMW-CD\u4EA4\u6362: ${mw.remainder.id} \u2194 ${cd.usedRemainders.map((r) => r.id).join("+")}`);
        solution.totalWaste += mw.remainder.length;
        solution.totalRealRemainder -= mw.remainder.length;
        mw.remainder.markAsWaste();
      }
      /**
       * 构建最终优化结果
       * 使用统一的StatisticsCalculator确保数据一致性
       */
      buildOptimizationResult(solutions, validation) {
        const endTime = Date.now();
        const executionTime = endTime - this.startTime;
        console.log("\u{1F3D7}\uFE0F \u4F7F\u7528\u7EDF\u4E00StatisticsCalculator\u6784\u5EFA\u6700\u7EC8\u4F18\u5316\u7ED3\u679C...");
        const completeResult = this.resultBuilder.buildCompleteResult(
          solutions,
          this.designSteels,
          this.moduleSteels,
          this.remainderManager,
          // 新增：传入余料管理器
          executionTime
        );
        const optimizationResult = new OptimizationResult({
          solutions,
          totalModuleUsed: completeResult.totalModuleUsed,
          totalMaterial: completeResult.totalMaterial,
          totalWaste: completeResult.totalWaste,
          totalRealRemainder: completeResult.totalRealRemainder,
          totalPseudoRemainder: completeResult.totalPseudoRemainder,
          totalLossRate: completeResult.totalLossRate,
          executionTime,
          timestamp: (/* @__PURE__ */ new Date()).toISOString(),
          version: "3.0",
          constraintValidation: validation,
          // 🔧 新增：完整的统计数据，前端直接使用
          completeStats: completeResult.completeStats,
          // 🔧 添加优化完成状态标记
          processingStatus: {
            isCompleted: true,
            remaindersFinalized: true,
            readyForRendering: true,
            completedAt: (/* @__PURE__ */ new Date()).toISOString(),
            dataConsistencyChecked: completeResult.completeStats.consistencyCheck.isConsistent
          }
        });
        const moduleSteelStats = this.collectModuleSteelUsageStats();
        optimizationResult.moduleSteelUsage = moduleSteelStats;
        const databaseRecords = this.collectDatabaseRecords();
        optimizationResult.databaseRecords = databaseRecords;
        console.log("\u2705 \u7EDF\u4E00StatisticsCalculator\u6784\u5EFA\u5B8C\u6210\uFF0C\u6570\u636E\u4E00\u81F4\u6027\u5DF2\u9A8C\u8BC1");
        console.log(`\u{1F4CA} \u5168\u5C40\u7EDF\u8BA1: \u6A21\u6570\u94A2\u6750${completeResult.totalModuleUsed}\u6839, \u635F\u8017\u7387${completeResult.totalLossRate}%, \u6267\u884C\u65F6\u95F4${executionTime}ms`);
        if (!completeResult.completeStats.consistencyCheck.isConsistent) {
          console.warn("\u26A0\uFE0F \u6570\u636E\u4E00\u81F4\u6027\u68C0\u67E5\u5931\u8D25\uFF0C\u8BF7\u68C0\u67E5\u7B97\u6CD5\u903B\u8F91");
          completeResult.completeStats.consistencyCheck.errors.forEach((error) => {
            console.warn(`   - ${error}`);
          });
        }
        return optimizationResult;
      }
      /**
       * V3新增：收集模数钢材使用统计（按根数）
       */
      collectModuleSteelUsageStats() {
        const stats = {};
        this.moduleSteelPools.forEach((pool, groupKey) => {
          const [specification, crossSection] = this.parseGroupKey(groupKey);
          if (!stats[specification]) {
            stats[specification] = {};
          }
          const poolStats = pool.getUsageStats();
          Object.entries(poolStats).forEach(([length, count]) => {
            const key = `${length}`;
            stats[specification][key] = (stats[specification][key] || 0) + count;
          });
        });
        return stats;
      }
      /**
       * V3新增：收集数据库存储记录
       */
      collectDatabaseRecords() {
        const records = [];
        this.moduleSteelPools.forEach((pool, groupKey) => {
          records.push(...pool.getDatabaseRecords());
        });
        return records;
      }
      /**
       * V3新增：重置所有模数钢材池
       */
      resetAllPools() {
        this.moduleSteelPools.forEach((pool) => {
          pool.reset();
        });
        this.moduleSteelPools.clear();
        console.log("\u{1F504} \u6240\u6709\u6A21\u6570\u94A2\u6750\u6C60\u5DF2\u91CD\u7F6E");
      }
      /**
       * V3新增：批量保存模数钢材使用记录到数据库（预留接口）
       */
      async saveToDatabaseAsync(records) {
        console.log(`\u{1F4BE} \u51C6\u5907\u4FDD\u5B58${records.length}\u6761\u6A21\u6570\u94A2\u6750\u4F7F\u7528\u8BB0\u5F55\u5230\u6570\u636E\u5E93`);
        const batchSize = 100;
        for (let i = 0; i < records.length; i += batchSize) {
          const batch = records.slice(i, i + batchSize);
          console.log(`\u{1F4BE} \u4FDD\u5B58\u6279\u6B21${Math.floor(i / batchSize) + 1}: ${batch.length}\u6761\u8BB0\u5F55`);
        }
        return true;
      }
      /**
       * 辅助方法 - [原版]
       */
      createDemandList(steels) {
        return steels.map((steel) => ({
          id: steel.id,
          length: steel.length,
          quantity: steel.quantity,
          remaining: steel.quantity,
          crossSection: steel.crossSection
        }));
      }
      /**
       * [新增] 辅助方法 - 创建扁平化的需求列表，每个元素代表一根钢材
       */
      createFlatDemandList(steels) {
        const flatList = [];
        steels.forEach((steel) => {
          for (let i = 0; i < steel.quantity; i++) {
            flatList.push({ ...steel, uniqueId: `${steel.id}_${i}` });
          }
        });
        return flatList;
      }
      /**
       * [新增] 辅助方法 - 将单个切割项按 designId 和 length 分组合并
       */
      groupCuts(flatCuts) {
        const grouped = /* @__PURE__ */ new Map();
        flatCuts.forEach((cut) => {
          const key = `${cut.designId}_${cut.length}`;
          if (!grouped.has(key)) {
            grouped.set(key, { ...cut, quantity: 0 });
          }
          grouped.get(key).quantity += 1;
        });
        return Array.from(grouped.values());
      }
      isTimeExceeded() {
        return Date.now() - this.startTime > this.constraints.timeLimit;
      }
    };
    var SpecificationModuleSteelPool = class {
      constructor(specification, crossSection, availableLengths = null) {
        this.availableLengths = (availableLengths || constraintManager.getDefaultModuleLengths()).sort((a, b) => a - b);
        this.specification = specification;
        this.crossSection = crossSection;
        this.usedSteels = [];
        this.counter = 0;
      }
      /**
       * 获取指定长度的模数钢材（动态生成）
       */
      getSteel(requiredLength) {
        const bestLength = this.availableLengths.find((length) => length >= requiredLength);
        if (!bestLength) {
          const maxLength = Math.max(...this.availableLengths);
          console.warn(`\u26A0\uFE0F \u9700\u6C42\u957F\u5EA6${requiredLength}mm\u8D85\u8FC7\u6700\u5927\u6A21\u6570\u94A2\u6750${maxLength}mm\uFF0C\u4F7F\u7528\u6700\u957F\u89C4\u683C`);
          return this.createSteel(maxLength);
        }
        const waste = bestLength - requiredLength;
        console.log(`\u{1F3AF} \u9700\u6C42${requiredLength}mm\uFF0C\u9009\u62E9${bestLength}mm\uFF08\u6D6A\u8D39${waste}mm\uFF09`);
        return this.createSteel(bestLength);
      }
      /**
       * 创建新的模数钢材实例
       */
      createSteel(length) {
        this.counter++;
        const steel = new ModuleSteel({
          id: `${this.specification}_${this.crossSection}_M${this.counter}`,
          name: `${this.specification}-${length}mm\u6A21\u6570\u94A2\u6750`,
          length,
          specification: this.specification,
          crossSection: this.crossSection,
          createdAt: (/* @__PURE__ */ new Date()).toISOString()
        });
        this.usedSteels.push({
          id: steel.id,
          specification: this.specification,
          crossSection: this.crossSection,
          length,
          usedAt: (/* @__PURE__ */ new Date()).toISOString()
        });
        console.log(`\u{1F527} \u52A8\u6001\u751F\u6210\u6A21\u6570\u94A2\u6750: ${steel.id} (${this.specification}, ${length}mm)`);
        return steel;
      }
      /**
       * 获取使用统计
       */
      getUsageStats() {
        const stats = {};
        this.usedSteels.forEach((steel) => {
          const key = steel.length;
          stats[key] = (stats[key] || 0) + 1;
        });
        return stats;
      }
      /**
       * 获取数据库记录
       */
      getDatabaseRecords() {
        return [...this.usedSteels];
      }
      /**
       * 重置池状态
       */
      reset() {
        this.usedSteels = [];
        this.counter = 0;
      }
    };
    module2.exports = SteelOptimizerV32;
  }
});

// netlify/functions/utils/netlifyDatabase.js
var require_netlifyDatabase = __commonJS({
  "netlify/functions/utils/netlifyDatabase.js"(exports2, module2) {
    var fs = require("fs");
    var path = require("path");
    var NetlifyDatabase = class {
      constructor() {
        this.data = null;
        this.initialized = false;
        this.initPromise = null;
      }
      /**
       * 初始化Netlify云端数据库
       * 使用内存存储，避免文件系统权限问题
       */
      async init() {
        if (this.initialized) return true;
        if (this.initPromise) return this.initPromise;
        this.initPromise = this._initialize();
        const result = await this.initPromise;
        this.initPromise = null;
        return result;
      }
      async _initialize() {
        try {
          console.log("\u{1F310} \u521D\u59CB\u5316Netlify\u4E91\u7AEF\u6570\u636E\u5E93...");
          this.data = this.getDefaultData();
          if (process.env.NETLIFY_DATA) {
            try {
              this.data = JSON.parse(process.env.NETLIFY_DATA);
              console.log("\u2705 \u4ECE\u73AF\u5883\u53D8\u91CF\u52A0\u8F7D\u9884\u8BBE\u6570\u636E");
            } catch (e) {
              console.log("\u26A0\uFE0F \u73AF\u5883\u53D8\u91CF\u6570\u636E\u683C\u5F0F\u9519\u8BEF\uFF0C\u4F7F\u7528\u9ED8\u8BA4\u6570\u636E");
            }
          }
          console.log("\u2705 Netlify\u4E91\u7AEF\u6570\u636E\u5E93\u521D\u59CB\u5316\u6210\u529F");
          this.initialized = true;
          return true;
        } catch (error) {
          console.error("\u274C Netlify\u6570\u636E\u5E93\u521D\u59CB\u5316\u5931\u8D25:", error);
          return false;
        }
      }
      /**
       * 获取默认数据结构
       */
      getDefaultData() {
        return {
          designSteels: [],
          moduleSteels: [
            {
              id: "default_1",
              name: "12\u7C73\u6807\u51C6\u94A2\u6750",
              length: 12e3,
              createdAt: (/* @__PURE__ */ new Date()).toISOString(),
              updatedAt: (/* @__PURE__ */ new Date()).toISOString()
            },
            {
              id: "default_2",
              name: "9\u7C73\u6807\u51C6\u94A2\u6750",
              length: 9e3,
              createdAt: (/* @__PURE__ */ new Date()).toISOString(),
              updatedAt: (/* @__PURE__ */ new Date()).toISOString()
            },
            {
              id: "default_3",
              name: "6\u7C73\u6807\u51C6\u94A2\u6750",
              length: 6e3,
              createdAt: (/* @__PURE__ */ new Date()).toISOString(),
              updatedAt: (/* @__PURE__ */ new Date()).toISOString()
            }
          ],
          optimizationTasks: [],
          systemStats: {
            totalOptimizations: 0,
            totalDesignSteels: 0,
            totalModuleSteels: 3,
            totalSavedCost: 0,
            lastUpdated: (/* @__PURE__ */ new Date()).toISOString()
          },
          operationLogs: [],
          settings: {
            autoBackup: false,
            // 云端环境禁用自动备份
            maxLogEntries: 100,
            maxBackups: 5
          }
        };
      }
      /**
       * 创建优化任务
       */
      async createOptimizationTask(taskData) {
        try {
          await this.init();
          const taskId = "task_" + Date.now() + "_" + Math.random().toString(36).substr(2, 9);
          const task = {
            id: taskId,
            designSteels: taskData.designSteels || [],
            moduleSteels: taskData.moduleSteels || [],
            constraints: taskData.constraints || {},
            status: "pending",
            progress: 0,
            createdAt: (/* @__PURE__ */ new Date()).toISOString(),
            updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
            results: null,
            error: null
          };
          this.data.optimizationTasks.push(task);
          this.data.systemStats.totalOptimizations++;
          this.data.systemStats.lastUpdated = (/* @__PURE__ */ new Date()).toISOString();
          console.log(`\u2705 \u4E91\u7AEF\u4EFB\u52A1\u521B\u5EFA\u6210\u529F: ${taskId}`);
          return taskId;
        } catch (error) {
          console.error("\u274C \u521B\u5EFA\u4E91\u7AEF\u4EFB\u52A1\u5931\u8D25:", error);
          throw error;
        }
      }
      /**
       * 更新任务状态
       */
      async updateTaskStatus(taskId, status) {
        try {
          await this.init();
          const task = this.data.optimizationTasks.find((t) => t.id === taskId);
          if (task) {
            task.status = status;
            task.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
            return true;
          }
          return false;
        } catch (error) {
          console.error("\u274C \u66F4\u65B0\u4EFB\u52A1\u72B6\u6001\u5931\u8D25:", error);
          return false;
        }
      }
      /**
       * 更新任务进度
       */
      async updateTaskProgress(taskId, progress, message) {
        try {
          await this.init();
          const task = this.data.optimizationTasks.find((t) => t.id === taskId);
          if (task) {
            task.progress = progress;
            task.message = message;
            task.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
            return true;
          }
          return false;
        } catch (error) {
          console.error("\u274C \u66F4\u65B0\u4EFB\u52A1\u8FDB\u5EA6\u5931\u8D25:", error);
          return false;
        }
      }
      /**
       * 设置任务结果
       */
      async setTaskResults(taskId, results) {
        try {
          await this.init();
          const task = this.data.optimizationTasks.find((t) => t.id === taskId);
          if (task) {
            task.results = results;
            task.status = results.success ? "completed" : "failed";
            task.progress = 100;
            task.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
            return true;
          }
          return false;
        } catch (error) {
          console.error("\u274C \u8BBE\u7F6E\u4EFB\u52A1\u7ED3\u679C\u5931\u8D25:", error);
          return false;
        }
      }
      /**
       * 设置任务错误
       */
      async setTaskError(taskId, error) {
        try {
          await this.init();
          const task = this.data.optimizationTasks.find((t) => t.id === taskId);
          if (task) {
            task.error = error;
            task.status = "failed";
            task.progress = 100;
            task.updatedAt = (/* @__PURE__ */ new Date()).toISOString();
            return true;
          }
          return false;
        } catch (error2) {
          console.error("\u274C \u8BBE\u7F6E\u4EFB\u52A1\u9519\u8BEF\u5931\u8D25:", error2);
          return false;
        }
      }
      /**
       * 获取任务
       */
      async getTask(taskId) {
        await this.init();
        return this.data.optimizationTasks.find((t) => t.id === taskId);
      }
      /**
       * 获取数据库统计信息
       */
      getStats() {
        if (!this.data) {
          return {
            designSteels: 0,
            moduleSteels: 3,
            optimizationTasks: 0,
            completedTasks: 0,
            operationLogs: 0,
            databaseSize: "\u5185\u5B58\u5B58\u50A8",
            lastUpdated: (/* @__PURE__ */ new Date()).toISOString()
          };
        }
        return {
          designSteels: this.data.designSteels?.length || 0,
          moduleSteels: this.data.moduleSteels?.length || 0,
          optimizationTasks: this.data.optimizationTasks?.length || 0,
          completedTasks: this.data.optimizationTasks?.filter((task) => task.status === "completed")?.length || 0,
          operationLogs: this.data.operationLogs?.length || 0,
          databaseSize: "\u5185\u5B58\u5B58\u50A8",
          lastUpdated: this.data.systemStats?.lastUpdated || (/* @__PURE__ */ new Date()).toISOString()
        };
      }
      /**
       * 获取数据库连接
       */
      getConnection() {
        if (!this.initialized) {
          throw new Error("Netlify\u4E91\u7AEF\u6570\u636E\u5E93\u672A\u521D\u59CB\u5316");
        }
        return this;
      }
    };
    var netlifyDb = new NetlifyDatabase();
    module2.exports = netlifyDb;
  }
});

// netlify/functions/optimize.js
var SteelOptimizerV3 = require_SteelOptimizerV3();
var ConstraintValidator = require_ConstraintValidator();
var db = require_netlifyDatabase();
exports.handler = async (event, context) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const data = JSON.parse(event.body);
    const { designSteels, moduleSteels, constraints } = data;
    if (!designSteels || !Array.isArray(designSteels) || designSteels.length === 0) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "Invalid or empty design steels data" })
      };
    }
    if (!moduleSteels || !Array.isArray(moduleSteels) || moduleSteels.length === 0) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "Invalid or empty module steels data" })
      };
    }
    const validator = new ConstraintValidator();
    const validationResult = validator.validateAllConstraints(designSteels, moduleSteels, constraints);
    if (!validationResult.isValid) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({
          error: "Invalid constraints",
          details: validationResult.violations,
          suggestions: validationResult.suggestions
        })
      };
    }
    const db2 = require_netlifyDatabase();
    const dbInitialized = await db2.init();
    if (!dbInitialized) {
      console.error("\u274C \u4E91\u7AEF\u6570\u636E\u5E93\u521D\u59CB\u5316\u5931\u8D25");
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({
          success: false,
          error: "Cloud database initialization failed",
          message: "\u4E91\u7AEF\u6570\u636E\u5E93\u521D\u59CB\u5316\u5931\u8D25\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5"
        })
      };
    }
    const taskId = await db2.createOptimizationTask({
      designSteels,
      moduleSteels,
      constraints
    });
    console.log(`\u2705 \u4F18\u5316\u4EFB\u52A1\u5DF2\u521B\u5EFA: ${taskId}`);
    setTimeout(async () => {
      try {
        console.log(`\u{1F680} \u5F00\u59CB\u5F02\u6B65\u6267\u884C\u4F18\u5316\u4EFB\u52A1: ${taskId}`);
        const progressUpdated = await db2.updateTaskProgress(taskId, 20, "\u6B63\u5728\u6267\u884C\u4F18\u5316...");
        if (!progressUpdated) {
          console.error(`\u274C \u65E0\u6CD5\u66F4\u65B0\u4EFB\u52A1\u8FDB\u5EA6: ${taskId}`);
        }
        const statusUpdated = await db2.updateTaskStatus(taskId, "running");
        if (!statusUpdated) {
          console.error(`\u274C \u65E0\u6CD5\u66F4\u65B0\u4EFB\u52A1\u72B6\u6001: ${taskId}`);
        }
        console.log(`\u{1F50D} \u5F00\u59CB\u6267\u884C\u4F18\u5316\u7B97\u6CD5: ${taskId}`);
        const optimizer = new SteelOptimizerV3(designSteels, moduleSteels, constraints);
        const optimizationResult = await optimizer.optimize();
        console.log(`\u{1F4CA} \u4F18\u5316\u7ED3\u679C: ${taskId}, success: ${optimizationResult.success}`);
        const resultsSet = await db2.setTaskResults(taskId, optimizationResult);
        if (resultsSet) {
          console.log(`\u2705 \u4F18\u5316\u5B8C\u6210\u5E76\u4FDD\u5B58\u7ED3\u679C: ${taskId}`);
        } else {
          console.error(`\u274C \u65E0\u6CD5\u4FDD\u5B58\u4F18\u5316\u7ED3\u679C: ${taskId}`);
        }
      } catch (error) {
        console.error("\u274C \u4F18\u5316\u4EFB\u52A1\u6267\u884C\u5F02\u5E38:", error);
        console.error("\u274C \u9519\u8BEF\u5806\u6808:", error.stack);
        try {
          await db2.setTaskError(taskId, {
            message: error.message || "\u4F18\u5316\u8FC7\u7A0B\u4E2D\u53D1\u751F\u672A\u77E5\u9519\u8BEF",
            stack: error.stack || "",
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          });
          console.log(`\u{1F4DD} \u5DF2\u8BB0\u5F55\u4EFB\u52A1\u9519\u8BEF: ${taskId}`);
        } catch (dbError) {
          console.error("\u274C \u65E0\u6CD5\u8BB0\u5F55\u4EFB\u52A1\u9519\u8BEF:", dbError);
        }
      }
    }, 100);
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        taskId,
        message: "\u4F18\u5316\u4EFB\u52A1\u5DF2\u521B\u5EFA\uFF0C\u8BF7\u901A\u8FC7taskId\u67E5\u8BE2\u8FDB\u5EA6",
        status: "pending"
      })
    };
  } catch (error) {
    console.error("\u274C API\u9519\u8BEF:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "API Error",
        message: error.message,
        success: false
      })
    };
  }
};
