var __getOwnPropNames = Object.getOwnPropertyNames;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// api/types/index.js
var require_types = __commonJS({
  "api/types/index.js"(exports2, module2) {
    var DesignSteel = class {
      constructor({
        id,
        length,
        quantity,
        crossSection,
        displayId = "",
        componentNumber = "",
        specification = "",
        partNumber = ""
      }) {
        this.id = id;
        this.length = length;
        this.quantity = quantity;
        this.crossSection = crossSection;
        this.displayId = displayId;
        this.componentNumber = componentNumber;
        this.specification = specification;
        this.partNumber = partNumber;
      }
    };
    var ModuleSteel = class {
      constructor({ id, name, length }) {
        this.id = id;
        this.name = name;
        this.length = length;
      }
    };
    var RemainderV3 = class {
      constructor({
        id,
        length,
        type = "pending",
        // 'pseudo' | 'real' | 'waste' | 'pending'
        isConsumed = false,
        sourceChain = [],
        crossSection,
        createdAt = (/* @__PURE__ */ new Date()).toISOString(),
        consumedAt = null,
        originalLength = null,
        parentId = null
      }) {
        this.id = id;
        this.length = length;
        this.type = type;
        this.isConsumed = isConsumed;
        this.sourceChain = sourceChain;
        this.crossSection = crossSection;
        this.createdAt = createdAt;
        this.consumedAt = consumedAt;
        this.originalLength = originalLength;
        this.parentId = parentId;
      }
      /**
       * 标记为伪余料（已被使用）
       */
      markAsPseudo() {
        this.type = "pseudo";
        this.isConsumed = true;
        this.consumedAt = (/* @__PURE__ */ new Date()).toISOString();
      }
      /**
       * 标记为真余料（未使用，计入损耗）
       */
      markAsReal() {
        this.type = "real";
        this.isConsumed = false;
      }
      /**
       * 标记为废料
       */
      markAsWaste() {
        this.type = "waste";
      }
    };
    var OptimizationConstraints = class {
      constructor({
        wasteThreshold = 600,
        targetLossRate = 5,
        timeLimit = 300,
        maxWeldingSegments = 1,
        // 保留V3动态焊接约束参数以保持兼容性
        weldingSegments = null,
        // 向后兼容
        maxIterations = 1e3,
        allowDynamicWelding = true,
        minWeldingSegments = 1,
        weldingCostPerSegment = 0.1,
        weldingTimePerSegment = 5
      } = {}) {
        this.wasteThreshold = wasteThreshold;
        this.targetLossRate = targetLossRate;
        this.timeLimit = timeLimit;
        this.maxWeldingSegments = maxWeldingSegments;
        if (weldingSegments !== null) {
          this.maxWeldingSegments = weldingSegments;
        }
        this.weldingSegments = this.maxWeldingSegments;
        this.allowDynamicWelding = allowDynamicWelding;
        this.minWeldingSegments = minWeldingSegments;
        this.weldingCostPerSegment = weldingCostPerSegment;
        this.weldingTimePerSegment = weldingTimePerSegment;
        this.maxIterations = maxIterations;
        this.validateBasicConstraints();
      }
      /**
       * V3.1 修复：基础约束验证（更宽松的验证逻辑）
       * 严格验证由约束配置中心统一处理
       */
      validateBasicConstraints() {
        if (this.wasteThreshold <= 0) {
          throw new Error(`\u5E9F\u6599\u9608\u503C${this.wasteThreshold}\u5FC5\u987B\u5927\u4E8E0`);
        }
        if (this.maxWeldingSegments < 1) {
          throw new Error(`\u6700\u5927\u710A\u63A5\u6BB5\u6570${this.maxWeldingSegments}\u4E0D\u80FD\u5C0F\u4E8E1`);
        }
        if (this.timeLimit <= 0) {
          throw new Error(`\u65F6\u95F4\u9650\u5236${this.timeLimit}\u5FC5\u987B\u5927\u4E8E0`);
        }
        if (this.maxWeldingSegments > 10) {
          console.warn(`\u26A0\uFE0F \u710A\u63A5\u6BB5\u6570${this.maxWeldingSegments}\u8F83\u5927\uFF0C\u53EF\u80FD\u5F71\u54CD\u4F18\u5316\u6548\u679C`);
        }
      }
      /**
       * V3新增：动态设置焊接段数
       */
      setWeldingSegments(segments) {
        if (segments < this.minWeldingSegments || segments > this.maxWeldingSegments) {
          throw new Error(`\u710A\u63A5\u6BB5\u6570${segments}\u8D85\u51FA\u5141\u8BB8\u8303\u56F4[${this.minWeldingSegments}, ${this.maxWeldingSegments}]`);
        }
        this.weldingSegments = segments;
        console.log(`\u{1F527} \u52A8\u6001\u8BBE\u7F6E\u710A\u63A5\u7EA6\u675F: \u5141\u8BB8${segments}\u6BB5\u710A\u63A5`);
      }
      /**
       * V3新增：计算焊接成本
       */
      calculateWeldingCost(segments) {
        if (segments <= 1) return 0;
        return (segments - 1) * this.weldingCostPerSegment;
      }
      /**
       * V3新增：计算焊接时间成本
       */
      calculateWeldingTime(segments) {
        if (segments <= 1) return 0;
        return (segments - 1) * this.weldingTimePerSegment;
      }
      /**
       * V3新增：获取焊接约束信息
       */
      getWeldingConstraintInfo() {
        return {
          current: this.weldingSegments,
          min: this.minWeldingSegments,
          max: this.maxWeldingSegments,
          allowDynamic: this.allowDynamicWelding,
          costPerSegment: this.weldingCostPerSegment,
          timePerSegment: this.weldingTimePerSegment
        };
      }
      /**
       * 验证焊接段数约束的可行性
       * 检查设计钢材长度是否超出模数钢材能力范围
       */
      validateWeldingConstraint(designSteels, moduleSteels) {
        const maxModuleLength = Math.max(...moduleSteels.map((m) => m.length));
        const conflictSteels = designSteels.filter((d) => d.length > maxModuleLength);
        if (conflictSteels.length > 0 && this.maxWeldingSegments === 1) {
          return {
            isValid: false,
            conflicts: conflictSteels,
            maxModuleLength,
            suggestions: [
              {
                type: "addLongerModule",
                description: `\u5EFA\u8BAE\u6DFB\u52A0\u957F\u5EA6\u2265${Math.max(...conflictSteels.map((s) => s.length))}mm\u7684\u6A21\u6570\u94A2\u6750`,
                requiredLength: Math.max(...conflictSteels.map((s) => s.length))
              },
              {
                type: "increaseWelding",
                description: `\u5EFA\u8BAE\u5C06\u6700\u5927\u710A\u63A5\u6BB5\u6570\u589E\u52A0\u5230\u2265${Math.ceil(Math.max(...conflictSteels.map((s) => s.length)) / maxModuleLength)}\u6BB5`,
                requiredSegments: Math.ceil(Math.max(...conflictSteels.map((s) => s.length)) / maxModuleLength)
              }
            ]
          };
        }
        return { isValid: true, conflicts: [], suggestions: [] };
      }
      /**
       * 获取约束条件的友好显示名称
       */
      getDisplayNames() {
        return {
          wasteThreshold: "\u5E9F\u6599\u9608\u503C",
          weldingSegments: "\u710A\u63A5\u6BB5\u6570",
          maxIterations: "\u6700\u5927\u8FED\u4EE3\u6B21\u6570",
          timeLimit: "\u8BA1\u7B97\u65F6\u95F4\u9650\u5236",
          allowDynamicWelding: "\u52A8\u6001\u710A\u63A5\u7EA6\u675F",
          maxWeldingSegments: "\u6700\u5927\u710A\u63A5\u6BB5\u6570",
          minWeldingSegments: "\u6700\u5C0F\u710A\u63A5\u6BB5\u6570",
          weldingCostPerSegment: "\u6BCF\u6BB5\u710A\u63A5\u7684\u6210\u672C\u7CFB\u6570",
          weldingTimePerSegment: "\u6BCF\u6BB5\u710A\u63A5\u7684\u65F6\u95F4\u6210\u672C(\u79D2)"
        };
      }
      /**
       * 获取约束条件的详细说明
       */
      getDescriptions() {
        return {
          wasteThreshold: "\u4F59\u6599\u957F\u5EA6\u5C0F\u4E8E\u6B64\u503C\u65F6\u89C6\u4E3A\u5E9F\u6599\uFF0C\u65E0\u6CD5\u518D\u6B21\u5229\u7528",
          weldingSegments: "\u5355\u6839\u8BBE\u8BA1\u94A2\u6750\u5141\u8BB8\u7684\u710A\u63A5\u6BB5\u6570\uFF0C1\u6BB5\u8868\u793A\u4E0D\u5141\u8BB8\u710A\u63A5",
          maxIterations: "\u7B97\u6CD5\u6700\u5927\u8FED\u4EE3\u6B21\u6570\uFF0C\u8D85\u8FC7\u540E\u8FD4\u56DE\u5F53\u524D\u6700\u4F18\u89E3",
          timeLimit: "\u7B97\u6CD5\u8BA1\u7B97\u7684\u6700\u5927\u5141\u8BB8\u65F6\u95F4\uFF0C\u8D85\u65F6\u540E\u8FD4\u56DE\u5F53\u524D\u6700\u4F18\u89E3",
          allowDynamicWelding: "\u662F\u5426\u5141\u8BB8\u52A8\u6001\u8C03\u6574\u710A\u63A5\u6BB5\u6570",
          maxWeldingSegments: "\u5355\u6839\u8BBE\u8BA1\u94A2\u6750\u5141\u8BB8\u7684\u6700\u5927\u710A\u63A5\u6BB5\u6570\uFF0C1\u6BB5\u8868\u793A\u4E0D\u5141\u8BB8\u710A\u63A5",
          minWeldingSegments: "\u5355\u6839\u8BBE\u8BA1\u94A2\u6750\u5141\u8BB8\u7684\u6700\u5C0F\u710A\u63A5\u6BB5\u6570\uFF0C1\u6BB5\u8868\u793A\u4E0D\u5141\u8BB8\u710A\u63A5",
          weldingCostPerSegment: "\u6BCF\u6BB5\u710A\u63A5\u7684\u6210\u672C\u7CFB\u6570\uFF0C\u5F71\u54CD\u710A\u63A5\u6210\u672C",
          weldingTimePerSegment: "\u6BCF\u6BB5\u710A\u63A5\u7684\u65F6\u95F4\u6210\u672C(\u79D2)\uFF0C\u5F71\u54CD\u710A\u63A5\u65F6\u95F4"
        };
      }
    };
    var CuttingDetail = class {
      constructor({
        sourceType,
        // 'module' | 'remainder'
        sourceId,
        sourceLength,
        moduleType = "",
        moduleLength = 0,
        designId,
        length,
        quantity,
        remainderInfo = null,
        // 余料信息
        weldingCount = 1
        // 焊接段数
      }) {
        this.sourceType = sourceType;
        this.sourceId = sourceId;
        this.sourceLength = sourceLength;
        this.moduleType = moduleType;
        this.moduleLength = moduleLength;
        this.designId = designId;
        this.length = length;
        this.quantity = quantity;
        this.remainderInfo = remainderInfo;
        this.weldingCount = weldingCount;
      }
    };
    var CuttingPlan = class {
      constructor({
        sourceType,
        sourceId,
        sourceDescription,
        sourceLength,
        moduleType = "",
        moduleLength = 0,
        cuts = [],
        newRemainders = [],
        pseudoRemainders = [],
        // 伪余料
        realRemainders = [],
        // 真余料
        waste = 0,
        usedRemainders = []
      }) {
        this.sourceType = sourceType;
        this.sourceId = sourceId;
        this.sourceDescription = sourceDescription;
        this.sourceLength = sourceLength;
        this.moduleType = moduleType;
        this.moduleLength = moduleLength;
        this.cuts = cuts;
        this.newRemainders = newRemainders;
        this.pseudoRemainders = pseudoRemainders;
        this.realRemainders = realRemainders;
        this.waste = waste;
        this.usedRemainders = usedRemainders;
      }
    };
    var OptimizationSolution = class {
      constructor({
        cuttingPlans = [],
        totalModuleUsed = 0,
        totalWaste = 0,
        totalPseudoRemainder = 0,
        // 伪余料总长度
        totalRealRemainder = 0,
        // 真余料总长度
        details = [],
        lossRateBreakdown = {}
        // 损耗率分解
      }) {
        this.cuttingPlans = cuttingPlans;
        this.totalModuleUsed = totalModuleUsed;
        this.totalWaste = totalWaste;
        this.totalPseudoRemainder = totalPseudoRemainder;
        this.totalRealRemainder = totalRealRemainder;
        this.details = details;
        this.lossRateBreakdown = lossRateBreakdown;
      }
    };
    var OptimizationResult = class {
      constructor({
        solutions = {},
        totalLossRate = 0,
        totalModuleUsed = 0,
        totalWaste = 0,
        totalPseudoRemainder = 0,
        totalRealRemainder = 0,
        totalMaterial = 0,
        executionTime = 0,
        lossRateValidation = null,
        // 损耗率验证结果
        constraintValidation = null
        // 约束验证结果
      }) {
        this.solutions = solutions;
        this.totalLossRate = totalLossRate;
        this.totalModuleUsed = totalModuleUsed;
        this.totalWaste = totalWaste;
        this.totalPseudoRemainder = totalPseudoRemainder;
        this.totalRealRemainder = totalRealRemainder;
        this.totalMaterial = totalMaterial;
        this.executionTime = executionTime;
        this.lossRateValidation = lossRateValidation;
        this.constraintValidation = constraintValidation;
      }
    };
    module2.exports = {
      // 基础类型
      DesignSteel,
      ModuleSteel,
      RemainderV3,
      // 约束系统
      OptimizationConstraints,
      // 切割和结果
      CuttingDetail,
      CuttingPlan,
      OptimizationSolution,
      OptimizationResult,
      // 🔧 统一架构：LossRateCalculator已整合到StatisticsCalculator中
      // 计算器相关功能请使用 StatisticsCalculator
      // 常量
      REMAINDER_TYPES: {
        PENDING: "pending",
        PSEUDO: "pseudo",
        REAL: "real",
        WASTE: "waste"
      },
      SOURCE_TYPES: {
        MODULE: "module",
        REMAINDER: "remainder"
      }
    };
  }
});

// core/config/ConstraintConfig.js
var require_ConstraintConfig = __commonJS({
  "core/config/ConstraintConfig.js"(exports2, module2) {
    var DEFAULT_CONSTRAINTS = {
      wasteThreshold: 600,
      // 废料阈值 (mm) - 余料长度小于此值时视为废料，默认值600mm
      targetLossRate: 5,
      // 目标损耗率 (%) - 优化目标参考值（软约束）
      timeLimit: 3e5,
      // 计算时间限制 (ms) - 算法最大运行时间 = 300秒
      maxWeldingSegments: 1
      // 最大焊接段数 (段) - 单根设计钢材允许的最大焊接段数
    };
    var VALIDATION_LIMITS = {
      wasteThreshold: {
        min: 100,
        // 最小废料阈值 (mm) - 必须≥100mm
        max: 2e3,
        // 最大废料阈值 (mm) - 放宽上限
        recommended: {
          min: 100,
          // 推荐最小值
          max: 1e3
          // 推荐最大值
        }
      },
      targetLossRate: {
        min: 0,
        // 最小损耗率 (%)
        max: 100,
        // 最大损耗率 (%)
        recommended: {
          min: 2,
          // 推荐最小值
          max: 15
          // 推荐最大值
        }
      },
      timeLimit: {
        min: 1e3,
        // 最小时间限制 (ms) = 1秒
        max: 3e5,
        // 最大时间限制 (ms) = 300秒
        recommended: {
          min: 5e3,
          // 推荐最小值 = 5秒
          max: 6e4
          // 推荐最大值 = 1分钟
        }
      },
      maxWeldingSegments: {
        min: 1,
        // 最小焊接段数
        max: 10,
        // 最大焊接段数
        recommended: {
          min: 1,
          // 推荐最小值
          max: 3
          // 推荐最大值
        }
      }
    };
    var DATA_LIMITS = {
      designSteel: {
        maxLength: 5e4,
        // 设计钢材最大长度 (mm)
        maxQuantity: 1e4,
        // 设计钢材最大数量
        maxCrossSection: 1e5
        // 最大截面面积 (mm²)
      },
      moduleSteel: {
        minLength: 1e3,
        // 模数钢材最小长度 (mm)
        maxLength: 5e4
        // 模数钢材最大长度 (mm)
      }
    };
    var STANDARD_STEEL_LENGTHS = [6e3, 9e3, 12e3, 15e3, 18e3];
    var DEFAULT_MODULE_LENGTHS = [12e3, 1e4, 8e3, 6e3];
    var REMAINDER_CONFIG = {
      idGeneration: {
        letterLimit: 50,
        // 单字母余料ID数量限制
        maxLetters: 26
        // 最大字母数量（a-z）
      },
      defaultWasteThreshold: 600,
      // 余料管理器默认废料阈值（与DEFAULT_CONSTRAINTS.wasteThreshold保持一致）
      binarySearchEnabled: true,
      // 是否启用二分查找优化
      dynamicAlgorithmSelection: true,
      // 是否启用动态算法选择
      algorithmThresholds: {
        smallScalePoolSize: 20,
        // 小规模问题的池大小阈值
        maxSegmentsForDP: 2
        // 动态规划算法的最大段数阈值
      }
    };
    var PERFORMANCE_CONFIG = {
      parallelOptimization: {
        maxActiveOptimizers: 10,
        // 最大并发优化器数量
        optimizerTimeout: 300,
        // 优化器超时时间 (ms)
        cleanupInterval: 6e4,
        // 清理间隔 (ms)
        historyLimit: 100
        // 历史记录数量限制
      },
      iterationLimits: {
        maxIterationsPerDemand: 100,
        // 每个需求的最大迭代次数倍数
        maxTotalIterations: 1e6
        // 总的最大迭代次数（安全上限）
      }
    };
    var ERROR_CONFIG = {
      validation: {
        maxErrorHistorySize: 100,
        // 最大错误历史记录数
        recentErrorWindow: 864e5
        // 最近错误时间窗口 (ms) = 24小时
      },
      systemResource: {
        highMemoryThreshold: 1e3,
        // 高内存使用阈值 (MB)
        maxFileSize: 10485760
        // 最大文件大小 (bytes) = 10MB
      }
    };
    var SCENARIO_CONFIGS = {
      // 高精度场景：桥梁、重要结构
      "precision": {
        wasteThreshold: 200,
        targetLossRate: 2,
        timeLimit: 6e4,
        // 1分钟
        maxWeldingSegments: 1,
        description: "\u9AD8\u7CBE\u5EA6\u573A\u666F - \u9002\u7528\u4E8E\u6865\u6881\u3001\u91CD\u8981\u7ED3\u6784\u7B49\u5BF9\u7CBE\u5EA6\u8981\u6C42\u6781\u9AD8\u7684\u9879\u76EE"
      },
      // 标准场景：一般建筑
      "standard": {
        wasteThreshold: 600,
        targetLossRate: 5,
        timeLimit: 3e5,
        // 300秒
        maxWeldingSegments: 2,
        description: "\u6807\u51C6\u573A\u666F - \u9002\u7528\u4E8E\u4E00\u822C\u5EFA\u7B51\u9879\u76EE\uFF0C\u5E73\u8861\u7CBE\u5EA6\u548C\u6548\u7387"
      },
      // 经济场景：成本优先
      "economic": {
        wasteThreshold: 800,
        targetLossRate: 8,
        timeLimit: 15e3,
        // 15秒
        maxWeldingSegments: 3,
        description: "\u7ECF\u6D4E\u573A\u666F - \u9002\u7528\u4E8E\u6210\u672C\u654F\u611F\u9879\u76EE\uFF0C\u4F18\u5148\u8003\u8651\u6548\u7387"
      },
      // 快速场景：时间优先
      "fast": {
        wasteThreshold: 700,
        targetLossRate: 6,
        timeLimit: 1e4,
        // 10秒
        maxWeldingSegments: 2,
        description: "\u5FEB\u901F\u573A\u666F - \u9002\u7528\u4E8E\u65F6\u95F4\u7D27\u6025\u7684\u9879\u76EE\uFF0C\u5FEB\u901F\u7ED9\u51FA\u4F18\u5316\u7ED3\u679C"
      }
    };
    var CONSTRAINT_DESCRIPTIONS = {
      wasteThreshold: "\u5F53\u4F59\u6599\u957F\u5EA6\u5C0F\u4E8E\u6B64\u503C\u65F6\uFF0C\u5C06\u88AB\u89C6\u4E3A\u5E9F\u6599\u65E0\u6CD5\u518D\u6B21\u5229\u7528",
      targetLossRate: "\u7B97\u6CD5\u4F18\u5316\u65F6\u7684\u76EE\u6807\u635F\u8017\u7387\uFF0C\u4F5C\u4E3A\u53C2\u8003\u503C\uFF08\u4E0D\u662F\u5F3A\u5236\u8981\u6C42\uFF09",
      timeLimit: "\u7B97\u6CD5\u8BA1\u7B97\u7684\u6700\u5927\u5141\u8BB8\u65F6\u95F4\uFF0C\u8D85\u65F6\u540E\u8FD4\u56DE\u5F53\u524D\u6700\u4F18\u89E3",
      maxWeldingSegments: "\u5355\u6839\u8BBE\u8BA1\u94A2\u6750\u5141\u8BB8\u7684\u6700\u5927\u710A\u63A5\u6BB5\u6570\uFF0C1\u6BB5\u8868\u793A\u4E0D\u5141\u8BB8\u710A\u63A5\uFF08V3\u6838\u5FC3\u529F\u80FD\uFF09"
    };
    var UNIT_CONVERSIONS = {
      time: {
        // 前端显示单位：秒，后端处理单位：毫秒
        msToSeconds: (ms) => Math.round(ms / 1e3),
        secondsToMs: (seconds) => Math.round(seconds * 1e3)
      },
      length: {
        // 统一使用毫米作为基础单位
        mmToM: (mm) => mm / 1e3,
        mToMm: (m) => m * 1e3
      }
    };
    var ENV_OVERRIDES = {
      wasteThreshold: process.env.HGJ_WASTE_THRESHOLD ? parseInt(process.env.HGJ_WASTE_THRESHOLD) : null,
      targetLossRate: process.env.HGJ_TARGET_LOSS_RATE ? parseFloat(process.env.HGJ_TARGET_LOSS_RATE) : null,
      timeLimit: process.env.HGJ_TIME_LIMIT ? parseInt(process.env.HGJ_TIME_LIMIT) : null,
      maxWeldingSegments: process.env.HGJ_MAX_WELDING_SEGMENTS ? parseInt(process.env.HGJ_MAX_WELDING_SEGMENTS) : null
    };
    module2.exports = {
      DEFAULT_CONSTRAINTS,
      VALIDATION_LIMITS,
      DATA_LIMITS,
      STANDARD_STEEL_LENGTHS,
      DEFAULT_MODULE_LENGTHS,
      REMAINDER_CONFIG,
      PERFORMANCE_CONFIG,
      ERROR_CONFIG,
      SCENARIO_CONFIGS,
      CONSTRAINT_DESCRIPTIONS,
      UNIT_CONVERSIONS,
      ENV_OVERRIDES
    };
  }
});

// core/config/ConstraintManager.js
var require_ConstraintManager = __commonJS({
  "core/config/ConstraintManager.js"(exports2, module2) {
    var {
      DEFAULT_CONSTRAINTS,
      VALIDATION_LIMITS,
      DATA_LIMITS,
      STANDARD_STEEL_LENGTHS,
      DEFAULT_MODULE_LENGTHS,
      REMAINDER_CONFIG,
      PERFORMANCE_CONFIG,
      ERROR_CONFIG,
      SCENARIO_CONFIGS,
      CONSTRAINT_DESCRIPTIONS,
      UNIT_CONVERSIONS,
      ENV_OVERRIDES
    } = require_ConstraintConfig();
    var ConstraintManager = class {
      constructor() {
        this.initializeConstraints();
      }
      /**
       * 初始化约束配置，应用环境变量覆盖
       */
      initializeConstraints() {
        this.currentConstraints = { ...DEFAULT_CONSTRAINTS };
        Object.keys(ENV_OVERRIDES).forEach((key) => {
          if (ENV_OVERRIDES[key] !== null) {
            this.currentConstraints[key] = ENV_OVERRIDES[key];
            console.log(`\u{1F527} \u7EA6\u675F\u914D\u7F6E\u8986\u76D6: ${key} = ${ENV_OVERRIDES[key]} (\u6765\u6E90: \u73AF\u5883\u53D8\u91CF)`);
          }
        });
        console.log("\u{1F4CB} \u7EA6\u675F\u7BA1\u7406\u5668\u521D\u59CB\u5316\u5B8C\u6210:", this.currentConstraints);
      }
      /**
       * 获取默认约束条件
       * @param {string} scenario - 可选的场景名称
       * @returns {Object} 约束条件对象
       */
      getDefaultConstraints(scenario = null) {
        if (scenario && SCENARIO_CONFIGS[scenario]) {
          const scenarioConfig = SCENARIO_CONFIGS[scenario];
          console.log(`\u{1F3AF} \u4F7F\u7528\u573A\u666F\u5316\u7EA6\u675F\u914D\u7F6E: ${scenario} - ${scenarioConfig.description}`);
          return {
            wasteThreshold: scenarioConfig.wasteThreshold,
            targetLossRate: scenarioConfig.targetLossRate,
            timeLimit: scenarioConfig.timeLimit,
            maxWeldingSegments: scenarioConfig.maxWeldingSegments
          };
        }
        return { ...this.currentConstraints };
      }
      /**
       * 获取约束验证限制
       * @param {string} constraintKey - 约束键名
       * @returns {Object} 验证限制对象
       */
      getValidationLimits(constraintKey = null) {
        if (constraintKey) {
          return VALIDATION_LIMITS[constraintKey] || null;
        }
        return VALIDATION_LIMITS;
      }
      /**
       * 验证单个约束条件
       * @param {string} key - 约束键名
       * @param {*} value - 约束值
       * @returns {Object} 验证结果
       */
      validateConstraint(key, value) {
        const limits = VALIDATION_LIMITS[key];
        if (!limits) {
          return {
            isValid: false,
            error: `\u672A\u77E5\u7684\u7EA6\u675F\u6761\u4EF6: ${key}`,
            code: "UNKNOWN_CONSTRAINT"
          };
        }
        if (typeof value !== "number" || isNaN(value)) {
          return {
            isValid: false,
            error: `${key} \u5FC5\u987B\u662F\u6709\u6548\u6570\u5B57`,
            code: "INVALID_TYPE"
          };
        }
        if (value < limits.min || value > limits.max) {
          return {
            isValid: false,
            error: `${key} \u5FC5\u987B\u5728 ${limits.min}-${limits.max} \u8303\u56F4\u5185`,
            code: "OUT_OF_RANGE",
            limits
          };
        }
        const isRecommended = value >= limits.recommended.min && value <= limits.recommended.max;
        return {
          isValid: true,
          isRecommended,
          recommendedRange: limits.recommended,
          warning: !isRecommended ? `\u5EFA\u8BAE\u5C06${key}\u8BBE\u7F6E\u5728 ${limits.recommended.min}-${limits.recommended.max} \u8303\u56F4\u5185\u4EE5\u83B7\u5F97\u6700\u4F73\u6548\u679C` : null
        };
      }
      /**
       * 验证完整的约束条件对象
       * @param {Object} constraints - 约束条件对象
       * @returns {Object} 验证结果
       */
      validateConstraints(constraints) {
        const results = {
          isValid: true,
          errors: [],
          warnings: [],
          fieldResults: {}
        };
        Object.keys(DEFAULT_CONSTRAINTS).forEach((key) => {
          if (constraints.hasOwnProperty(key)) {
            const validation = this.validateConstraint(key, constraints[key]);
            results.fieldResults[key] = validation;
            if (!validation.isValid) {
              results.isValid = false;
              results.errors.push({
                field: key,
                message: validation.error,
                code: validation.code,
                limits: validation.limits
              });
            } else if (validation.warning) {
              results.warnings.push({
                field: key,
                message: validation.warning
              });
            }
          }
        });
        return results;
      }
      /**
       * 获取数据验证限制
       * @param {string} dataType - 数据类型 ('designSteel' | 'moduleSteel')
       * @returns {Object} 数据验证限制
       */
      getDataLimits(dataType = null) {
        if (dataType) {
          return DATA_LIMITS[dataType] || null;
        }
        return DATA_LIMITS;
      }
      /**
       * 获取标准钢材长度
       * @returns {Array} 标准长度数组
       */
      getStandardSteelLengths() {
        return [...STANDARD_STEEL_LENGTHS];
      }
      /**
       * 获取默认模数钢材长度
       * @returns {Array} 默认模数钢材长度数组
       */
      getDefaultModuleLengths() {
        return [...DEFAULT_MODULE_LENGTHS];
      }
      /**
       * 获取余料管理配置
       * @returns {Object} 余料管理配置
       */
      getRemainderConfig() {
        return { ...REMAINDER_CONFIG };
      }
      /**
       * 获取性能配置
       * @returns {Object} 性能配置
       */
      getPerformanceConfig() {
        return { ...PERFORMANCE_CONFIG };
      }
      /**
       * 获取错误处理配置
       * @returns {Object} 错误处理配置
       */
      getErrorConfig() {
        return { ...ERROR_CONFIG };
      }
      /**
       * 获取约束描述
       * @param {string} constraintKey - 约束键名
       * @returns {string} 约束描述
       */
      getConstraintDescription(constraintKey) {
        return CONSTRAINT_DESCRIPTIONS[constraintKey] || "";
      }
      /**
       * 获取所有约束描述
       * @returns {Object} 所有约束描述
       */
      getAllConstraintDescriptions() {
        return { ...CONSTRAINT_DESCRIPTIONS };
      }
      /**
       * 获取可用的场景配置
       * @returns {Object} 场景配置
       */
      getAvailableScenarios() {
        return Object.keys(SCENARIO_CONFIGS).map((key) => ({
          key,
          name: key,
          description: SCENARIO_CONFIGS[key].description,
          constraints: {
            wasteThreshold: SCENARIO_CONFIGS[key].wasteThreshold,
            targetLossRate: SCENARIO_CONFIGS[key].targetLossRate,
            timeLimit: SCENARIO_CONFIGS[key].timeLimit,
            maxWeldingSegments: SCENARIO_CONFIGS[key].maxWeldingSegments
          }
        }));
      }
      /**
       * 时间单位转换：毫秒转秒（用于前端显示）
       * @param {number} ms - 毫秒
       * @returns {number} 秒
       */
      msToSeconds(ms) {
        return UNIT_CONVERSIONS.time.msToSeconds(ms);
      }
      /**
       * 时间单位转换：秒转毫秒（用于后端处理）
       * @param {number} seconds - 秒
       * @returns {number} 毫秒
       */
      secondsToMs(seconds) {
        return UNIT_CONVERSIONS.time.secondsToMs(seconds);
      }
      /**
       * 长度单位转换：毫米转米
       * @param {number} mm - 毫米
       * @returns {number} 米
       */
      mmToM(mm) {
        return UNIT_CONVERSIONS.length.mmToM(mm);
      }
      /**
       * 长度单位转换：米转毫米
       * @param {number} m - 米
       * @returns {number} 毫米
       */
      mToMm(m) {
        return UNIT_CONVERSIONS.length.mToMm(m);
      }
      /**
       * 创建前端安全的约束对象（时间转换为秒）
       * @param {Object} constraints - 后端约束对象（时间为毫秒）
       * @returns {Object} 前端约束对象（时间为秒）
       */
      createFrontendConstraints(constraints) {
        return {
          wasteThreshold: constraints.wasteThreshold,
          targetLossRate: constraints.targetLossRate,
          timeLimit: this.msToSeconds(constraints.timeLimit),
          maxWeldingSegments: constraints.maxWeldingSegments
        };
      }
      /**
       * 创建后端约束对象（时间转换为毫秒）
       * @param {Object} frontendConstraints - 前端约束对象（时间为秒）
       * @returns {Object} 后端约束对象（时间为毫秒）
       */
      createBackendConstraints(frontendConstraints) {
        return {
          wasteThreshold: frontendConstraints.wasteThreshold,
          targetLossRate: frontendConstraints.targetLossRate,
          timeLimit: this.secondsToMs(frontendConstraints.timeLimit),
          maxWeldingSegments: frontendConstraints.maxWeldingSegments
        };
      }
      /**
       * 生成推荐的模数钢材长度
       * @param {number} requiredLength - 所需最小长度
       * @param {number} maxCount - 最大返回数量
       * @returns {Array} 推荐长度数组
       */
      generateRecommendedLengths(requiredLength, maxCount = 3) {
        const recommended = [];
        recommended.push(requiredLength);
        STANDARD_STEEL_LENGTHS.forEach((length) => {
          if (length >= requiredLength && !recommended.includes(length)) {
            recommended.push(length);
          }
        });
        return recommended.sort((a, b) => a - b).slice(0, maxCount);
      }
      /**
       * 检查焊接约束冲突
       * @param {Array} designSteels - 设计钢材数组
       * @param {Array} moduleSteels - 模数钢材数组
       * @param {Object} constraints - 约束条件
       * @returns {Object} 冲突检查结果
       */
      checkWeldingConstraintConflict(designSteels, moduleSteels, constraints) {
        if (!designSteels.length || !moduleSteels.length) {
          return { hasConflict: false };
        }
        const maxModuleLength = Math.max(...moduleSteels.map((m) => m.length));
        const conflictSteels = designSteels.filter((d) => d.length > maxModuleLength);
        if (conflictSteels.length > 0 && constraints.maxWeldingSegments === 1) {
          const maxDesignLength = Math.max(...conflictSteels.map((s) => s.length));
          const requiredSegments = Math.ceil(maxDesignLength / maxModuleLength);
          return {
            hasConflict: true,
            conflictCount: conflictSteels.length,
            maxConflictLength: maxDesignLength,
            maxModuleLength,
            requiredSegments,
            suggestions: [
              {
                type: "addLongerModule",
                title: "\u6DFB\u52A0\u66F4\u957F\u7684\u6A21\u6570\u94A2\u6750",
                description: `\u5EFA\u8BAE\u6DFB\u52A0\u957F\u5EA6\u2265${maxDesignLength}mm\u7684\u6A21\u6570\u94A2\u6750`,
                recommendedLengths: this.generateRecommendedLengths(maxDesignLength)
              },
              {
                type: "increaseWelding",
                title: "\u589E\u52A0\u5141\u8BB8\u710A\u63A5\u6BB5\u6570",
                description: `\u5EFA\u8BAE\u5C06\u6700\u5927\u710A\u63A5\u6BB5\u6570\u8C03\u6574\u4E3A${requiredSegments}\u6BB5\u4EE5\u4E0A`,
                recommendedValue: requiredSegments
              }
            ]
          };
        }
        return { hasConflict: false };
      }
      /**
       * 重置为默认配置
       */
      resetToDefaults() {
        this.initializeConstraints();
        console.log("\u{1F504} \u7EA6\u675F\u914D\u7F6E\u5DF2\u91CD\u7F6E\u4E3A\u9ED8\u8BA4\u503C");
      }
      /**
       * 获取当前配置摘要
       * @returns {Object} 配置摘要
       */
      getConfigSummary() {
        return {
          currentConstraints: { ...this.currentConstraints },
          hasEnvironmentOverrides: Object.values(ENV_OVERRIDES).some((val) => val !== null),
          environmentOverrides: Object.fromEntries(
            Object.entries(ENV_OVERRIDES).filter(([, value]) => value !== null)
          ),
          availableScenarios: Object.keys(SCENARIO_CONFIGS),
          configVersion: "3.0.0",
          lastInitialized: (/* @__PURE__ */ new Date()).toISOString()
        };
      }
    };
    var constraintManager = new ConstraintManager();
    module2.exports = constraintManager;
  }
});

// core/constraints/ConstraintValidator.js
var require_ConstraintValidator = __commonJS({
  "core/constraints/ConstraintValidator.js"(exports2, module2) {
    var { OptimizationConstraints } = require_types();
    var constraintManager = require_ConstraintManager();
    var ConstraintValidator2 = class {
      constructor() {
        this.validationHistory = [];
      }
      /**
       * 综合验证所有约束条件
       */
      validateAllConstraints(designSteels, moduleSteels, constraints) {
        const results = {
          isValid: true,
          violations: [],
          suggestions: [],
          warnings: []
        };
        const basicValidation = this.validateBasicConstraints(constraints);
        if (!basicValidation.isValid) {
          results.isValid = false;
          results.violations.push(...basicValidation.violations);
        }
        const weldingValidation = this.validateWeldingConstraint(designSteels, moduleSteels, constraints);
        if (!weldingValidation.isValid) {
          results.isValid = false;
          results.violations.push(...weldingValidation.violations);
          results.suggestions.push(...weldingValidation.suggestions);
        }
        const dataValidation = this.validateDataIntegrity(designSteels, moduleSteels);
        if (!dataValidation.isValid) {
          results.isValid = false;
          results.violations.push(...dataValidation.violations);
        }
        results.warnings.push(...this.generateWarnings(designSteels, moduleSteels, constraints));
        this.validationHistory.push({
          timestamp: (/* @__PURE__ */ new Date()).toISOString(),
          result: JSON.parse(JSON.stringify(results))
        });
        return results;
      }
      /**
       * 验证基础约束条件
       */
      validateBasicConstraints(constraints) {
        const violations = [];
        const defaults = constraintManager.getDefaultConstraints();
        const validationLimits = constraintManager.getValidationLimits();
        if (constraints.wasteThreshold <= 0) {
          violations.push({
            type: "wasteThreshold",
            message: "\u5E9F\u6599\u9608\u503C\u5FC5\u987B\u5927\u4E8E0",
            current: constraints.wasteThreshold,
            suggested: defaults.wasteThreshold
          });
        }
        if (constraints.targetLossRate < 0 || constraints.targetLossRate > validationLimits.targetLossRate.max) {
          violations.push({
            type: "targetLossRate",
            message: `\u76EE\u6807\u635F\u8017\u7387\u5FC5\u987B\u57280-${validationLimits.targetLossRate.max}%\u4E4B\u95F4`,
            current: constraints.targetLossRate,
            suggested: defaults.targetLossRate
          });
        }
        if (constraints.timeLimit < validationLimits.timeLimit.min || constraints.timeLimit > validationLimits.timeLimit.max) {
          const minSeconds = constraintManager.msToSeconds(validationLimits.timeLimit.min);
          const maxSeconds = constraintManager.msToSeconds(validationLimits.timeLimit.max);
          violations.push({
            type: "timeLimit",
            message: `\u8BA1\u7B97\u65F6\u95F4\u9650\u5236\u5FC5\u987B\u5728${minSeconds}-${maxSeconds}\u79D2\u8303\u56F4\u5185`,
            current: constraints.timeLimit,
            suggested: defaults.timeLimit
          });
        }
        if (constraints.maxWeldingSegments < 1) {
          violations.push({
            type: "maxWeldingSegments",
            message: "\u6700\u5927\u710A\u63A5\u6BB5\u6570\u5FC5\u987B\u22651",
            current: constraints.maxWeldingSegments,
            suggested: defaults.maxWeldingSegments
          });
        }
        return {
          isValid: violations.length === 0,
          violations
        };
      }
      /**
       * 验证焊接约束W
       * 关键功能：检查W=1时是否存在冲突
       */
      validateWeldingConstraint(designSteels, moduleSteels, constraints) {
        if (moduleSteels.length === 0) {
          return {
            isValid: false,
            violations: [{
              type: "noModuleSteel",
              message: "\u81F3\u5C11\u9700\u8981\u4E00\u79CD\u6A21\u6570\u94A2\u6750",
              suggestions: []
            }],
            suggestions: []
          };
        }
        const maxModuleLength = Math.max(...moduleSteels.map((m) => m.length));
        const maxDesignLength = Math.max(...designSteels.map((d) => d.length));
        const conflictSteels = designSteels.filter((d) => d.length > maxModuleLength);
        if (conflictSteels.length > 0 && constraints.maxWeldingSegments === 1) {
          const requiredLength = Math.max(...conflictSteels.map((s) => s.length));
          const requiredSegments = Math.ceil(maxDesignLength / maxModuleLength);
          return {
            isValid: false,
            violations: [{
              type: "weldingConstraintViolation",
              message: `\u7EA6\u675FW=1\u4E0E\u8BBE\u8BA1\u9700\u6C42\u51B2\u7A81`,
              details: {
                maxModuleLength,
                conflictCount: conflictSteels.length,
                maxConflictLength: requiredLength,
                conflictSteels: conflictSteels.slice(0, 5)
                // 只显示前5个
              }
            }],
            suggestions: [
              {
                type: "addLongerModule",
                priority: 1,
                title: "\u65B9\u6848A\uFF1A\u6DFB\u52A0\u66F4\u957F\u7684\u6A21\u6570\u94A2\u6750",
                description: `\u5EFA\u8BAE\u6DFB\u52A0\u957F\u5EA6\u2265${requiredLength}mm\u7684\u6A21\u6570\u94A2\u6750`,
                details: {
                  requiredLength,
                  currentMaxLength: maxModuleLength,
                  additionalLength: requiredLength - maxModuleLength
                },
                implementation: {
                  action: "addModuleSteel",
                  minLength: requiredLength,
                  recommendedLengths: this.generateRecommendedLengths(requiredLength)
                }
              },
              {
                type: "increaseWelding",
                priority: 2,
                title: "\u65B9\u6848B\uFF1A\u589E\u52A0\u5141\u8BB8\u710A\u63A5\u6BB5\u6570",
                description: `\u5EFA\u8BAE\u5C06\u5141\u8BB8\u710A\u63A5\u6BB5\u6570W\u589E\u52A0\u5230\u2265${requiredSegments}`,
                details: {
                  currentW: constraints.maxWeldingSegments,
                  requiredW: requiredSegments,
                  maxSegmentsNeeded: requiredSegments
                },
                implementation: {
                  action: "updateConstraint",
                  parameter: "maxWeldingSegments",
                  minValue: requiredSegments,
                  recommendedValue: requiredSegments
                }
              }
            ]
          };
        }
        const efficiencyWarnings = this.checkWeldingEfficiency(designSteels, moduleSteels, constraints);
        return {
          isValid: true,
          violations: [],
          suggestions: [],
          efficiencyWarnings
        };
      }
      /**
       * 验证数据完整性
       */
      validateDataIntegrity(designSteels, moduleSteels) {
        const violations = [];
        if (designSteels.length === 0) {
          violations.push({
            type: "noDesignSteel",
            message: "\u81F3\u5C11\u9700\u8981\u4E00\u4E2A\u8BBE\u8BA1\u94A2\u6750"
          });
        }
        designSteels.forEach((steel, index) => {
          if (!steel.length || steel.length <= 0) {
            violations.push({
              type: "invalidDesignLength",
              message: `\u8BBE\u8BA1\u94A2\u6750${index + 1}\uFF1A\u957F\u5EA6\u5FC5\u987B\u5927\u4E8E0`,
              steelIndex: index
            });
          }
          if (!steel.quantity || steel.quantity <= 0) {
            violations.push({
              type: "invalidDesignQuantity",
              message: `\u8BBE\u8BA1\u94A2\u6750${index + 1}\uFF1A\u6570\u91CF\u5FC5\u987B\u5927\u4E8E0`,
              steelIndex: index
            });
          }
          if (!steel.crossSection || steel.crossSection <= 0) {
            violations.push({
              type: "invalidCrossSection",
              message: `\u8BBE\u8BA1\u94A2\u6750${index + 1}\uFF1A\u622A\u9762\u9762\u79EF\u5FC5\u987B\u5927\u4E8E0`,
              steelIndex: index
            });
          }
        });
        if (moduleSteels.length === 0) {
          violations.push({
            type: "noModuleSteel",
            message: "\u81F3\u5C11\u9700\u8981\u4E00\u79CD\u6A21\u6570\u94A2\u6750"
          });
        }
        moduleSteels.forEach((steel, index) => {
          if (!steel.length || steel.length <= 0) {
            violations.push({
              type: "invalidModuleLength",
              message: `\u6A21\u6570\u94A2\u6750${index + 1}\uFF1A\u957F\u5EA6\u5FC5\u987B\u5927\u4E8E0`,
              steelIndex: index
            });
          }
        });
        return {
          isValid: violations.length === 0,
          violations
        };
      }
      /**
       * 生成警告信息
       */
      generateWarnings(designSteels, moduleSteels, constraints) {
        const warnings = [];
        const avgDesignLength = designSteels.reduce((sum, s) => sum + s.length, 0) / designSteels.length;
        const avgModuleLength = moduleSteels.reduce((sum, s) => sum + s.length, 0) / moduleSteels.length;
        if (avgDesignLength < avgModuleLength * 0.3) {
          warnings.push({
            type: "highWasteRisk",
            level: "warning",
            message: "\u8BBE\u8BA1\u94A2\u6750\u5E73\u5747\u957F\u5EA6\u8F83\u77ED\uFF0C\u53EF\u80FD\u5BFC\u81F4\u8F83\u9AD8\u7684\u635F\u8017\u7387",
            suggestion: "\u8003\u8651\u4F18\u5316\u8BBE\u8BA1\u5C3A\u5BF8\u6216\u8C03\u6574\u6A21\u6570\u94A2\u6750\u89C4\u683C"
          });
        }
        if (constraints.maxWeldingSegments === 1 && moduleSteels.length > 1) {
          warnings.push({
            type: "constraintEfficiency",
            level: "info",
            message: "W=1\u4E14\u6709\u591A\u79CD\u6A21\u6570\u94A2\u6750\uFF0C\u7CFB\u7EDF\u5C06\u81EA\u52A8\u9009\u62E9\u6700\u4F18\u89C4\u683C",
            suggestion: "\u8003\u8651\u589E\u52A0W\u503C\u4EE5\u83B7\u5F97\u66F4\u7075\u6D3B\u7684\u4F18\u5316\u7ED3\u679C"
          });
        }
        const totalDesignCount = designSteels.reduce((sum, s) => sum + s.quantity, 0);
        const timeLimitSeconds = constraintManager.msToSeconds(constraints.timeLimit);
        if (timeLimitSeconds < Math.ceil(totalDesignCount / 10) && totalDesignCount > 100) {
          warnings.push({
            type: "timeLimitRisk",
            level: "warning",
            message: "\u8BBE\u8BA1\u94A2\u6750\u6570\u91CF\u8F83\u591A\uFF0C\u5EFA\u8BAE\u589E\u52A0\u65F6\u95F4\u9650\u5236\u4EE5\u83B7\u5F97\u66F4\u597D\u7684\u4F18\u5316\u7ED3\u679C",
            suggestion: `\u5EFA\u8BAE\u65F6\u95F4\u9650\u5236\u8BBE\u7F6E\u4E3A\u2265${Math.ceil(totalDesignCount / 10)}\u79D2`
          });
        }
        return warnings;
      }
      /**
       * 检查焊接效率
       */
      checkWeldingEfficiency(designSteels, moduleSteels, constraints) {
        const warnings = [];
        const maxModuleLength = Math.max(...moduleSteels.map((m) => m.length));
        const needWeldingCount = designSteels.filter((d) => {
          const segmentsNeeded = Math.ceil(d.length / maxModuleLength);
          return segmentsNeeded > constraints.maxWeldingSegments;
        }).length;
        if (needWeldingCount > 0) {
          warnings.push({
            type: "weldingEfficiency",
            level: "info",
            message: `\u6709${needWeldingCount}\u4E2A\u8BBE\u8BA1\u94A2\u6750\u53EF\u80FD\u9700\u8981\u66F4\u591A\u710A\u63A5\u6BB5\u6570`,
            details: { needWeldingCount, totalCount: designSteels.length }
          });
        }
        return warnings;
      }
      /**
       * 生成推荐的模数钢材长度
       */
      generateRecommendedLengths(requiredLength) {
        const standardLengths = constraintManager.getStandardSteelLengths();
        const recommended = [];
        recommended.push(requiredLength);
        standardLengths.forEach((length) => {
          if (length >= requiredLength && !recommended.includes(length)) {
            recommended.push(length);
          }
        });
        return recommended.sort((a, b) => a - b).slice(0, 3);
      }
      /**
       * 获取约束违规的用户友好描述
       */
      getViolationSummary(violations) {
        if (violations.length === 0) {
          return "\u6240\u6709\u7EA6\u675F\u6761\u4EF6\u5747\u5DF2\u6EE1\u8DB3";
        }
        const categories = {
          critical: [],
          warning: [],
          info: []
        };
        violations.forEach((violation) => {
          const severity = this.getViolationSeverity(violation.type);
          categories[severity].push(violation);
        });
        let summary = "";
        if (categories.critical.length > 0) {
          summary += `\u274C ${categories.critical.length}\u4E2A\u4E25\u91CD\u95EE\u9898\u9700\u8981\u89E3\u51B3
`;
        }
        if (categories.warning.length > 0) {
          summary += `\u26A0\uFE0F ${categories.warning.length}\u4E2A\u8B66\u544A
`;
        }
        if (categories.info.length > 0) {
          summary += `\u2139\uFE0F ${categories.info.length}\u4E2A\u63D0\u793A`;
        }
        return summary.trim();
      }
      /**
       * 获取违规严重程度
       */
      getViolationSeverity(violationType) {
        const severityMap = {
          "weldingConstraintViolation": "critical",
          "noDesignSteel": "critical",
          "noModuleSteel": "critical",
          "invalidDesignLength": "critical",
          "invalidDesignQuantity": "critical",
          "invalidCrossSection": "critical",
          "invalidModuleLength": "critical",
          "wasteThreshold": "warning",
          "targetLossRate": "warning",
          "timeLimit": "warning",
          "maxWeldingSegments": "warning"
        };
        return severityMap[violationType] || "info";
      }
      /**
       * 清空验证历史
       */
      clearHistory() {
        this.validationHistory = [];
      }
      /**
       * 获取验证历史
       */
      getValidationHistory() {
        return this.validationHistory.slice();
      }
    };
    module2.exports = ConstraintValidator2;
  }
});

// netlify/functions/validate-constraints.js
var { ConstraintValidator } = require_ConstraintValidator();
exports.handler = async (event, context) => {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const data = JSON.parse(event.body);
    const { constraints } = data;
    if (!constraints) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: "Constraints data is required" })
      };
    }
    const validator = new ConstraintValidator();
    const result = validator.validateConstraints(constraints);
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify(result)
    };
  } catch (error) {
    console.error("Constraint validation error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Constraint validation failed",
        message: error.message
      })
    };
  }
};
